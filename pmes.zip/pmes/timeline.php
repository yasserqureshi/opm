<?php
error_reporting(0); // Turn off all error reporting
if(session_status()!=PHP_SESSION_ACTIVE) 
	session_start();
date_default_timezone_set("Asia/Karachi");
if(!isset($_SESSION['username']))
	header('location: index.php');
include('include/connection.php');
include('header.php');
$projectid=mysqli_real_escape_string($conn,$_GET['projectid'])+0;
$stmt_main = "select project_id, project_name, project_cost, expected_completion_cost,
		  round((ifnull(expected_completion_cost,0)-ifnull(project_cost,0))/project_cost*100) cost_over_run_formula, 
		  date_format(commencement_date,'%d-%m-%Y') commencement_date, date_format(completion_date,'%d-%M-%Y') completion_date, 
		  date_format(ifnull(completion_date,expected_completion_date),'%d-%m-%Y') expected_completion_date, psdp_number, 
		  physical_progress,
		  round(((ifnull(expenditure_upto,0)+ifnull(expenditure,0))*100)/ifnull(expected_completion_cost,project_cost)) financial_progress,
		  TIMESTAMPDIFF(MONTH, completion_date, date_format(now(), '%Y%m%d'))  time_over_run 
		  from tbl_project_summary where project_id=".$projectid;
$run_query_main= $conn->query($stmt_main);
if ($run_query_main->num_rows > 0)
		{
			$row_main = mysqli_fetch_assoc($run_query_main);
		}
		else
		{
			echo "<font style='color:#F00; font-style:italic; font-size:20px'>";
			die("Fata Error-00215! Unable to execute query. Please contact Director-MIS (0321-9131997).");
			echo "</font>";
		}
		
$output = fopen('json/timeline_progress.csv', 'w');
		
// output the column headings
fputcsv($output, array('Month', 'July', 'Aug','Sept','Oct','Nov','Dec','Jan','Feb','Mar','Apr','May','Jun'));

$stmt_timeline_progress = "SELECT progress_type,		
		ifnull(max(case when for_month='JULY' then progress end),-1)  Jul,
		ifnull(max(case when for_month='AUGUST' then progress end),-1)  Aug,
		ifnull(max(case when for_month='SEPTEMBER' then progress end),-1)  Sep,
		ifnull(max(case when for_month='OCTOBER' then progress end),-1)  Oct,
		ifnull(max(case when for_month='NOVEMBER' then progress end),-1)  Nov,
		ifnull(max(case when for_month='DECEMBER' then progress end),-1) 'Dec',
		ifnull(max(case when for_month='JANUARY' then progress end),-1) 'Jan',
		ifnull(max(case when for_month='FEBRUARY' then progress end),-1) 'Feb',
		ifnull(max(case when for_month='MARCH' then progress end),-1) 'Mar',
		ifnull(max(case when for_month='APRIL' then progress end),-1) 'Apr',
		ifnull(max(case when for_month='MAY' then progress end),-1) 'May',
		ifnull(max(case when for_month='JUNE' then progress end),-1) 'Jun'
		FROM vw_progress 
		where project_id=".$projectid." group by progress_type";
$run_query_timeline_progress= $conn->query($stmt_timeline_progress);

// loop over the rows, outputting them
while ($row_timeline_progress=mysqli_fetch_assoc($run_query_timeline_progress)) 
	fputcsv($output, $row_timeline_progress);

fclose($output);

$output2 = fopen('json/timeline_outlay.csv', 'w');

fputcsv($output2, array('Category', 'Allocation', 'Releases','Expenditure'));

$stmt_timeline_outlay = "select concat('PSDP No.',psdp_number),allocation,releases,expenditure from tbl_project_summary
			where project_id=".$projectid;

$run_query_timeline_outlay= $conn->query($stmt_timeline_outlay);

// loop over the rows, outputting them
while ($row_timeline_outlay=mysqli_fetch_assoc($run_query_timeline_outlay)) 
	fputcsv($output2, $row_timeline_outlay);

fclose($output2);

// Speedometer

$stmt_spi="select ifnull(round((round(ifnull(physical_progress,0)/
		TIMESTAMPDIFF(MONTH,DATE_FORMAT(commencement_date,'%Y-%m-%d'),DATE_FORMAT(now(),'%Y-%m-%d')),2)*100) / 
		(100 / TIMESTAMPDIFF(MONTH,DATE_FORMAT(commencement_date,'%Y-%m-%d'),DATE_FORMAT(completion_date,'%Y-%m-%d'))),0),0)
		speed from tbl_project_summary
		where project_id=".$projectid;
			
	$run_query_spi= $conn->query($stmt_spi);
	if($run_query_spi == FALSE) 
		{ 
		  die(mysql_error()); // TODO: better error handling
		}
	$row_spi = mysqli_fetch_assoc($run_query_spi);
?>
<title>Project TimeLine</title>
<link rel="shortcut icon" href="images/Federal Logo.jpg">
<link href="fonts/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<script src="js/pace.min.js"></script>
<script type="text/javascript" src="js/arrow78.js"></script>
<script type="text/javascript">	
		$(document).ready(function() {
			var options = {
				chart: {
					renderTo: 'timeline_progress',
					type: 'line'
				},
				title: {
					text: 'Physical / Financial Progress',
					style:{
                    color: '#3B5998',
                    fontSize: '18px'
                	}  
				},
				xAxis: {
					categories: [],
					labels: {
							style: {
									fontSize:'15px'
									}
								},
					title: {
						text: '<font style="color:#D9534F"> Note: Progress "-1" represents "PROGRESS NOT PROVIDED"</font>',
						style:{
                    		color: '#3B5998',
                    		fontSize: '16px'
                				}
					}
				},
				
				yAxis: {
					labels: {
						formatter: function () 
									{return this.value+' %';},
						style: {
									fontSize:'14px'
									
								}
							},
					title: {
						text: '<font style="color:#D9534F"> Percent Progress</font>',
						style:{
                    		color: '#3B5998',
                    		fontSize: '15px'
                				}
					}
				},

				 plotOptions: {
           			line: {
						  	dataLabels: {
                   			enabled: true,

							style: {
                        			fontWeight: 'bold',
									fontSize:'10px'
                   					 }
							},
					
				credits: {
    						enabled: false
  						 },
                enableMouseTracking: true
            			}
        		},
				series: []
			};
 
			$.get('json/timeline_progress.csv', function(data) {
				// Split the lines
				var lines = data.split('\n');
				$.each(lines, function(lineNo, line) {
					var items = line.split(',');
					
					// header line containes categories
					if (lineNo == 0) {
						$.each(items, function(itemNo, item) {
							if (itemNo > 0) options.xAxis.categories.push(item);
						});
					}
					// the rest of the lines contain data with their name in the first position
					else {
						var series = { 
							data: []
						};
						$.each(items, function(itemNo, item) {
							if (itemNo == 0 ) {
								series.name = item;
							} else {
								series.data.push(parseFloat(item));
							}
						});
						options.series.push(series);
						//options.dataLabels.enabled=true;
						options.credits=false;
						//options.dataLabels=true;

					}
					
				});
				var chart = new Highcharts.Chart(options);
						var item = chart.series[chart.series.length-1];
						item.options.showInLegend = false;
						item.legendItem = null;
						
					    chart.legend.destroyItem(item);
						chart.legend.render();
						
			});
		});
// Allocation , Releases & Expenditure Graphs
		$(document).ready(function() {
			var options = {
				chart: {
					renderTo: 'timeline_outlay',
					type: 'column'
				},
				title: {
					text: 'Financial Outlay (2016-17)',
					style:{
                    color: '#3B5998',
                    fontSize: '18px'
                	}  
				},
				xAxis: {
					categories: [],
					
					labels: {
							style: {
									fontSize:'15px'
									}
								}
					 
				},
				yAxis: {
					title: {
						text: 'in Millions',
						style:{
                    		color: '#3B5998',
                    		fontSize: '18px'
                				}
					}
				},
				 plotOptions: {
           			series: {
              			  	dataLabels: {
                   			enabled: true,
							style: {
                        			fontWeight: 'bold',
									fontSize:'14px'
                   					 }
                			},
				credits: {
    						enabled: false
  				},
                enableMouseTracking: true
            }
        },
				series: []
			};
 
			$.get('json/timeline_outlay.csv', function(data) {
				// Split the lines
				var lines = data.split('\n');
				$.each(lines, function(lineNo, line) {
					var items = line.split(',');
					
					// header line containes categories
					if (lineNo == 0) {
						$.each(items, function(itemNo, item) {
							if (itemNo > 0) options.xAxis.categories.push(item);
						});
					}
					// the rest of the lines contain data with their name in the first position
					else {
						var series = { 
							data: []
						};
						$.each(items, function(itemNo, item) {
							if (itemNo == 0 ) {
								series.name = item;
							} else {
								series.data.push(parseFloat(item));
							}
						});
						options.series.push(series);
						options.credits=false;
						//options.plotOptions.line.dataLabels.enabled=true;
						//options.xAxis.style.fontSize="18px";
					}
					
				});
				var chart = new Highcharts.Chart(options);
						var item = chart.series[chart.series.length-1];
						item.options.showInLegend = false;
						item.legendItem = null;
					    chart.legend.destroyItem(item);
						chart.legend.render();
			});
		});
		
// Speedometer
$(document).ready(function() {
	var speedColor = '#474337';
    var rpmColor = '#BBB59C';
    var kmhArr = [ 0, 20, 40, 60, 90, 120, 150, 180, 210 ];
    var hiRef = '#A41E09';
    var dialColor = '#FA3421';
    var currentRpm = 0;
	var speedColor = '#474337';
    $('#spi').highcharts({

        chart: {
            type: 'gauge',
            plotBackgroundColor: null,
            plotBackgroundImage: null,
            plotBorderWidth: 0,
            plotShadow: false
        },

        title: {
            text: 'Schedule Performance',
			style:{
                    		color: '#3B5998',
                    		fontSize: '18px'
                }
        },

       pane: {
            startAngle: -150,
            endAngle: 90,
            background: [{
                backgroundColor: {
                    linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                    stops: [
                        [0, '#FFF'],
                        [1, '#333']
                    ]
                },
                borderWidth: 0,
                outerRadius: '115%'
            }, {
                backgroundColor: {
                    linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                    stops: [
                        [0, '#333'],
                        [1, '#FFF']
                    ]
                },
                borderWidth: 1,
                outerRadius: '107%'
            }, {
                // default background
            }, {
               // BG color for rpm
                    backgroundColor: '#999',
                    outerRadius: '6%',
                    innerRadius: '5%'
            }]
        },
		credits: {
    						enabled: false
  				},
        // the value axis
        yAxis: {
            min: 0,
            max: 120,
			
                tickInterval: 5,
                tickLength: 7,
				tickWidth: 1.5,
                lineWidth: 1,
                lineColor: speedColor,
                tickColor: speedColor,
				tickPosition: 'outside',
                minorTickInterval: 2,
                minorTickLength: 10,
                minorTickWidth: .5,
				minorTickPosition: 'inside',
                minorTickColor: speedColor,
                endOnTick: false,
				
            labels: {
                step: 2,
                rotation: 'auto',
				style: {
                       fontFamily: 'Verdana',
                       fontSize: '14px',
					   color:'#474337',
					   offset:10
                       
                   }
            },
            title: {
                text: '% SP',
                    y: 100,
                    x: 0,
				style:{
                    color: '#3B5998',
                    fontSize: '18px'
					}
            },
            plotBands: [{
                from: 0,
                to: 60,
                color: '#DF5353' // red 
            }, {
                from: 60,
                to: 80,
                color: '#DDDF0D' // yellow
            }, {
                from: 80,
                to: 120,
                color: '#55BF3B' // green
            }]
        },

        series: [{
            name: 'SP',
            data: [0],
            tooltip: {
                valueSuffix: ' %'
            },
			dataLabels: 
				{
                    color:'#222',
                    borderWidth: 1,
                    y: -60,
                    x: 0,
                    style: {
                        fontSize: '18px'
                    		},
                    formatter: function() {
                        return this.y.toFixed(0);
                    					  }
                },
			dial: {
                    backgroundColor: dialColor,
                    baseLength: '70%',
                    baseWidth: 5,
                    radius: '80%',
                    topWidth: .2,
                    rearLength: '-7%',
                    borderColor: '#B17964',
                    borderWidth: 1
                }
				
        }]

    },
	
	
        // Add some life
        function (chart) {
			
            if (!chart.renderer.forExport) 	{
				var initial_value=0;
                var timer = setInterval(function () 		{
                    var point = chart.series[0].points[0],newVal,
                        inc = <?php echo $row_spi["speed"];?>
					
                    if (initial_value >= inc)
                        {
							clearInterval(timer);
							//initial_value=0;
						}
					else
						initial_value = initial_value +3;
						
                    point.update(initial_value);
					//
                								}, 200);
            								}
        				});
}); 

</script>

<div class="containter">
  <div class="row">
    <div class="col-lg-12">
      <h4 class="text-center hidden" id="project_name"><?php echo  $row_main["project_name"]?></h4>
      <h4 class="text-center hidden" id="psdp_number"><?php echo  "(2016-2017) PSDP No. ".$row_main["psdp_number"]?> <?php echo "<input type='button' class='btn btn-success' id='show_detail". $row_main["project_id"]."' value='Show Details' onclick= 'showdetail(".$row_main["project_id"].")' />"?> </h4>
    </div>
  </div>
  <div class="voffset1"></div>
  <div class="row align-center-div">
    <div class="col-lg-3 col-md-3 hidden" id="project_cost">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <div class="row">
            <div class="col-xs-3"> <i class="fa fa-money fa-4x"></i> </div>
            <div class="col-xs-9 text-right">
              <h3><?php echo "Rs. ".$row_main["project_cost"]; ?></h3>
              <div>Millions</div>
            </div>
          </div>
        </div>
        <a href="#">
        <div class="panel-footer"> <span class="pull-left">Project Cost</span> <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
          <div class="clearfix"></div>
        </div>
        </a> </div>
    </div>
    <div class="col-lg-3 col-md-3 hidden" id="revised_cost">
      <div class="panel panel-yellow">
        <div class="panel-heading">
          <div class="row">
            <div class="col-xs-3"> <i class="fa fa-money fa-4x"></i> </div>
            <div class="col-xs-9 text-right">
              <h3>
                <?php if (is_null($row_main["expected_completion_cost"]))
						echo "Not Revised";
					else
						echo "Rs. ".$row_main["expected_completion_cost"];  ?>
              </h3>
              <div>
                <?php if  (is_null($row_main["expected_completion_cost"]))
							echo "_";
						else if ($row_main["cost_over_run_formula"] < 0)
							echo "_";
                        else
                            echo "Millions";?>
              </div>
            </div>
          </div>
        </div>
        <a href="#">
        <div class="panel-footer"> <span class="pull-left">Project Revised Cost</span> <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
          <div class="clearfix"></div>
        </div>
        </a> </div>
    </div>
    <div class="col-lg-3 col-md-3 hidden" id="commencement_date">
      <div class="panel panel-green">
        <div class="panel-heading">
          <div class="row">
            <div class="col-xs-3"> <i class="fa fa-calendar fa-4x"></i> </div>
            <div class="col-xs-9 text-right">
              <h3><?php echo $row_main["commencement_date"]; ?></h3>
              <div> &nbsp</div>
            </div>
          </div>
        </div>
        <a href="#">
        <div class="panel-footer"> <span class="pull-left">Commencement Date</span> <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
          <div class="clearfix"></div>
        </div>
        </a> </div>
    </div>
    <div class="col-lg-3 col-md-3 hidden" id="completion_date">
      <div class="panel panel-red">
        <div class="panel-heading">
          <div class="row">
            <div class="col-xs-3"> <i class="fa fa-check-square fa-4x"></i> </div>
            <div class="col-xs-9 text-right">
              <h3><?php echo $row_main["expected_completion_date"]; ?> </h3>
              <div> &nbsp</div>
            </div>
          </div>
        </div>
        <a href="#">
        <div class="panel-footer"> <span class="pull-left">Completion Date</span> <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
          <div class="clearfix"></div>
        </div>
        </a> 
        </div>
    </div>
  </div>
  <div class="row align-center-div" >
    <div class="col-lg-3 col-md-3 hidden" id="cost_over_run">
      <div class="panel panel-gold">
        <div class="panel-heading">
          <div class="row">
            <div class="col-xs-3"> <i class="fa fa-line-chart fa-4x"></i> </div>
            <div class="col-xs-9 text-right">
              <h3>
                <?php if  (is_null($row_main["expected_completion_cost"]))
							echo "Not Revised";
						else if ($row_main["cost_over_run_formula"] < 0)
							echo "Not Cost Over Run";
						else
							echo "<span class='blink'>".$row_main["cost_over_run_formula"]."</span>"; ?>
              </h3>
              <div>
                <?php if  (is_null($row_main["expected_completion_cost"]))
							echo "_";
						else if ($row_main["cost_over_run_formula"] < 0)
							echo "_";
                        else
                            echo "Percent";?>
              </div>
            </div>
          </div>
        </div>
        <a href="#">
        <div class="panel-footer"> <span class="pull-left">Cost Over Run</span> <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
          <div class="clearfix"></div>
        </div>
        </a> </div>
    </div>
    <div class="col-lg-3 col-md-3 hidden" id="time_over_run">
      <div class="panel panel-maroon">
        <div class="panel-heading">
          <div class="row">
            <div class="col-xs-3"> <i class="fa fa-clock-o fa-4x"></i> </div>
            <div class="col-xs-9 text-right">
              <h3>
                <?php if ($row_main["time_over_run"] > 0)
						echo "<span class='blink'>".$row_main["time_over_run"]."</span>"; 
					else
						echo "On Time"; ?>
              </h3>
              <div> Months</div>
            </div>
          </div>
        </div>
        <a href="#">
        <div class="panel-footer"> <span class="pull-left">Time Over Run</span> <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
          <div class="clearfix"></div>
        </div>
        </a> </div>
    </div>
    <div class="col-lg-3 col-md-3 hidden" id="physical_progress">
      <div class="panel panel-gray">
        <div class="panel-heading">
          <div class="row">
            <div class="col-xs-3"> <i class="fa fa-cubes fa-4x"></i> </div>
            <div class="col-xs-9 text-right">
              <h3><?php echo $row_main["physical_progress"]; ?></h3>
              <div> Percent</div>
            </div>
          </div>
        </div>
        <a href="#">
        <div class="panel-footer"> <span class="pull-left">Physical Progress</span> <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
          <div class="clearfix"></div>
        </div>
        </a> </div>
    </div>
    <div class="col-lg-3 col-md-3 hidden" id="financial_progress">
      <div class="panel panel-purple">
        <div class="panel-heading">
          <div class="row">
            <div class="col-xs-3"> <i class="fa fa-pie-chart fa-4x"></i> </div>
            <div class="col-xs-9 text-right">
              <h3><?php echo $row_main["financial_progress"]; ?></h3>
              <div> Percent</div>
            </div>
          </div>
        </div>
        <a href="#">
        <div class="panel-footer"> <span class="pull-left">Financial Progress</span> <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
          <div class="clearfix"></div>
        </div>
        </a> </div>
    </div>
    
  </div>
  <div class="row">
    <div class="col-md-6">
      <div id="spi" class="align-center"> </div>
    </div>
    <div class="col-md-6">
      <div  id="timeline_outlay" class="align-center"> </div>
    </div>
  </div>
  <div class="voffset3"></div>
  <div class="row">
    <div class="col-md-12">
      <div id="timeline_progress" class="align-center"> </div>
    </div>
  </div>
</div>
<div class="voffset6"></div>
<?php include("footer.php");?>
<script>
function showdetail(incomingcall)
	{
	window.location="project_summary.php?projectid="+incomingcall;
	}

$(document).ready(function () 
{
	setTimeout(function(){
							$('#project_name').removeClass('hidden').addClass('animated bounceInLeft');
							$('#psdp_number').removeClass('hidden').addClass('animated bounceInRight');
						 },900); 
	
	setTimeout(function(){
							$('#project_cost').removeClass('hidden').addClass('animated bounceInLeft');
							$('#revised_cost').removeClass('hidden').addClass('animated bounceInRight');
							$('#commencement_date').removeClass('hidden').addClass('animated bounceInLeft');
							$('#completion_date').removeClass('hidden').addClass('animated bounceInRight');
							
							$('#cost_over_run').removeClass('hidden').addClass('animated bounceInLeft');
							$('#time_over_run').removeClass('hidden').addClass('animated bounceInRight');
							$('#physical_progress').removeClass('hidden').addClass('animated bounceInLeft');
							$('#financial_progress').removeClass('hidden').addClass('animated bounceInRight');

						 },1800); 

});
</script>
