<?php 
	error_reporting(0); // Turn off all error reporting
	if(session_status()!=PHP_SESSION_ACTIVE) 
		session_start();

if(!isset($_SESSION['username']) && !isset($_SESSION['email']))
	{
		header('location: index.php');
	}
include("include/connection.php");
include("header.php");
?>
<title>Select Project</title>
<link rel="shortcut icon" href="images/Federal Logo.jpg">
<link rel="stylesheet" type="text/css" href="css/datatable.css"/>
<link rel="stylesheet" type="text/css" href="css/jquery.dataTables.css"/>
<link rel="stylesheet" type="text/css" href="css/responsive.dataTables.min.css"/>
<!--<link rel="stylesheet" type="text/css" href="css/responsive.bootstrap.min.css"/>-->
<!--<link rel="stylesheet" type="text/css" href="css/buttons.dataTables.min.css"/>-->

<script src="js/pace.min.js"></script>
<script type="text/javascript" language="javascript" src="js/jquery.dataTables.min.js"></script>
<script type="text/javascript" language="javascript" src="js/dataTables.responsive.min.js"></script>
<!--<script type="text/javascript" language="javascript" src="js/dataTables.buttons.min.js"></script>
<script type="text/javascript" language="javascript" src="js/buttons.colVis.min.js"></script>-->

<script type="text/javascript" language="javascript" class="init">
		$(document).ready(function() 
		{
			 var table = $('#projects').DataTable({
				  
				  "aLengthMenu": [[10, 25, 50, 100, 500, -1], [10, 25, 50, 100, 500, "All"]],
				   responsive: true,
				  //"scrollX": true,
				  "oLanguage": {
						 		"sSearch": "Search on any field:",
								sLengthMenu: "Show _MENU_ Projects"
								}
				/* dom: 'Bfrtip', // To show columns manually
						buttons: [
							'colvis'
						],*/
			});
				
			 function format(value,value1) {
			 
			 return '<div class="slider"> <table cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;">'+
						'<tr>'+
							'<td>Updated By :</td>'+
							'<td>'+ value +'</td>'+
						'</tr>'+
						'<tr>'+
							'<td>Project Director Mobile:</td>'+
							'<td>'+ value1 +'</td>'+
						'</tr>'+
					'</table> </div>';
  			}
		 
			 
		
			  // Add event listener for opening and closing details
			  $('#projects').on('click', 'td.details-control', function () {
				  var tr = $(this).closest('tr');
				  var row = table.row(tr);
		
				  if (row.child.isShown()) {
					  // This row is already open - close it
					  $('div.slider', row.child()).slideUp( function () {
						row.child.hide();
						tr.removeClass('shown');
					} );
				  } else {
					  // Open this row
					  row.child(format(tr.data('child-value'),tr.data('child-value1'))).show();
					  tr.addClass('shown');
					  $('div.slider', row.child()).slideDown();
				  }
			  });
		  });
	 
	</script>

<div class="container">
  <div class="row">
    <div class="col-lg-12">
      <h3 class="text-center">
        <?php 
	
	if ($_GET['graph']=='Time Over Run Details')
	{
		
		echo "Projects Time Over Run <span class='text-danger'>".$_GET['graph_value']."</span> for <span class='text-danger'>".$_GET['graph_for']."</span> PSDP";
		echo "<br/>";
		if ($_GET['ministry']<>'0')
			echo "<span class='text-danger'> ".$_GET['ministry']."</span>";
		else
			if ($_GET['category']=='ministry')
				echo "<span class='text-danger'> "."All Ministries"."</span>";
			else if ($_GET['category']=='province')
				echo "<span class='text-danger'> "."All Provinces"."</span>";
			else if ($_GET['category']=='sector')
				echo "<span class='text-danger'> "."All Sectors"."</span>";
    }
	?>
      </h3>
      <div class="voffset4"></div>
    </div>
  </div>
  <div class="row">
    <div class="col-lg-12">
      <?php

$where_condition='';

if ($_GET['graph_value']=='N/A' && $_GET['graph_for']=='All')
	$where_condition=" and (isnull(COMPLETION_DATE)  or COMPLETION_DATE='0000-00-00' or COMPLETION_DATE='')";
else if ($_GET['graph_value']=='"'.'More than 3 Years'.'"' && $_GET['graph_for']=='All')
	$where_condition=" and round(timestampdiff(MONTH,  COMPLETION_DATE ,date_format(now(),'%Y%m%d')),0) > 36";	
else if ($_GET['graph_value']=='"'.'Bet. 1 to 3 Years'.'"' && $_GET['graph_for']=='All')
	$where_condition=" and round(timestampdiff(MONTH,  COMPLETION_DATE ,date_format(now(),'%Y%m%d')),0) between 13 and 36";	
else if ($_GET['graph_value']=='"'.'Less than Year'.'"' && $_GET['graph_for']=='All')
	$where_condition=" and round(timestampdiff(MONTH,  COMPLETION_DATE ,date_format(now(),'%Y%m%d')),0) between 1 and 12";		
else if ($_GET['graph_value']=='"'.'On Time'.'"' && $_GET['graph_for']=='All')
	$where_condition=" and round(timestampdiff(MONTH,  COMPLETION_DATE ,date_format(now(),'%Y%m%d')),0)<=0";	
else if ($_GET['graph_value']=='N/A' && $_GET['graph_for']=='CPEC')
	$where_condition=" and (ucase(PROJECT_NAME) like '%CPEC%') and (isnull(COMPLETION_DATE)  or COMPLETION_DATE='0000-00-00' or COMPLETION_DATE='')";
else if ($_GET['graph_value']=='"'.'More than 3 Years'.'"' && $_GET['graph_for']=='CPEC')
	$where_condition=" and (ucase(PROJECT_NAME) like '%CPEC%') and round(timestampdiff(MONTH,  COMPLETION_DATE ,date_format(now(),'%Y%m%d')),0) > 36";	
else if ($_GET['graph_value']=='"'.'Bet. 1 to 3 Years'.'"' && $_GET['graph_for']=='CPEC')
	$where_condition=" and (ucase(PROJECT_NAME) like '%CPEC%') and round(timestampdiff(MONTH,  COMPLETION_DATE ,date_format(now(),'%Y%m%d')),0) between 13 and 36";	
else if ($_GET['graph_value']=='"'.'Less than Year'.'"' && $_GET['graph_for']=='CPEC')
	$where_condition=" and (ucase(PROJECT_NAME) like '%CPEC%') and round(timestampdiff(MONTH,  COMPLETION_DATE ,date_format(now(),'%Y%m%d')),0) between 1 and 12";		
else if ($_GET['graph_value']=='"'.'On Time'.'"' && $_GET['graph_for']=='CPEC')
	$where_condition=" and (ucase(PROJECT_NAME) like '%CPEC%') and round(timestampdiff(MONTH,  COMPLETION_DATE ,date_format(now(),'%Y%m%d')),0)<=0";

if ($_GET['ministry'] <> '0')
	{
	if ($_GET['category']=='ministry')
		$stmt = "select project_id,project_name,
			ifnull(expected_completion_cost,project_cost) project_cost,
			psdp_number,dml_date,dml_time,projectid, ministry,physical_progress,project_director,contact_2,user_name,
			round(timestampdiff(MONTH,  COMPLETION_DATE ,date_format(now(),'%Y%m%d')),0)  time_over_run_value,
			for_month
			from tbl_project_summary a,userprojects b
			where a.project_id = b.projectid".$where_condition."
			and ministry="."'".$_GET['ministry']."'"."
			and username='".$_SESSION['username']."' and emailaddress='".$_SESSION['email']."'"." order by psdp_number ";
	else if ($_GET['category']=='sector')
			$stmt = "select project_id,project_name,
			ifnull(expected_completion_cost,project_cost) project_cost,
			psdp_number,dml_date,dml_time,projectid, ministry,physical_progress,project_director,contact_2,user_name,
			round(timestampdiff(MONTH,  COMPLETION_DATE ,date_format(now(),'%Y%m%d')),0)  time_over_run_value,
			for_month
			from tbl_project_summary a,userprojects b
			where a.project_id = b.projectid".$where_condition."
			and sector="."'".$_GET['ministry']."'"."
			and username='".$_SESSION['username']."' and emailaddress='".$_SESSION['email']."'"." order by psdp_number ";
	else if ($_GET['category']=='province')
			$stmt = "select project_id,project_name,
			ifnull(expected_completion_cost,project_cost) project_cost,
			psdp_number,dml_date,dml_time,projectid, ministry,physical_progress,project_director,contact_2,user_name,
			round(timestampdiff(MONTH,  COMPLETION_DATE ,date_format(now(),'%Y%m%d')),0)  time_over_run_value,
			for_month
			from tbl_project_summary a,userprojects b
			where a.project_id = b.projectid".$where_condition."
			and province="."'".$_GET['ministry']."'"."
			and username='".$_SESSION['username']."' and emailaddress='".$_SESSION['email']."'"." order by psdp_number ";
	}
else			
	$stmt = "select project_id,project_name,
		ifnull(expected_completion_cost,project_cost) project_cost,
		psdp_number,dml_date,dml_time,projectid, ministry,physical_progress,project_director,contact_2,user_name,
		round(timestampdiff(MONTH,  COMPLETION_DATE ,date_format(now(),'%Y%m%d')),0)  time_over_run_value,
		for_month
		from tbl_project_summary a,userprojects b
		where a.project_id = b.projectid".$where_condition."
		and username='".$_SESSION['username']."' and emailaddress='".$_SESSION['email']."'"." order by psdp_number ";

$run_query= $conn->query($stmt);
if($run_query == FALSE) 
				{ 
  				  die(mysql_error()); // TODO: better error handling
				}



echo "<table id='projects' class='display responsive' width='100%'>\n";
echo "<thead>\n";
echo "<tr>\n";
echo "<th class='dt-center all'>Options</th>\n";
echo "<th class='dt-center all'>PSDP# (2016-2017)</th>\n";
echo "<th class='dt-center min-tablet-l'>Ministry</th>\n";
echo "<th class='dt-center desktop'>Project Title</th>\n";
echo "<th class='dt-center min-mobile-l'>Project Cost</th>\n";
echo "<th class='dt-center all'>Time Over Run</th>\n";
echo "<th class='dt-center desktop'>Physical Progress</th>\n";
echo "<th class='desktop'></th>\n";
echo "</tr>\n";
echo "</thead>\n";
echo "<tbody>\n";

while ($row = mysqli_fetch_assoc($run_query))
 {
	 
echo "<tr data-child-value=".$row["user_name"]." data-child-value1= ".$row["contact_2"]."> \n";
echo " <td  align='center'>
<select name='actions' id='actions' style='width:90px' onchange='setValue(".$row["project_id"].",value)'>
		<option value='0' >Click Here</option>
		<option value='PRINT'>Print</option>
</select></td>\n";
        echo "<td align='center'>" . $row["psdp_number"] . "</td>\n";
		echo "<td>" . $row["ministry"] . "</td>\n";
		echo "<td>" . $row["project_name"] . "</td>\n";
		echo "<td align='center'>" . $row["project_cost"]  . "</td>\n";
		echo "<td align='center'>" . $row["time_over_run_value"] . "</td>\n";
		echo "<td align='center'>" .$row["physical_progress"] . "</td>\n";
		echo "<td align='center' class='details-control'></td>\n";
	    echo "</tr>";
	
}
echo "</tbody>";
echo "</table>";

?>
    </div>
  </div>
</div>
<div class="voffset6"></div>
<?php include("footer.php")?>
<script language="javascript" >
	function setValue(incomingcall,incomingoption)
	{
		if (incomingoption=='UPDATE')
			window.location="project_summary.php?projectid="+incomingcall ;
		else if (incomingoption=='HISTORY')
			window.location="project_history.php?projectid="+incomingcall ;
		else if (incomingoption=='TIMELINE')
			window.location="timeline.php?projectid="+incomingcall ;
		else if (incomingoption=='PRINT')
			window.location="one_pager.php?printprojectid="+incomingcall ;
	}	
</script>
