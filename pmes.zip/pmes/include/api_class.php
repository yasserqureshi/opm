<?php
#====================================FOR DETAILS CONTACT US
#	Office: FF-04, first floor, deans trade center, Peshawar cantt.
#	Phone: 091-5253258 | E-mail: Business@mcwnetwork.com
#====================================FOR DETAILS CONTACT US



#======================* START - Smile API Class

CLASS SMILE_API
{
	
	
	
function get_session()
{

$username="31";	#Put your API Username here
$password="yaseer@pnd8734";	#Put your API Password here
//$data=file_get_contents("http://api.smilesn.com/session?username=".$username."&password=".$password);

$ch = curl_init();
$timeout = 5; // set to zero for no timeout
curl_setopt ($ch, CURLOPT_URL, "http://api.smilesn.com/session?username=".$username."&password=".$password);
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
$content = curl_exec($ch);
//echo $content;
curl_close($ch);

$data=json_decode($content);
$sessionid=$data->sessionid;


$file2 = fopen('session.txt', 'w');

$file1 = fopen('session.txt', 'a');
fputs($file1, $sessionid);
fclose($file1);

return $sessionid;
}
	


function send_sms($receivenum, $sendernum, $textmessage)
{
$receivenum=urlencode($receivenum);
$sendernum=urlencode($sendernum);
$textmessage=urlencode($textmessage);


$session_file = file("session.txt");
$session_id = trim($session_file[0]);

if(empty($session_id))
{
$session_id = $this->get_session();
}

//$data=file_get_contents("http://api.smilesn.com/sendsms?sid=".$session_id."&receivenum=".$receivenum."&sendernum=8583&textmessage=".$textmessage);

$ch = curl_init();
$timeout = 5; // set to zero for no timeout
curl_setopt ($ch, CURLOPT_URL, "http://api.smilesn.com/sendsms?sid=".$session_id."&receivenum=".$receivenum."&sendernum=8583&textmessage=".$textmessage);
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
$content = curl_exec($ch);
//echo $content;
curl_close($ch);

$data2=json_decode($content);

$response_status=$data2->status;

#=====* START - IF SESSION EXPIRED IS RETURN, GENERATE ANOTHER SESSION & RETRY
if($response_status=="SESSION_EXPIRED")
{
$session_id = $this->get_session();
//$data=file_get_contents("http://api.smilesn.com/sendsms?sid=".$session_id."&receivenum=".$receivenum."&sendernum=8583&textmessage=".$textmessage);
$ch = curl_init();
$timeout = 5; // set to zero for no timeout
curl_setopt ($ch, CURLOPT_URL, "http://api.smilesn.com/sendsms?sid=".$session_id."&receivenum=".$receivenum."&sendernum=8583&textmessage=".$textmessage);
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
$content = curl_exec($ch);

curl_close($ch);
}
#=====* END - IF SESSION EXPIRED IS RETURN, GENERATE ANOTHER SESSION & RETRY

return $content;
}



function receive_sms()
{
$session_file = file("session.txt");
$session_id = trim($session_file[0]);

if(empty($session_id))
{
$session_id = $this->get_session();
}

$data=file_get_contents("http://api.smilesn.com/receivesms?sid=".$session_id);

$data2=json_decode($data);
$response_status=$data2->status;


#=====* START - IF SESSION EXPIRED IS RETURN, GENERATE ANOTHER SESSION & RETRY
if($response_status=="SESSION_EXPIRED")
{
$session_id = $this->get_session();
$data=file_get_contents("http://api.smilesn.com/receivesms?sid=".$session_id);
}
#=====* END - IF SESSION EXPIRED IS RETURN, GENERATE ANOTHER SESSION & RETRY


return $data;
}

/**
 * 
 * function to check quota
 * void()
 * 
 * */
 function getQuota()
 {
    $session_file = file("session.txt");
    $session_id = trim($session_file[0]);

    if(empty($session_id))
    {
        $session_id = $this->get_session();
    }
    $quota = file_get_contents('http://api.smilesn.com/check_quota?sid='.$session_id);
    $quota = json_decode($quota);
    if($quota->status == 'SESSION_EXPIRED')
    {
        $session_id = $this->get_session();
        $quota = file_get_contents('http://api.smilesn.com/check_quota?sid='.$session_id);
        $quota = json_decode($quota);
    }
    switch($quota->status)
    {
        case 'QUOTA_EXPIRED':
            return 'Quota expired';
        break;
        case 'LIMIT_REACHED':
            return 'Sms limit reached';
        break;
    }
    if(preg_match('/^[0-9]+$/', $quota->status))
    {
        return 'Remaining sms: '.$quota->status;
    }
    return $quota->status;
 }
	
}
#======================* END - Smile API Class

$object_smile_api = new SMILE_API();
?>