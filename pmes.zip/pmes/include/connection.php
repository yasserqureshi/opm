<?php
$host = "localhost";
$user = "root";
$pwd = "";
$db = "pmes";
/*$host = "localhost";
$user = "psdp_pmes";
$pwd = "ORaclE..79";
$db = "psdp_pmes";*/
$conn = mysqli_connect($host,$user,$pwd,$db);
?>