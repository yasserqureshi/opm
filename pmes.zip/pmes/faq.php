<?php 
	error_reporting(0); // Turn off all error reporting
	if(session_status()!=PHP_SESSION_ACTIVE) 
		session_start();
	include("header.php");
?>
<link rel="shortcut icon" href="images/FederalLogo.jpg">
<script src="js/pace.min.js"></script>
<script type="text/javascript" src="js/arrow78.js"></script>
<title> Frequently Asked Questions </title>
<div class="container">
  <div class="row">
    <div class="col-lg-12">
      <div class="page-header">
        <h3 class="text-center">Frequently Asked Questions</h3>
      </div>
      <table class="table table-striped table-hover">
        <tr>
          <td style=" color:#34495E; font-weight:bold"> Q 1) What is One Pager Web Application? </td>
        </tr>
        <tr>
          <td style="color:#34495E"> A 1) One Pager Web Application is a newly developed module by MIS Section, Projects Wing to streamline the process of projects' progresses updation and reporting for Prime Minister's Office, Parliamentary bodies and Public Accounts Committee. The module's data has been initially updated from PMES database. <br />
            <br /></td>
        </tr>
        <tr>
          <td style="color:#34495E; font-weight:bold"> Q 2) How can I login into One Pager Web Application ? </td>
        </tr>
        <tr>
          <td style="color:#34495E"> A 2) For accessing One Pager Web Application you need PMES's username and PMES's Email ID. Every PMES's user has stored an Email address in the User Profile Section. This Email address will be used along with PMES's username to access One Pager Web Application. (to  get to know your password, please see the USER MANUAL)<br />
            <br /></td>
        </tr>
        <tr>
          <td style=" color:#34495E; font-weight:bold"> Q 3) I don't remember my Email ID and Username for PMES ? </td>
        </tr>
        <tr>
          <td style="color:#34495E"> A 3) Please visit Contact Us page and contact the concerned DPS for your PMES's username and Email ID. <br />
            <br /></td>
        </tr>
        <tr>
          <td style="color:#34495E; font-weight:bold"> Q 4) Why I need One Pager Web Application if I am updating project progress on PMES regularly ? </td>
        </tr>
        <tr>
          <td style="color:#34495E"> A 4) 
            One  pager module provides an updated information in a brief form regarding the  status of the project on monthly basis where as PMES encompasses the detailed  information (component wise progress). <br />
            <br /></td>
        </tr>
        <tr>
          <td style="color:#34495E; font-weight:bold"> Q 5) Do I have to update regularly ? </td>
        </tr>
        <tr>
          <td style="color:#34495E"> A 5) YES. You have to update your project's progress regularly on monthly basis by 7th of following month. For example you have to update April-2015 progress till 7th of May, 2015. If we will not receive any progress update from your side, the last updated  status of progress details of your project will be reported assuming that no  progress has been made since the last reported progress<br />
            <br /></td>
        </tr>
        <tr>
          <td style=" color:#34495E; font-weight:bold"> Q 8) How many images required to be uploaded ? </td>
        </tr>
        <tr>
          <td style="color:#34495E"> A 8) You can upload upto 3 images at a time for any single month. <br />
            <br /></td>
        </tr>
        <tr>
          <td style=" color:#34495E; font-weight:bold"> Q 9) What size and type of the images can be uploaded ? </td>
        </tr>
        <tr>
          <td style="color:#34495E"> A 9) Image with JPEG or GIF extensions having size not more than 512 KB. (0.5 MB) <br />
            <br /></td>
        </tr>
        <tr>
          <td style=" color:#34495E; font-weight:bold"> Q 10) How can I redudce image size ? </td>
        </tr>
        <tr>
          <td style="color:#34495E"> A 10) You can reduce image size by using MS Paint or any other image optimizer software. Also you can use online software like <a href="http://www.reduceimages.com" target="_blank"> Resize Your Image </a> <br />
            <br /></td>
        </tr>
        <tr>
          <td style=" color:#34495E; font-weight:bold"> Q 11) Can I get a print out of the the project data ? </td>
        </tr>
        <tr>
          <td style="color:#34495E"> A 11) YES. You can print your project's progress data from the Project Search page. <br />
            <br /></td>
        </tr>
      </table>
    </div>
  </div>
</div>
<?php include("footer.php");?>
