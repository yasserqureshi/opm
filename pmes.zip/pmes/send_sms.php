<title>Send SMS</title>
<?php include("header.php");?>
<div class="container">
<div class="row">
<div class="col-md-12">
  <?php
	error_reporting(0); // Turn off all error reporting
	include('include/connection.php');
	date_default_timezone_set("Asia/Karachi");
	$username_for_sms=mysqli_real_escape_string($conn,$_GET['username_for_sms']);
	$mobile_for_sms=mysqli_real_escape_string($conn,$_GET['mobile_for_sms']);
	
	$stmt = "select emailaddress from users
			 where username='$username_for_sms'";	

	$run_query= $conn->query($stmt);
				if($run_query == FALSE) 
				{ 
  				  die(mysql_error()); // TODO: better error handling
				}


			if ($row_sms=mysqli_fetch_assoc($run_query))
			{
				require("include/api_class.php");
				$obj = new SMILE_API();
				$mobile_number = preg_replace("/-/", '',$mobile_for_sms);
				$var_session=$obj->get_session();
				if ($username_for_sms == 'master' || $username_for_sms == 'one_pager')
					{
						$var_result=$obj->send_sms($mobile_number,"8583","You are not allowed to access ".$username_for_sms." user.");
					}
				else  
					{
						$var_result=$obj->send_sms($mobile_number,"8583","Login credential for One Pager Module. Username: ".$username_for_sms." Email: ".$row_sms['emailaddress']." URL: www.psdp.net/pmes ");
						//echo $var_result;
						$stmt_insert="insert into tbl_message (mobile,dml_date,dml_time,status,user_name) values ("."'".$mobile_number."',"."STR_TO_DATE("."'".date("d-m-Y")."'".",'%d-%m-%Y')".","."'".date("h:i")."',"."'".$var_result."'".",'".$username_for_sms."')";
						$run_query_insert= $conn->query($stmt_insert);
					}
			?>
  <div class="alert alert-success alert-dismissible text-center" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    <h3 class="text-center"> SMS Sent to <strong> <?php echo $_GET['mobile_for_sms'];?> </strong> </h3>
    <br/>
    <h4 class="text-center">If you have received your PMES Email Address via SMS then </h4>
  </div>
  <h5 class="text-center">
    <button type="button" class="btn btn-success btn-lg" onclick="return login()">Login</button>
    Again </h5>
  <?php
		}
		else
		{?>
  <div class="voffset3"></div>
  <div class="alert alert-danger alert-dismissible text-center" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
    Sorry Username <strong><?php echo $_GET['username_for_sms'];?></strong> is not valid. Please provide valid Username or Call 0321-9131997 </div>
  <h3 class="text-center">
    <div class="voffset5"></div>
    Back to
    <button type="button" class="btn btn-success btn-group-lg" onclick="return login()">Login</button>
  </h3>
  <?php }?>
</div>
<!-- /container -->
<?php include("footer.php");?>
<script>

function login()
{
	window.location="index.php" ;
}

</script>