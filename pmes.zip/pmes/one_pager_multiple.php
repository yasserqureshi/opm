<?php
error_reporting(0); // Turn off all error reporting
	if(session_status()!=PHP_SESSION_ACTIVE) 
		session_start();
		
	if(!isset($_SESSION['username']))
			header('location: index.php');


include('include/connection.php');
$printprojectid=mysqli_real_escape_string($conn,$_GET['printprojectid'])+0;

$stmt = "select psdp_number,project_name,ministry,forum,objective,scope,progress_remarks,reason_cost_over_run benifits,
		 reason_time_over_run delay_reason,
		 case approval_date
		 when '0000-00-00' then '-'
		 else date_format(approval_date,'%d-%m-%Y')
		 end approval_date,
		 case revised_approval_date
		 when '0000-00-00' then '-'
		 else date_format(revised_approval_date,'%d-%m-%Y')
		 end revised_approval_date,
		 project_cost,
		 expected_completion_cost,expenditure_upto,expenditure,allocation,releases,release_upto,
		 round((((ifnull(EXPENDITURE_UPTO,0) + ifnull(EXPENDITURE,0)) * 100) / ifnull(EXPECTED_COMPLETION_COST,PROJECT_COST)),0) financial_progress ,
		 progress_remarks,reason_cost_over_run,issue,
		 case commencement_date
		 when '0000-00-00' then '-'
		 else date_format(commencement_date,'%d-%m-%Y')
		 end commencement_date,
		 case completion_date
		 when '0000-00-00' then '-'
		 else date_format(completion_date,'%d-%m-%Y')
		 end completion_date,
		 case revised_completion_date
		 when '0000-00-00' then '-'
		 else date_format(revised_completion_date,'%d-%m-%Y')
		 end revised_completion_date,
		 case expected_completion_date
		 when '0000-00-00' then '-'
		 else date_format(expected_completion_date,'%d-%m-%Y')
		 end expected_completion_date,
		 physical_progress,
		 case 
		 when TIMESTAMPDIFF(MONTH, completion_date, date_format(now(), '%Y%m%d')) <=0 then '-'
		 else  TIMESTAMPDIFF(MONTH, completion_date, date_format(now(), '%Y%m%d'))
		 end time_over_run,
		 reason_time_over_run,
		 case 
		 when expected_completion_cost IS NULL then '-'
		 else round((ifnull(expected_completion_cost,0)-ifnull(project_cost,0))/project_cost*100) 
		 end cost_over_run_formula,
		 for_month,
		 for_year,
		 project_director,
		 contact_1,
		 contact_2,
		 email,
		 user_name,
		 dml_date															
		 from tbl_project_summary
		 where psdp_number in (756,771,806,818,819,871,872,873,949,954)
		 order by psdp_number";

$run_query= $conn->query($stmt);
if($run_query == FALSE) 
				{ 
  				  die(mysql_error()); // TODO: better error handling
				}

if (PHP_SAPI == 'cli')
	die('This example should only be run from a Web Browser');

/** Include PHPExcel */
//require_once('Classes/PHPExcel.php');
require_once dirname(__FILE__) . '/Classes/PHPExcel.php';

// Create new PHPExcel object
$objPHPExcel = new PHPExcel();

// Set document properties
$objPHPExcel->getProperties()->setCreator("Yasser H. Qureshi")
							 ->setLastModifiedBy("Yasser H. Qureshi")
							 ->setTitle("One Pager Module Report")
							 ->setSubject("One Pager")
							 ->setDescription("This report is generated from One Pager Module.")
							 ->setCategory("One Pager");
							 
$styleThinBlackBorderOutline = array(
	'borders' => array(
		'outline' => array(
			'style' => PHPExcel_Style_Border::BORDER_THIN,
			'color' => array('argb' => 'FF000000'),
		),
	),
);



$counter=0;

while ($row = mysqli_fetch_assoc($run_query))
{
// Set active sheet index to the first sheet, so Excel opens this as the first sheet
$objPHPExcel->setActiveSheetIndex($counter);


// Set Margains
$objPHPExcel->getActiveSheet()->getPageMargins()->setTop(.75);
$objPHPExcel->getActiveSheet()->getPageMargins()->setRight(.4);
$objPHPExcel->getActiveSheet()->getPageMargins()->setLeft(.4);
$objPHPExcel->getActiveSheet()->getPageMargins()->setBottom(.5);

$objPHPExcel->getActiveSheet()->getPageSetup()->setHorizontalCentered(true);
//$objPHPExcel->getActiveSheet()->getPageSetup()->setVerticalCentered(true);

$objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_PORTRAIT);
$objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);


// Set Header and Footer
//$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddHeader('&C&H&25 One Pager');
$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddFooter('&L&B'.$objPHPExcel->getProperties()->getTitle().'&I&CPrinting Date: &D (&T) '.'&RPage &P of &N');	
	
$objPHPExcel->getActiveSheet()->getHeaderFooter()->setOddHeader('&C&H&18'."PSDP No (2016-2017): ".$row["psdp_number"]);

$objPHPExcel->getActiveSheet()->mergeCells('A1:J1');
//$objPHPExcel->getActiveSheet()->getRowDimension('1')->setRowHeight(20);
$objPHPExcel->getActiveSheet()->getStyle('A1:J1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A1:J1')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A1:J1')->getFont()->setSize(16);

//Project Name Title
$objPHPExcel->getActiveSheet()->getRowDimension('2')->setRowHeight(30);
$objPHPExcel->getActiveSheet()->mergeCells('A2:C2');
$objPHPExcel->getActiveSheet()->getStyle('A2:C2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A2:C2')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A2:C2')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A2:C2')->getFont()->setBold(true);
// Project Name
$objPHPExcel->getActiveSheet()->mergeCells('D2:J2');
$objPHPExcel->getActiveSheet()->getStyle('D2:J2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('D2:J2')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D2:J2')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D2:J2')->getAlignment()->setWrapText(true);

// Ministry Name Title
$objPHPExcel->getActiveSheet()->mergeCells('A3:C3');
$objPHPExcel->getActiveSheet()->getStyle('A3:C3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A3:C3')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A3:C3')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A3:C3')->getFont()->setBold(true);
// Ministry Name 
$objPHPExcel->getActiveSheet()->mergeCells('D3:J3');
$objPHPExcel->getActiveSheet()->getStyle('D3:J3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('D3:J3')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D3:J3')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D3:J3')->getAlignment()->setWrapText(true);

// Objective Title
$objPHPExcel->getActiveSheet()->mergeCells('A4:C4');
$objPHPExcel->getActiveSheet()->getStyle('A4:C4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A4:C4')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A4:C4')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A4:C4')->getFont()->setBold(true);
// Objective
$objPHPExcel->getActiveSheet()->mergeCells('D4:J4');
$objPHPExcel->getActiveSheet()->getStyle('D4:J4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('D4:J4')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D4:J4')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D4:J4')->getAlignment()->setWrapText(true);

// Scope Title
$objPHPExcel->getActiveSheet()->mergeCells('A5:C5');
$objPHPExcel->getActiveSheet()->getStyle('A5:C5')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A5:C5')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A5:C5')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A5:C5')->getFont()->setBold(true);
// Scope
$objPHPExcel->getActiveSheet()->mergeCells('D5:J5');
$objPHPExcel->getActiveSheet()->getStyle('D5:J5')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('D5:J5')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D5:J5')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D5:J5')->getAlignment()->setWrapText(true);

// Forum Title
$objPHPExcel->getActiveSheet()->mergeCells('A6:C6');
$objPHPExcel->getActiveSheet()->getStyle('A6:C6')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A6:C6')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A6:C6')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A6:C6')->getFont()->setBold(true);
// Forum
$objPHPExcel->getActiveSheet()->mergeCells('D6:J6');
$objPHPExcel->getActiveSheet()->getStyle('D6:J6')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D6:J6')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D6:J6')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D6:J6')->getAlignment()->setWrapText(true);

// Approval Date Title
$objPHPExcel->getActiveSheet()->mergeCells('A7:C8');
$objPHPExcel->getActiveSheet()->getStyle('A7:C8')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A7:C8')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A7:C8')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A7:C8')->getFont()->setBold(true);
// Approval Date Title
$objPHPExcel->getActiveSheet()->mergeCells('D7:F7');
$objPHPExcel->getActiveSheet()->getStyle('D7:F7')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D7:F7')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D7:F7')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D7:F7')->getAlignment()->setWrapText(true);
$objPHPExcel->getActiveSheet()->getStyle('D7:F7')->getFont()->setBold(true);
// Revised Approval Date Title
$objPHPExcel->getActiveSheet()->mergeCells('G7:J7');
$objPHPExcel->getActiveSheet()->getStyle('G7:J7')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('G7:J7')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('G7:J7')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('G7:J7')->getAlignment()->setWrapText(true);
$objPHPExcel->getActiveSheet()->getStyle('G7:J7')->getFont()->setBold(true);
// Approval Date Value
$objPHPExcel->getActiveSheet()->mergeCells('D8:F8');
$objPHPExcel->getActiveSheet()->getStyle('D8:F8')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D8:F8')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D8:F8')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D8:F8')->getAlignment()->setWrapText(true);
// Revised Approval Date Value
$objPHPExcel->getActiveSheet()->mergeCells('G8:J8');
$objPHPExcel->getActiveSheet()->getStyle('G8:J8')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('G8:J8')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('G8:J8')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('G8:J8')->getAlignment()->setWrapText(true);


// Cost Title
$objPHPExcel->getActiveSheet()->mergeCells('A9:C11');
$objPHPExcel->getActiveSheet()->getStyle('A9:C11')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A9:C11')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A9:C11')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A9:C11')->getFont()->setBold(true);
// Cost Title
$objPHPExcel->getActiveSheet()->mergeCells('D9:F9');
$objPHPExcel->getActiveSheet()->getStyle('D9:F9')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D9:F9')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D9:F9')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D9:F9')->getAlignment()->setWrapText(true);
$objPHPExcel->getActiveSheet()->getStyle('D9:F9')->getFont()->setBold(true);
// Revised Cost Title
$objPHPExcel->getActiveSheet()->mergeCells('G9:J9');
$objPHPExcel->getActiveSheet()->getStyle('G9:J9')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('G9:J9')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('G9:J9')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('G9:J9')->getAlignment()->setWrapText(true);
$objPHPExcel->getActiveSheet()->getStyle('G9:J9')->getFont()->setBold(true);
// Cost / FEC / Total Label
$objPHPExcel->getActiveSheet()->getStyle('D10')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D10')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D10')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D10')->getAlignment()->setWrapText(true);

$objPHPExcel->getActiveSheet()->getStyle('E10')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('E10')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('E10')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('E10')->getAlignment()->setWrapText(true);

$objPHPExcel->getActiveSheet()->getStyle('F10')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('F10')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('F10')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('F10')->getAlignment()->setWrapText(true);
// Cost / FEC / Total Value
$objPHPExcel->getActiveSheet()->getStyle('D11')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D11')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D11')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D11')->getAlignment()->setWrapText(true);

$objPHPExcel->getActiveSheet()->getStyle('E11')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('E11')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('E11')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('E11')->getAlignment()->setWrapText(true);

$objPHPExcel->getActiveSheet()->getStyle('F11')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('F11')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('F11')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('F11')->getAlignment()->setWrapText(true);

// Revised Cost / FEC / Total Label
$objPHPExcel->getActiveSheet()->getStyle('G10')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('G10')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('G10')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('G10')->getAlignment()->setWrapText(true);

$objPHPExcel->getActiveSheet()->getStyle('H10')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('H10')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('H10')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('H10')->getAlignment()->setWrapText(true);

$objPHPExcel->getActiveSheet()->mergeCells('I10:J10');
$objPHPExcel->getActiveSheet()->getStyle('I10:J10')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('I10:J10')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('I10:J10')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('I10:J10')->getAlignment()->setWrapText(true);

// Revised Cost / FEC / Total Value
$objPHPExcel->getActiveSheet()->getStyle('G11')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('G11')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('G11')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('G11')->getAlignment()->setWrapText(true);

$objPHPExcel->getActiveSheet()->getStyle('H11')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('H11')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('H11')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('H11')->getAlignment()->setWrapText(true);

$objPHPExcel->getActiveSheet()->mergeCells('I11:J11');
$objPHPExcel->getActiveSheet()->getStyle('I11:J11')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('I11:J11')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('I11:J11')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('I11:J11')->getAlignment()->setWrapText(true);

// Commencement Date Title
$objPHPExcel->getActiveSheet()->mergeCells('A12:C12');
$objPHPExcel->getActiveSheet()->getStyle('A12:C12')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A12:C12')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A12:C12')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A12:C12')->getFont()->setBold(true);
// Commencement Date
$objPHPExcel->getActiveSheet()->mergeCells('D12:J12');
$objPHPExcel->getActiveSheet()->getStyle('D12:J12')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D12:J12')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D12:J12')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D12:J12')->getAlignment()->setWrapText(true);

// Completion Date Title
$objPHPExcel->getActiveSheet()->mergeCells('A13:C13');
$objPHPExcel->getActiveSheet()->getStyle('A13:C13')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A13:C13')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A13:C13')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A13:C13')->getFont()->setBold(true);
// Completion Date
$objPHPExcel->getActiveSheet()->mergeCells('D13:J13');
$objPHPExcel->getActiveSheet()->getStyle('D13:J13')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D13:J13')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D13:J13')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D13:J13')->getAlignment()->setWrapText(true);

// Revised Completion Date Title
$objPHPExcel->getActiveSheet()->mergeCells('A14:C14');
$objPHPExcel->getActiveSheet()->getStyle('A14:C14')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A14:C14')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A14:C14')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A14:C14')->getFont()->setBold(true);
// Revised Completion Date
$objPHPExcel->getActiveSheet()->mergeCells('D14:J14');
$objPHPExcel->getActiveSheet()->getStyle('D14:J14')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D14:J14')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D14:J14')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D14:J14')->getAlignment()->setWrapText(true);

// Expected Completion Date Title
$objPHPExcel->getActiveSheet()->mergeCells('A15:C15');
$objPHPExcel->getActiveSheet()->getStyle('A15:C15')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A15:C15')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A15:C15')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A15:C15')->getFont()->setBold(true);
// Expected Completion Date
$objPHPExcel->getActiveSheet()->mergeCells('D15:J15');
$objPHPExcel->getActiveSheet()->getStyle('D15:J15')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D15:J15')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D15:J15')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D15:J15')->getAlignment()->setWrapText(true);

// Time Over Run Title
$objPHPExcel->getActiveSheet()->mergeCells('A16:C16');
$objPHPExcel->getActiveSheet()->getStyle('A16:C16')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A16:C16')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A16:C16')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A16:C16')->getFont()->setBold(true);
// Time Over Run Value
$objPHPExcel->getActiveSheet()->mergeCells('D16:J16');
$objPHPExcel->getActiveSheet()->getStyle('D16:J16')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D16:J16')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D16:J16')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D16:J16')->getAlignment()->setWrapText(true);

// Cost Over Run Title
$objPHPExcel->getActiveSheet()->mergeCells('A17:C17');
$objPHPExcel->getActiveSheet()->getStyle('A17:C17')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A17:C17')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A17:C17')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A17:C17')->getFont()->setBold(true);
// Cost Over Run Value
$objPHPExcel->getActiveSheet()->mergeCells('D17:J17');
$objPHPExcel->getActiveSheet()->getStyle('D17:J17')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D17:J17')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D17:J17')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D17:J17')->getAlignment()->setWrapText(true);

// Reason Cost Over Title
$objPHPExcel->getActiveSheet()->mergeCells('A18:C18');
$objPHPExcel->getActiveSheet()->getStyle('A18:C18')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A18:C18')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A18:C18')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A18:C18')->getFont()->setBold(true);
//  Reason Cost Over  Value
$objPHPExcel->getActiveSheet()->mergeCells('D18:J18');
$objPHPExcel->getActiveSheet()->getStyle('D18:J18')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('D18:J18')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D18:J18')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D18:J18')->getAlignment()->setWrapText(true);

// Allocation Title
$objPHPExcel->getActiveSheet()->mergeCells('A19:C19');
$objPHPExcel->getActiveSheet()->getStyle('A19:C19')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A19:C19')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A19:C19')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A19:C19')->getFont()->setBold(true);
// Allocation
$objPHPExcel->getActiveSheet()->mergeCells('D19:J19');
$objPHPExcel->getActiveSheet()->getStyle('D19:J19')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D19:J19')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D19:J19')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D19:J19')->getAlignment()->setWrapText(true);

// Releases Last FY Title
$objPHPExcel->getActiveSheet()->mergeCells('A20:C20');
$objPHPExcel->getActiveSheet()->getStyle('A20:C20')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A20:C20')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A20:C20')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A20:C20')->getFont()->setBold(true);
// Releases Last FY
$objPHPExcel->getActiveSheet()->mergeCells('D20:J20');
$objPHPExcel->getActiveSheet()->getStyle('D20:J20')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D20:J20')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D20:J20')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D20:J20')->getAlignment()->setWrapText(true);

// Expenditure Last FY Title
$objPHPExcel->getActiveSheet()->mergeCells('A21:C21');
$objPHPExcel->getActiveSheet()->getStyle('A21:C21')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A21:C21')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A21:C21')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A21:C21')->getFont()->setBold(true);
// Expenditure Last FY
$objPHPExcel->getActiveSheet()->mergeCells('D21:J21');
$objPHPExcel->getActiveSheet()->getStyle('D21:J21')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D21:J21')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D21:J21')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D21:J21')->getAlignment()->setWrapText(true);

// Releases Current  FY Title
$objPHPExcel->getActiveSheet()->mergeCells('A22:C22');
$objPHPExcel->getActiveSheet()->getStyle('A22:C22')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A22:C22')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A22:C22')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A22:C22')->getFont()->setBold(true);
// Releases Current FY
$objPHPExcel->getActiveSheet()->mergeCells('D22:J22');
$objPHPExcel->getActiveSheet()->getStyle('D22:J22')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D22:J22')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D22:J22')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D22:J22')->getAlignment()->setWrapText(true);

// Expenditure Current  FY Title
$objPHPExcel->getActiveSheet()->mergeCells('A23:C23');
$objPHPExcel->getActiveSheet()->getStyle('A23:C23')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A23:C23')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A23:C23')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A23:C23')->getFont()->setBold(true);
// Expenditure Current FY
$objPHPExcel->getActiveSheet()->mergeCells('D23:J23');
$objPHPExcel->getActiveSheet()->getStyle('D23:J23')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D23:J23')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D23:J23')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D23:J23')->getAlignment()->setWrapText(true);

// Physical Progress Title
$objPHPExcel->getActiveSheet()->mergeCells('A24:C24');
$objPHPExcel->getActiveSheet()->getStyle('A24:C24')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A24:C24')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A24:C24')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A24:C24')->getFont()->setBold(true);
// Physical Progress
$objPHPExcel->getActiveSheet()->mergeCells('D24:J24');
$objPHPExcel->getActiveSheet()->getStyle('D24:J24')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D24:J24')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D24:J24')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D24:J24')->getAlignment()->setWrapText(true);

// Financial Progress Title
$objPHPExcel->getActiveSheet()->mergeCells('A25:C25');
$objPHPExcel->getActiveSheet()->getStyle('A25:C25')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A25:C25')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A25:C25')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A25:C25')->getFont()->setBold(true);

// Fincancial Progress
$objPHPExcel->getActiveSheet()->mergeCells('D25:J25');
$objPHPExcel->getActiveSheet()->getStyle('D25:J25')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D25:J25')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D25:J25')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D25:J25')->getAlignment()->setWrapText(true);

// Major Work Done Title
$objPHPExcel->getActiveSheet()->mergeCells('A26:C26');
$objPHPExcel->getActiveSheet()->getStyle('A26:C26')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A26:C26')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A26:C26')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A26:C26')->getFont()->setBold(true);
// Major Work Done
$objPHPExcel->getActiveSheet()->mergeCells('D26:J26');
$objPHPExcel->getActiveSheet()->getStyle('D26:J26')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('D26:J26')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D26:J26')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D26:J26')->getAlignment()->setWrapText(true);

// Benifits Title
$objPHPExcel->getActiveSheet()->mergeCells('A27:C27');
$objPHPExcel->getActiveSheet()->getStyle('A27:C27')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A27:C27')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A27:C27')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A27:C27')->getFont()->setBold(true);
// Benifits
$objPHPExcel->getActiveSheet()->mergeCells('D27:J27');
$objPHPExcel->getActiveSheet()->getStyle('D27:J27')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('D27:J27')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D27:J27')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D27:J27')->getAlignment()->setWrapText(true);

// PD Name Title
$objPHPExcel->getActiveSheet()->mergeCells('A29:C29');
$objPHPExcel->getActiveSheet()->getStyle('A29:C29')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A29:C29')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A29:C29')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A29:C29')->getFont()->setBold(true);
// PD Name Value
$objPHPExcel->getActiveSheet()->mergeCells('D29:J29');
$objPHPExcel->getActiveSheet()->getStyle('D29:J29')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D29:J29')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D29:J29')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D29:J29')->getAlignment()->setWrapText(true);

// Contact 1 Title
$objPHPExcel->getActiveSheet()->mergeCells('A30:C30');
$objPHPExcel->getActiveSheet()->getStyle('A30:C30')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A30:C30')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A30:C30')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A30:C30')->getFont()->setBold(true);
// Contact 1 Value
$objPHPExcel->getActiveSheet()->mergeCells('D30:J30');
$objPHPExcel->getActiveSheet()->getStyle('D30:J30')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D30:J30')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D30:J30')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D30:J30')->getAlignment()->setWrapText(true);

// Contact 2 Title
$objPHPExcel->getActiveSheet()->mergeCells('A31:C31');
$objPHPExcel->getActiveSheet()->getStyle('A31:C31')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A31:C31')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A31:C31')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A31:C31')->getFont()->setBold(true);
// Contact 2 Value
$objPHPExcel->getActiveSheet()->mergeCells('D31:J31');
$objPHPExcel->getActiveSheet()->getStyle('D31:J31')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D31:J31')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D31:J31')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D31:J31')->getAlignment()->setWrapText(true);

// Email Title
$objPHPExcel->getActiveSheet()->mergeCells('A32:C32');
$objPHPExcel->getActiveSheet()->getStyle('A32:C32')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A32:C32')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A32:C32')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A32:C32')->getFont()->setBold(true);
// Email Value
$objPHPExcel->getActiveSheet()->mergeCells('D32:J32');
$objPHPExcel->getActiveSheet()->getStyle('D32:J32')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D32:J32')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D32:J32')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D32:J32')->getAlignment()->setWrapText(true);

// Username Title
$objPHPExcel->getActiveSheet()->mergeCells('A33:C33');
$objPHPExcel->getActiveSheet()->getStyle('A33:C33')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A33:C33')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A33:C33')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A33:C33')->getFont()->setBold(true);
// Username Value
$objPHPExcel->getActiveSheet()->mergeCells('D33:J33');
$objPHPExcel->getActiveSheet()->getStyle('D33:J33')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D33:J33')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D33:J33')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D33:J33')->getAlignment()->setWrapText(true);

// DML Title
$objPHPExcel->getActiveSheet()->mergeCells('A34:C34');
$objPHPExcel->getActiveSheet()->getStyle('A34:C34')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
$objPHPExcel->getActiveSheet()->getStyle('A34:C34')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('A34:C34')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('A34:C34')->getFont()->setBold(true);
// DML Value
$objPHPExcel->getActiveSheet()->mergeCells('D34:J34');
$objPHPExcel->getActiveSheet()->getStyle('D34:J34')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D34:J34')->getAlignment()->setVertical(PHPExcel_Style_Alignment::VERTICAL_CENTER);
$objPHPExcel->getActiveSheet()->getStyle('D34:J34')->applyFromArray($styleThinBlackBorderOutline);
$objPHPExcel->getActiveSheet()->getStyle('D34:J34')->getAlignment()->setWrapText(true);


$objPHPExcel->setActiveSheetIndex($counter)
				->setCellValue('A1',"Project Progress Proforma - ".$row["for_month"]." / ".$row["for_year"])
				//->setCellValue('A2',"For the Month of ". $row["for_month"]." - ".$row["for_year"])
				->setCellValue('A2',"Project Name")
				->setCellValue('D2',$row["project_name"])
				->setCellValue('A3',"Ministry")
				->setCellValue('D3',$row["ministry"])
				->setCellValue('A4',"Objectives")
				->setCellValue('D4',$row["objective"])
				->setCellValue('A5',"Scope")
				->setCellValue('D5',$row["scope"])
				->setCellValue('A6',"Approval Forum")
				->setCellValue('D6',$row["forum"])
				->setCellValue('A7',"Approval Date")
				->setCellValue('D7',"Original")
				->setCellValue('G7',"Revised")
				->setCellValue('D8',$row["approval_date"])
				->setCellValue('G8',$row["revised_approval_date"])
				->setCellValue('A9',"Cost (Rs. Million)")
				->setCellValue('D9',"Original")
				->setCellValue('G9',"Revised")
				//->setCellValue('D10',"Local")
				//->setCellValue('E10',"FEC")
				->setCellValue('F10',"Total")
				//->setCellValue('G10',"Local")
				//->setCellValue('H10',"FEC")
				->setCellValue('I10',"Total")
				//->setCellValue('D11',$row["project_cost"])
				//->setCellValue('E11',"-")
				->setCellValue('F11',$row["project_cost"])
				//->setCellValue('G11',$row["expected_completion_cost"])
				//->setCellValue('H11',"-")
				->setCellValue('I11',$row["expected_completion_cost"])
				->setCellValue('A12',"Commencement Date")
				->setCellValue('D12',$row["commencement_date"])
				->setCellValue('A13',"Completion Date")
				->setCellValue('D13',$row["completion_date"])
				->setCellValue('A14',"Revised Completion Date")
				->setCellValue('D14',$row["revised_completion_date"])
				->setCellValue('A15',"Expected Completion Date")
				->setCellValue('D15',$row["expected_completion_date"])
				->setCellValue('A16',"Time Over Run (months)")
				->setCellValue('D16',$row["time_over_run"])
				->setCellValue('A17',"Cost Over Run (%)")
				->setCellValue('D17',$row["cost_over_run_formula"])
				->setCellValue('A18',"Reason Time / Cost Over Run")
				->setCellValue('D18',$row["reason_time_over_run"])
				->setCellValue('A19',"Allocation (2016-17)")
				->setCellValue('D19',$row["allocation"])
				->setCellValue('A20',"Releases upto Last FY")
				->setCellValue('D20',$row["release_upto"])
				->setCellValue('A21',"Expenditure upto Last FY")
				->setCellValue('D21',$row["expenditure_upto"])
				->setCellValue('A22',"Releases Current FY")
				->setCellValue('D22',$row["releases"])
				->setCellValue('A23',"Expenditures Current FY")
				->setCellValue('D23',$row["expenditure"])
				->setCellValue('A24',"Physical Progress (%)")
				->setCellValue('D24',$row["physical_progress"])
				->setCellValue('A25',"Financial Progress (%)")
				->setCellValue('D25',$row["financial_progress"])
				->setCellValue('A26',"Major Work Done")
				->setCellValue('D26',$row["progress_remarks"])
				->setCellValue('A27',"Benefits")
				->setCellValue('D27',$row["reason_cost_over_run"])
				->setCellValue('A29',"Project Director")
				->setCellValue('D29',$row["project_director"])
				->setCellValue('A30',"Contact 1")
				->setCellValue('D30',$row["contact_1"])
				->setCellValue('A31',"Contact 2")
				->setCellValue('D31',$row["contact_2"])
				->setCellValue('A32',"Email Address")
				->setCellValue('D32',$row["email"])
				->setCellValue('A33',"Last Updated By")
				->setCellValue('D33',$row["user_name"])
				->setCellValue('A34',"Updated On")
				->setCellValue('D34',$row["dml_date"]);

// Row Auto Height
if (strlen($row["objective"]) < 100)
	$objPHPExcel->getActiveSheet()->getRowDimension(4)->setRowHeight(32);
elseif (strlen($row["objective"]) > 100 && strlen($row["objective"]) < 550)
	$objPHPExcel->getActiveSheet()->getRowDimension(4)->setRowHeight(round(strlen($row["objective"])/3,2));
elseif (strlen($row["objective"]) > 550 && strlen($row["objective"]) < 700)
	$objPHPExcel->getActiveSheet()->getRowDimension(4)->setRowHeight(round(strlen($row["objective"])/3.25,2));
elseif (strlen($row["objective"]) > 700 && strlen($row["objective"]) < 900)
	$objPHPExcel->getActiveSheet()->getRowDimension(4)->setRowHeight(round(strlen($row["objective"])/3.5,2));
elseif (strlen($row["objective"]) > 900 )
	$objPHPExcel->getActiveSheet()->getRowDimension(4)->setRowHeight(round(strlen($row["objective"])/3.75,2));
	
if (strlen($row["scope"]) < 100)
	$objPHPExcel->getActiveSheet()->getRowDimension(5)->setRowHeight(32);
elseif (strlen($row["scope"]) > 100 && strlen($row["scope"]) < 550)
	$objPHPExcel->getActiveSheet()->getRowDimension(5)->setRowHeight(round(strlen($row["scope"])/3,2));
elseif (strlen($row["scope"]) > 550 && strlen($row["scope"]) < 700)
	$objPHPExcel->getActiveSheet()->getRowDimension(5)->setRowHeight(round(strlen($row["scope"])/3.25,2));
elseif (strlen($row["scope"]) > 700 && strlen($row["scope"]) < 900)
	$objPHPExcel->getActiveSheet()->getRowDimension(5)->setRowHeight(round(strlen($row["scope"])/3.5,2));
elseif (strlen($row["scope"]) > 900 )
	$objPHPExcel->getActiveSheet()->getRowDimension(5)->setRowHeight(round(strlen($row["scope"])/3.75,2));

if (strlen($row["progress_remarks"]) < 100)
	$objPHPExcel->getActiveSheet()->getRowDimension(26)->setRowHeight(32);
elseif (strlen($row["progress_remarks"]) > 100 && strlen($row["progress_remarks"]) < 550)
	$objPHPExcel->getActiveSheet()->getRowDimension(26)->setRowHeight(round(strlen($row["progress_remarks"])/3,2));
elseif (strlen($row["progress_remarks"]) > 550 && strlen($row["progress_remarks"]) < 700)
	$objPHPExcel->getActiveSheet()->getRowDimension(26)->setRowHeight(round(strlen($row["progress_remarks"])/3.25,2));
elseif (strlen($row["progress_remarks"]) > 700 && strlen($row["progress_remarks"]) < 900)
	$objPHPExcel->getActiveSheet()->getRowDimension(26)->setRowHeight(round(strlen($row["progress_remarks"])/3.5,2));
elseif (strlen($row["progress_remarks"]) > 900 )
	$objPHPExcel->getActiveSheet()->getRowDimension(26)->setRowHeight(round(strlen($row["progress_remarks"])/3.75,2));
	
if (strlen($row["reason_cost_over_run"]) < 100)
	$objPHPExcel->getActiveSheet()->getRowDimension(27)->setRowHeight(32);
elseif (strlen($row["reason_cost_over_run"]) > 100 && strlen($row["reason_cost_over_run"]) < 550)
	$objPHPExcel->getActiveSheet()->getRowDimension(27)->setRowHeight(round(strlen($row["reason_cost_over_run"])/3,2));
elseif (strlen($row["reason_cost_over_run"]) > 550 && strlen($row["reason_cost_over_run"]) < 700)
	$objPHPExcel->getActiveSheet()->getRowDimension(27)->setRowHeight(round(strlen($row["reason_cost_over_run"])/3.25,2));
elseif (strlen($row["reason_cost_over_run"]) > 700 && strlen($row["reason_cost_over_run"]) < 900)
	$objPHPExcel->getActiveSheet()->getRowDimension(27)->setRowHeight(round(strlen($row["reason_cost_over_run"])/3.5,2));
elseif (strlen($row["reason_cost_over_run"]) > 900 )
	$objPHPExcel->getActiveSheet()->getRowDimension(27)->setRowHeight(round(strlen($row["reason_cost_over_run"])/3.75,2));



if (strlen($row["reason_time_over_run"]) < 100)
	$objPHPExcel->getActiveSheet()->getRowDimension(18)->setRowHeight(32);
elseif (strlen($row["reason_time_over_run"]) > 100 && strlen($row["reason_time_over_run"]) < 550)
	$objPHPExcel->getActiveSheet()->getRowDimension(18)->setRowHeight(round(strlen($row["reason_time_over_run"])/3,2));
elseif (strlen($row["reason_time_over_run"]) > 550 && strlen($row["reason_time_over_run"]) < 700)
	$objPHPExcel->getActiveSheet()->getRowDimension(18)->setRowHeight(round(strlen($row["reason_time_over_run"])/3.25,2));
elseif (strlen($row["reason_time_over_run"]) > 700 && strlen($row["reason_time_over_run"]) < 900)
	$objPHPExcel->getActiveSheet()->getRowDimension(18)->setRowHeight(round(strlen($row["reason_time_over_run"])/3.5,2));
elseif (strlen($row["reason_time_over_run"]) > 900 )
	$objPHPExcel->getActiveSheet()->getRowDimension(18)->setRowHeight(round(strlen($row["reason_time_over_run"])/3.75,2));	
// Rename worksheet
$objPHPExcel->getActiveSheet()->setTitle($row["psdp_number"]);

$counter=$counter+1;

// Add new sheet
$objWorkSheet = $objPHPExcel->createSheet($counter); //Setting index when creating


}



$objPHPExcel->removeSheetByIndex($counter); //Setting index when creating


// Set fonts
//$objPHPExcel->getActiveSheet()->getStyle('A1:R'.$counter)->getFont()->setName('Calibri');
//$objPHPExcel->getActiveSheet()->getStyle('A1:R'.$counter)->getFont()->setSize(10);




// Redirect output to a client’s web browser (Excel5)
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="One Pager.xls"');
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');

// If you're serving to IE over SSL, then the following may be needed
header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT +5:00'); // always modified
header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
header ('Pragma: public'); // HTTP/1.0

$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('php://output');
exit;

?>