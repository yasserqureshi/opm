<?php include("header.php");?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
$host = "localhost";
$user = "root";
$pwd = "";
$db = "pmes";
$conn = mysqli_connect($host,$user,$pwd,$db);
mysqli_set_charset($conn,"utf8");
$run_query= $conn->query("SELECT * FROM books");
while($row=mysqli_fetch_assoc($run_query))
{
echo $row['id']; // Book id 
echo $row['name']."<br/>"; // Book title
}


if(isset($_POST['book_name']))
{
	echo 1;
	$stmt_insert="insert into books values (2,"."'".$_POST['book_name']."')";
	$run_query_insert= $conn->query($stmt_insert);
}

?>


<form id="feedback_form" method="POST" name="feedback_form"  enctype="multipart/form-data">
اپنا نام لکھیں  <input type="text" id="book_name" name="book_name" />

<button type="button" onclick="return check_empty()">Send Feedback</button>
</form>
</body>
</html>
<script>
function check_empty(){
	
$('#feedback_form').submit();
}
</script>