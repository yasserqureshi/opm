<link rel="shortcut icon" href="images/FederalLogo.jpg">
<?php 
error_reporting(0); // Turn off all error reporting
if(session_status()!=PHP_SESSION_ACTIVE) 
	session_start();
date_default_timezone_set("Asia/Karachi");
if(!isset($_SESSION['username']))
	header('location: index.php');
include('include/connection.php');
include("header.php");
$transactionid=mysqli_real_escape_string($conn,$_GET['transaction_id'])+0;
$stmt = "select forum,date_format(approval_date,'%d-%m-%Y') approval_date,
		 project_status, project_id, project_name, ministry, objective, project_cost, 
		 expected_completion_cost, date_format(commencement_date,'%d-%m-%Y') commencement_date, 
		 date_format(completion_date,'%d-%m-%Y') completion_date, 
		 date_format(expected_completion_date,'%d-%m-%Y') expected_completion_date, for_month, for_year, 
		 psdp_number, allocation, release_upto, releases, release_remarks, expenditure_upto, expenditure, 
		 expenditure_remarks, physical_progress, progress_remarks, cost_over_run, reason_cost_over_run,
		 time_over_run,reason_time_over_run,issue, image_path_1, image_path_2, image_path_3, 
		 project_director, contact_1, contact_2, fiscal_year,date_format(entry_date,'%d-%m-%Y') entry_date, 
		 date_format(revised_approval_date,'%d-%m-%Y') revised_approval_date,
		 date_format(revised_completion_date,'%d-%m-%Y') revised_completion_date, 
		 dml_date,dml_time,user_name,scope,funding,email from tbl_project_history where transaction_id=".$transactionid;

$run_query= $conn->query($stmt);
if ($run_query->num_rows > 0)
		{
			$row = mysqli_fetch_assoc($run_query);
		}
		else
		{
			echo "<font style='color:#F00; font-style:italic; font-size:20px'>";
			die("Fata Error-00215! Unable to execute query. Please contact Director-MIS (0321-9131997).");
			echo "</font>";
		}

?>
<title>One Pager Form</title>
<script src="js/pace.min.js"></script>
<script type="text/javascript" src="js/arrow78.js"></script>
<div class="container">
  <div class="row">
    <div class="page-header">
      <h4 class="text-center text-danger"><?php echo  $row["project_name"];?></h4>
    </div>
  </div>
  <div class="voffset3"></div>
  <form id="update_form" name="update_form" class="form-horizontal" method="post" role="form" enctype="multipart/form-data" >
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Project ID</label>
      <div class="col-sm-2">
        <input class="form-control" id="project_id" name="project_id" value="<?php echo $row["project_id"]; ?>" readonly />
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">PSDP Number</label>
      <div class="col-sm-2">
        <input class="form-control" id="psdp_number" name="psdp_number" value="<?php echo $row["psdp_number"]; ?>" readonly />
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Ministry</label>
      <div class="col-sm-9">
        <input class="form-control" id="ministry" name="ministry" value="<?php echo $row["ministry"];?>" readonly />
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Last Progress for Month- Year</label>
      <div class="col-sm-3">
        <input class="form-control" value="<?php echo $row["for_month"].' - '.$row["for_year"];?>" readonly />
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Objectives</label>
      <div class="col-sm-9">
        <textarea class="form-control" rows="4" id="objective" name="objective" readonly> <?php echo $row["objective"];  ?></textarea>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Scope</label>
      <div class="col-sm-9">
        <textarea class="form-control" rows="2" id="scope" name="scope" readonly><?php echo $row["scope"];  ?></textarea>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Project Cost</label>
      <div class="col-sm-3">
        <div class="input-group">
          <input class="form-control" name="project_cost" id="project_cost" value="<?php echo $row["project_cost"]; ?>" aria-describedby="project_cost" readonly/>
          <span class="input-group-addon">Rs. in Millions</span> </div>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Project Revised Cost</label>
      <div class="col-sm-3">
        <div class="input-group">
          <input class="form-control"   name="expected_completion_cost" id="expected_cost" value="<?php echo $row["expected_completion_cost"]; ?>" aria-describedby="revised_cost" readonly/>
          <span class="input-group-addon">Rs. in Millions</span> </div>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Forum</label>
      <div class="col-sm-3">
        <input class="form-control" name="forum" id="forum" value="<?php echo $row["forum"]; ?>"  readonly/>
      </div>
    </div>
    <div class="form-group">
    <label class="col-sm-3 control-label text-right">Approval Date</label>
    <div class="col-sm-2">
      <input class="form-control" id="approval_date" name="approval_date" value="<?php echo $row["approval_date"]; ?>" readonly  />
    </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Revised Approval Date </label>
      <div class="col-sm-2">
        <input class="form-control" id="revised_approval_date" name="revised_approval_date" value="<?php echo $row["revised_approval_date"]; ?>"  readonly />
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Commencement Date</label>
      <div class="col-sm-2">
        <input class="form-control" id="commencement_date" name="commencement_date" value="<?php echo $row["commencement_date"]; ?>" readonly />
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Completion Date</label>
      <div class="col-sm-2">
        <input class="form-control" id="completion_date" name="completion_date" value="<?php echo  $row["completion_date" ]; ?>" readonly />
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Revised Completion Date </label>
      <div class="col-sm-2">
        <input class="form-control" id="revised_completion_date" name="revised_completion_date" value="<?php echo $row["revised_completion_date"]; ?>"  readonly />
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Expected Completion Date</label>
      <div class="col-sm-2">
        <input class="form-control" id="expected_completion_date" name="expected_completion_date" value="<?php echo  $row["expected_completion_date"]; ?>" readonly />
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Allocation in FY 2016-17</label>
      <div class="col-sm-3">
        <div class="input-group">
          <input class="form-control"  name="allocation" id="allocation" value="<?php echo  $row["allocation"];  ?>" aria-describedby="allocation" readonly />
          <span class="input-group-addon">Rs. in Millions</span> </div>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Releases upto June, 2016</label>
      <div class="col-sm-3">
        <div class="input-group">
          <input class="form-control" name="release_upto" id="release_upto"   value="<?php echo  $row["release_upto"]; ?>" aria-describedby="release_upto" readonly />
          <span class="input-group-addon">Rs. in Millions</span> </div>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Releases in FY 2016-17</label>
      <div class="col-sm-3">
        <div class="input-group">
          <input class="form-control" name="release" id="release" value="<?php echo  $row["releases"]; ?>" aria-describedby="release" readonly />
          <span class="input-group-addon">Rs. in Millions</span> </div>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Any Remarks for Releases</label>
      <div class="col-sm-9">
        <textarea class="form-control" rows="2" id="release_remarks" name="release_remarks" readonly><?php echo  $row["release_remarks"];?></textarea>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Expenditures upto June, 2016</label>
      <div class="col-sm-3">
        <div class="input-group">
          <input class="form-control" name="expenditure_upto" id="expenditure_upto" value="<?php echo  $row["expenditure_upto"]; ?>" aria-describedby="expenditure_upto" readonly />
          <span class="input-group-addon">Rs. in Millions</span> </div>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Expenditures in FY 2016-17</label>
      <div class="col-sm-3">
        <div class="input-group">
          <input class="form-control" name="expenditure" id="expenditure" value="<?php echo  $row["expenditure"]; ?>" aria-describedby="expenditure" readonly/>
          <span class="input-group-addon">Rs. in Millions</span> </div>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Any Remarks for Expenditures</label>
      <div class="col-sm-9">
        <textarea class="form-control" rows="2" id="expenditure_remarks" name="expenditure_remarks" readonly><?php echo  $row["expenditure_remarks"]; ?></textarea>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Overall Physical Progress</label>
      <div class="col-sm-2">
        <div class="input-group">
          <input class="form-control" name="physical_progress"  id="physical_progress" value="<?php echo  $row["physical_progress"]; ?>" aria-describedby="physical_progress" readonly/>
          <span class="input-group-addon">%</span> </div>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Major Work Done</label>
      <div class="col-sm-9">
        <textarea class="form-control" rows="2" id="progress_remarks" name="progress_remarks" readonly><?php echo  $row["progress_remarks"];  ?></textarea>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Benefits</label>
      <div class="col-sm-9">
        <textarea class="form-control" rows="2" id="reason_cost_over_run" name="reason_cost_over_run" readonly><?php echo  $row["reason_cost_over_run"];  ?></textarea>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Reason for Delay / Cost Over Run</label>
      <div class="col-sm-9">
        <textarea class="form-control" rows="2" id="reason_time_over_run" name="reason_time_over_run" readonly><?php echo  $row["reason_time_over_run"]; ?></textarea>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Bottlenecks / Any Other Issue</label>
      <div class="col-sm-9">
        <textarea class="form-control" rows="2" id="issue" name="issue" readonly><?php echo  $row["issue"]; ?></textarea>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">
      Image 1 <br/>
      </label>
      <div class="col-sm-6">
        <input class="form-control" type="hidden" readonly   id="image_path_1" name="image_path_1" value=<?php echo  $row["image_path_1"]  ?>   />
        <img src="uploaded/<?php echo  $row["image_path_1"]  ?>" width="100" height="100"/>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right"> Image 2 <br/>
      </label>
      <div class="col-sm-6">
        <input class="form-control" type="hidden" readonly   id="image_path_2" name="image_path_2" value=<?php echo  $row["image_path_2"]  ?>  />
        <img src="uploaded/<?php echo  $row["image_path_2"]  ?>" width="100" height="100"/>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right"> Image 3 <br/>
      </label>
      <div class="col-sm-6">
        <input class="form-control" type="hidden" readonly   id="image_path_3" name="image_path_3" value=<?php echo  $row["image_path_3"]  ?>  />
        <img src="uploaded/<?php echo  $row["image_path_3"]  ?>" width="100" height="100"/>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Project Director</label>
      <div class="col-sm-3">
        <input class="form-control" name="project_director"  id="project_director"  value="<?php echo  $row["project_director"]; ?>" readonly/>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Office Telephone</label>
      <div class="col-sm-3">
        <input class="form-control" name="contact_1"  id="contact_1" value="<?php echo  $row["contact_1"]; ?>" aria-describedby="contact_1" readonly />
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Mobile</label>
      <div class="col-sm-3">
        <input class="form-control" name="contact_2"  id="contact_2"  value="<?php echo  $row["contact_2"]; ?>" aria-describedby="contact_2" readonly/>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Email</label>
      <div class="col-sm-3">
        <input class="form-control" name="email"  id="email" value="<?php echo  $row["email"];  ?>" readonly/>
      </div>
    </div>
    <div class="form-group">
      <div class="col-sm-3"> </div>
      <div class="col-sm-2"> <?php echo "<input type='button' class='btn btn-success' id='value". $row["project_id"]."' value='Back to Historical Data' onclick= 'setValue(".$row["project_id"].")' />";?> </div>
    </div>
  </form>
</div>
<div class="voffset5"></div>
<?php include("footer.php");?>
<script language="javascript" >
	function setValue(incomingcall)
	{
	window.location="project_history.php?projectid="+incomingcall ;
	
	}	
</script>