<?php
	error_reporting(0); // Turn off all error reporting
	if(session_status()!=PHP_SESSION_ACTIVE) 
		session_start();
	include('include/connection.php');
	date_default_timezone_set("Asia/Karachi");

	$stmt_updated_today="select count(*) total from tbl_project_summary
								where dml_date=DATE_FORMAT(CURRENT_DATE,'%Y-%m-%d')"; 
	$run_query_updated_today= $conn->query($stmt_updated_today);
	if($run_query_updated_today == FALSE) 
		{ 
		  die(mysql_error()); // TODO: better error handling
		}
	$row_updated_today = mysqli_fetch_assoc($run_query_updated_today);
	
	$stmt_updated_week="select count(*) total from tbl_project_summary
							  where dml_date between  DATE_FORMAT(CURRENT_DATE - INTERVAL 8 DAY,'%Y-%m-%d') and DATE_FORMAT(CURRENT_DATE - INTERVAL 1 DAY,'%Y-%m-%d')"; 
	$run_query_updated_week= $conn->query($stmt_updated_week);
	if($run_query_updated_week == FALSE) 
		{ 
		  die(mysql_error()); // TODO: better error handling
		}
	$row_updated_week = mysqli_fetch_assoc($run_query_updated_week);
	
	
	
	$output2 = fopen('json/monthly_progress.csv', 'w');
	// output the column headings
	fputcsv($output2, array('Category', 'Jul', 'Aug','Sept','Oct','Nov','Dec','Jan','Feb','Mar','Apr','May','Jun'));
	
	$stmt_monthly_progress = "SELECT 'One Pager Progress',
				count(case when for_month='JULY' then for_month end) 'Jul 2016',
				count(case when for_month='AUGUST' then for_month end) 'Aug 2016',
				count(case when for_month='SEPTEMBER' then for_month end) 'Sept 2016',
				count(case when for_month='OCTOBER' then for_month end) 'Oct 2016',
				count(case when for_month='NOVEMBER' then for_month end) 'Nov 2016',
				count(case when for_month='DECEMBER' then for_month end) 'Dec 2016',
				count(case when for_month='JANUARY' then for_month end) 'Jan 2017',
				count(case when for_month='FEBRUARY' then for_month end) 'Feb 2017',
				count(case when for_month='MARCH' then for_month end) 'Mar 2017',
				count(case when for_month='APRIL' then for_month end) 'Apr 2017',
				count(case when for_month='MAY' then for_month end) 'May 2017',
				count(case when for_month='JUNE' then for_month end) 'Jun 2017'
				FROM tbl_project_summary
				union all
				SELECT 'PMES Progress',
				count(case when for_month='JULY' then for_month end) 'Jul 2016',
				count(case when for_month='AUGUST' then for_month end) 'Aug 2016',
				count(case when for_month='SEPTEMBER' then for_month end) 'Sept 2016',
				count(case when for_month='OCTOBER' then for_month end) 'Oct 2016',
				count(case when for_month='NOVEMBER' then for_month end) 'Nov 2016',
				count(case when for_month='DECEMBER' then for_month end) 'Dec 2016',
				count(case when for_month='JANUARY' then for_month end) 'Jan 2017',
				count(case when for_month='FEBRUARY' then for_month end) 'Feb 2017',
				count(case when for_month='MARCH' then for_month end) 'Mar 2017',
				count(case when for_month='APRIL' then for_month end) 'Apr 2017',
				count(case when for_month='MAY' then for_month end) 'May 2017',
				count(case when for_month='JUNE' then for_month end) 'Jun 2017'
				FROM tbl_project_summary_pmes ";		
				
	$run_query_monthly_progress= $conn->query($stmt_monthly_progress);
	
	// loop over the rows, outputting them
	while ($row_monthly_progress=mysqli_fetch_assoc($run_query_monthly_progress)) 
		fputcsv($output2, $row_monthly_progress);
	
	fclose($output2);
	
?>
<script src="js/d3.v3.min.js" language="JavaScript"></script>
<script src="js/liquidFillGauge.js" language="JavaScript"></script>

<style>
		.box {
			background: none repeat scroll 0 0 #fff;
			border: 1px solid #d8d8d8;
			border-radius: 7px 7px 7px 7px;
			box-shadow: 0 4px 5px #d3d3d3;
			margin: 5px auto;
			padding: 0px 5px 5px;
			position: relative;
			min-height: 200px;
		}
		
		.center {
				margin: auto;
				width: 80%;
				padding: 2px;
			}
</style>
<div class="voffset2"></div>
<div class="container"> 
  <!--<div class="row">
    <div class="col-md-10">
      <div id="speedometer"> </div>
      <h4 class="text-center" id="formula"> <a href="images/Formula.jpg" target="new"> How it's Calculated ? </a></h4>
      <!--<h4 class="text-center" id="formula"> <a href="http://www.psdp.net/pmes_2015-2016" target="new"><span class="blink"> To access One Pager Module for PSDP 2015-16</span> </a></h4> 
    </div>
  </div>-->
  <div class="row">
    <div class="col-md-9">
      <div id="monthly_progress"> </div>
    </div>
    <div class="col-md-3">
      <div class="row">
        <div class="col-md-12 box"> 
        <div class="voffset2"></div>
        <h5 class="text-center text-primary">Projects Updated Today </h5>
			<div class="voffset2"></div>
			<svg style="center" id="fillgauge1" width="100%" height="90%" ></svg> </div>
      </div>
      <div class="row">
      
        <div class="col-md-12 box"> 
		  <div class="voffset2"></div>
        <h5 class="text-center text-primary">Projects Updated Last Week </h5>
			<div class="voffset2"></div>
			<svg id="fillgauge2" width="100%" height="90%" ></svg> </div>
      </div>
    </div>
  </div>
</div>
<script>
		var updated_today=<?php echo $row_updated_today["total"];?>;
		
		var updated_week=<?php echo $row_updated_week["total"];?>;
		
		var config1 = liquidFillGaugeDefaultSettings();
		config1.circleThickness = 0.1;
		config1.textVertPosition = .5;
		config1.waveAnimateTime = 5000;
		config1.waveHeight = .15;
		config1.waveAnimate = true;
		config1.waveOffset = 0.25;
		config1.valueCountUp = true;
		config1.displayPercent = false;
		var gauge1= loadLiquidFillGauge("fillgauge1",updated_today ,config1);
		
		
		
		var config2 = liquidFillGaugeDefaultSettings();
		config2.circleThickness = 0.1;
		config2.textVertPosition = 0.5;
		config2.waveAnimateTime = 3000;
		config2.waveHeight = 0.15;
		config2.waveAnimate = true;
		config2.waveOffset = 0.8;
		config2.valueCountUp = true;
		config2.displayPercent = false;		
		var gauge2 = loadLiquidFillGauge("fillgauge2", updated_week,config2);

	 
$(document).ready(function () 
{
//Highcharts
var options = {
				chart: {
					renderTo: 'monthly_progress',
					type: 'line'
				},
				title: {
					text: 'Progress Updated Month Wise Against 1013 Projects <br>in PSDP 2016-17',
					style:{
                    color: '#34495E',
                    fontSize: '18px'
                	}  
				},
				xAxis: {
					categories: [],
					labels: {
							style: {
									fontSize:'13px'
									}
								}
				},
				
				yAxis: {
					title: {
						text: 'No of Projects',
						style:{
                    		color: '#F00',
                    		fontSize: '14px'
                				}
					}
				},
				 plotOptions: {
           			line: {
						  	dataLabels: {
                   			enabled: true
							},
					
				credits: {
    						enabled: false
  						 },
                enableMouseTracking: true
            			}
          		},
				series: []
			};
 
			$.get('json/monthly_progress.csv', function(data) {
				// Split the lines
				var lines = data.split('\n');
				$.each(lines, function(lineNo, line) {
					var items = line.split(',');
					
					// header line containes categories
					if (lineNo == 0) {
						$.each(items, function(itemNo, item) {
							if (itemNo > 0) options.xAxis.categories.push(item);
						});
					}
					// the rest of the lines contain data with their name in the first position
					else {
						var series = { 
							data: []
						};
						$.each(items, function(itemNo, item) {
							if (itemNo == 0 ) {
								series.name = item;
							} else {
								series.data.push(parseFloat(item));
							}
						});
						options.series.push(series);
						//options.dataLabels.enabled=true;
						options.credits=false;
						//options.dataLabels=true;

					}
					
				});
				var chart = new Highcharts.Chart(options);
						var item = chart.series[chart.series.length-1];
						item.options.showInLegend = false;
						item.legendItem = null;
					    chart.legend.destroyItem(item);
						chart.legend.render();
			});
			
});
			
</script>