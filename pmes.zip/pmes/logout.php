<?php 
error_reporting(0); // Turn off all error reporting
if(session_status()!=PHP_SESSION_ACTIVE) 
	session_start(); 
if(!isset($_SESSION['username']))
header('location: index.php');
else
{	unset($_SESSION['username']);
	unset($_SESSION['email']);
	unset($_SESSION['roleid']);
	session_destroy();
}
?>
<title>Logout</title>
<link href="css/pmes.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="images/Federal Logo.jpg">
<script src="js/pace.min.js"></script>
<style>
.center {
	margin: auto;
	width: 45%;
	padding: 2px;
}
</style>
<?php include("header.php");?>
<div class="container">
  <div class="row">
    <div class="col-lg-12">
      <h3 id="logout_message" class="text-success text-center hidden align-center-div"> You have been successfully logged out.
        <button id='login_again' class='btn btn-success hidden'> Login Again </button>
      </h3>
    </div>
  </div>
  <div class="voffset2"></div>
  
</div>
<?php include("footer.php")?>
<script>
$(document).ready(function () {
		setTimeout(function(){
							$('#logout_message').removeClass('hidden').addClass('animated bounceInRight');
						 },500); 
		setTimeout(function(){
							$('#login_again').removeClass('hidden').addClass('animated bounceInLeft');
						 },700); 
		
		$('#login_again').click(function(){
			window.location="index.php";
		});
	});				
</script>