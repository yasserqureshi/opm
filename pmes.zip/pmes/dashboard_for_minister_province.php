<?php
	error_reporting(0); // Turn off all error reporting
	if(session_status()!=PHP_SESSION_ACTIVE) 
		session_start();
	include("header.php");
	if(!isset($_SESSION['username']))
		header('location: index.php');
	include('include/connection.php');


	
	if ($_POST['select_ministry'] <> '0')
			$stmt ="select 
				'All',
				ifnull(round((sum(local_pip)+sum(fec_pip))/1000,2),0) 'Allocation',
				ifnull(round(sum(releases_pip)/1000,2),0) 'Releases-PIP', 
				ifnull(round(sum(releases)/1000,2),0) 'Releases', 
				ifnull(round(sum(expenditure)/1000,2),0) 'Expenditure'
				from tbl_project_summary
				where province="."'".$_POST['select_ministry']."'"."
				union all
				select
				'CPEC',
				ifnull(round((sum(local_pip)+sum(fec_pip))/1000,2),0) 'Allocation',
				ifnull(round(sum(releases_pip)/1000,2),0) 'Releases-PIP', 
				ifnull(round(sum(releases)/1000,2),0) 'Releases', 
				ifnull(round(sum(expenditure)/1000,2),0) 'Expenditure'
				from tbl_project_summary 
				where upper(project_name) like ('%CPEC%')
				and province="."'".$_POST['select_ministry']."'";
	else
		$stmt ="select 
				'All',
				ifnull(round((sum(local_pip)+sum(fec_pip))/1000,2),0) 'Allocation',
				ifnull(round(sum(releases_pip)/1000,2),0) 'Releases-PIP',
				ifnull(round(sum(releases)/1000,2),0) 'Releases',  
				ifnull(round(sum(expenditure)/1000,2),0) 'Expenditure'
				from tbl_project_summary
				union all
				select
				'CPEC',
				ifnull(round((sum(local_pip)+sum(fec_pip))/1000,2),0) 'Allocation',
				ifnull(round(sum(releases_pip)/1000,2),0) 'Releases-PIP', 
				ifnull(round(sum(releases)/1000,2),0) 'Releases', 
				ifnull(round(sum(expenditure)/1000,2),0) 'Expenditure'
				from tbl_project_summary 
				where upper(project_name) like ('%CPEC%')";
	
		$output = fopen('json/outlay.csv', 'w');
		fputcsv($output, array('Category', 'Allocation', 'Releases by PIP','Releases','Expenditure'));
		$run_query_outlay= $conn->query($stmt);
	// loop over the rows, outputting them
	while ($row_outlay=mysqli_fetch_assoc($run_query_outlay)) 
		fputcsv($output, $row_outlay);
		fclose($output);
	
	
	
	
	
	$output1 = fopen('json/time_over_run.csv', 'w');
	// output the column headings
	fputcsv($output1, array('Category', 'On Time', 'Less than Year','Bet. 1 to 3 Years','More than 3 Years','N/A'));
	
	if ($_POST['select_ministry'] <> '0')
		$stmt_time_over_run = "SELECT category,
				count(case when time_over_run='On Time' then time_over_run end) 'On Time',
				count(case when time_over_run='Less than 1 Year' then time_over_run end) 'Less than Year',
				count(case when time_over_run='Between 1 and 3 Years' then time_over_run end) 'Bet. 1 to 3 Years',
				count(case when time_over_run='More than 3 Years' then time_over_run end) 'More than 3 Years',
				count(case when time_over_run='N/A' then time_over_run end) 'N/A'
				FROM vw_time_over_run 
				where forum in ('DDWP','CDWP','ECNEC') 
				and province="."'".$_POST['select_ministry']."'"."
				group by category";
	else
		$stmt_time_over_run = "SELECT category,
				count(case when time_over_run='On Time' then time_over_run end) 'On Time',
				count(case when time_over_run='Less than 1 Year' then time_over_run end) 'Less than Year',
				count(case when time_over_run='Between 1 and 3 Years' then time_over_run end) 'Bet. 1 to 3 Years',
				count(case when time_over_run='More than 3 Years' then time_over_run end) 'More than 3 Years',
				count(case when time_over_run='N/A' then time_over_run end) 'N/A'
				FROM vw_time_over_run
				where  forum in ('DDWP','CDWP','ECNEC') 
				group by category";
				
	$run_query_time_over_run= $conn->query($stmt_time_over_run);
	
	// loop over the rows, outputting them
	while ($row_time_over_run=mysqli_fetch_assoc($run_query_time_over_run)) 
		fputcsv($output1, $row_time_over_run);
	
	fclose($output1);
	
	
	$output2 = fopen('json/monthly_progress.csv', 'w');
	// output the column headings
	fputcsv($output2, array('Category', 'Jul', 'Aug','Sept','Oct','Nov','Dec','Jan','Feb','Mar','Apr','May','Jun'));
	
	if ($_POST['select_ministry'] <> '0')
		$stmt_monthly_progress = "SELECT category,
			count(case when for_month='JULY' then for_month end) 'Jul 2016',
			count(case when for_month='AUGUST' then for_month end) 'Aug 2016',
			count(case when for_month='SEPTEMBER' then for_month end) 'Sept 2016',
			count(case when for_month='OCTOBER' then for_month end) 'Oct 2016',
			count(case when for_month='NOVEMBER' then for_month end) 'Nov 2016',
			count(case when for_month='DECEMBER' then for_month end) 'Dec 2016',
			count(case when for_month='JANUARY' then for_month end) 'Jan 2017',
			count(case when for_month='FEBRUARY' then for_month end) 'Feb 2017',
			count(case when for_month='MARCH' then for_month end) 'Mar 2017',
			count(case when for_month='APRIL' then for_month end) 'Apr 2017',
			count(case when for_month='MAY' then for_month end) 'May 2017',
			count(case when for_month='JUNE' then for_month end) 'Jun 2017'

			FROM vw_monthly_progress 
			where province="."'".$_POST['select_ministry']."'"."
			group by category";	
	else
		$stmt_monthly_progress = "SELECT category,
				count(case when for_month='JULY' then for_month end) 'Jul 2016',
				count(case when for_month='AUGUST' then for_month end) 'Aug 2016',
				count(case when for_month='SEPTEMBER' then for_month end) 'Sept 2016',
				count(case when for_month='OCTOBER' then for_month end) 'Oct 2016',
				count(case when for_month='NOVEMBER' then for_month end) 'Nov 2016',
				count(case when for_month='DECEMBER' then for_month end) 'Dec 2016',
				count(case when for_month='JANUARY' then for_month end) 'Jan 2017',
				count(case when for_month='FEBRUARY' then for_month end) 'Feb 2017',
				count(case when for_month='MARCH' then for_month end) 'Mar 2017',
				count(case when for_month='APRIL' then for_month end) 'Apr 2017',
				count(case when for_month='MAY' then for_month end) 'May 2017',
				count(case when for_month='JUNE' then for_month end) 'Jun 2017'
				FROM vw_monthly_progress 
				group by category";		
	$run_query_monthly_progress= $conn->query($stmt_monthly_progress);
	
	// loop over the rows, outputting them
	while ($row_monthly_progress=mysqli_fetch_assoc($run_query_monthly_progress)) 
		fputcsv($output2, $row_monthly_progress);
	
	fclose($output2);
	
	
	$output3 = fopen('json/commencement_year.csv', 'w');
	// output the column headings
	fputcsv($output3, array('Category','2001','2002','2003','2004','2005','2006','2007','2008','2009','2010','2011','2012','2013','2014','2015','2016','N/A'));
	
	if ($_POST['select_ministry'] <> '0')
		$stmt_commencement_year = "SELECT category,
			count(case when year='2001' then year end) '2001',
			count(case when year='2002' then year end) '2002',
			count(case when year='2003' then year end) '2003',
			count(case when year='2004' then year end) '2004',
			count(case when year='2005' then year end) '2005',
			count(case when year='2006' then year end) '2006',
			count(case when year='2007' then year end) '2007',
			count(case when year='2008' then year end) '2008',
			count(case when year='2009' then year end) '2009',
			count(case when year='2010' then year end) '2010',
			count(case when year='2011' then year end) '2011',
			count(case when year='2012' then year end) '2012',
			count(case when year='2013' then year end) '2013',
			count(case when year='2014' then year end) '2014',
			count(case when year='2015' then year end) '2015',
			count(case when year='2016' then year end) '2016',
			count(case when year='0' then year end) 'N/A'
			FROM vw_year_commencement
			where  forum in ('DDWP','CDWP','ECNEC') 
			and province="."'".$_POST['select_ministry']."'"."
			group by category";
	else
		$stmt_commencement_year = "SELECT category,
				count(case when year='2001' then year end) '2001',
				count(case when year='2002' then year end) '2002',
				count(case when year='2003' then year end) '2003',
				count(case when year='2004' then year end) '2004',
				count(case when year='2005' then year end) '2005',
				count(case when year='2006' then year end) '2006',
				count(case when year='2007' then year end) '2007',
				count(case when year='2008' then year end) '2008',
				count(case when year='2009' then year end) '2009',
				count(case when year='2010' then year end) '2010',
				count(case when year='2011' then year end) '2011',
				count(case when year='2012' then year end) '2012',
				count(case when year='2013' then year end) '2013',
				count(case when year='2014' then year end) '2014',
				count(case when year='2015' then year end) '2015',
				count(case when year='2016' then year end) '2016',
				count(case when year='0' then year end) 'N/A'
				FROM vw_year_commencement
				where  forum in ('DDWP','CDWP','ECNEC')
				group by category";
					
	$run_query_commencement_year= $conn->query($stmt_commencement_year);
	
	// loop over the rows, outputting them
	while ($row_commencement_year=mysqli_fetch_assoc($run_query_commencement_year)) 
		fputcsv($output3, $row_commencement_year);
	
	fclose($output3);
	
	
	
	$output4 = fopen('json/completion_year.csv', 'w');
	// output the column headings
	fputcsv($output4, array('Category','2005','2006','2007','2008','2009','2010','2011','2012','2013','2014','2015','2016','2017','2018','2019','2020','2021','2022','2023','2024','N/A'));
	
	if ($_POST['select_ministry'] <> '0')
		$stmt_completion_year = "SELECT category,
			count(case when year='2005' then year end) '2005',
			count(case when year='2006' then year end) '2006',
			count(case when year='2007' then year end) '2007',
			count(case when year='2008' then year end) '2008',
			count(case when year='2009' then year end) '2009',
			count(case when year='2010' then year end) '2010',
			count(case when year='2011' then year end) '2011',
			count(case when year='2012' then year end) '2012',
			count(case when year='2013' then year end) '2013',
			count(case when year='2014' then year end) '2014',
			count(case when year='2015' then year end) '2015',
			count(case when year='2016' then year end) '2016',
			count(case when year='2017' then year end) '2017',
			count(case when year='2018' then year end) '2018',
			count(case when year='2019' then year end) '2019',
			count(case when year='2020' then year end) '2020',
			count(case when year='2021' then year end) '2021',
			count(case when year='2022' then year end) '2022',
			count(case when year='2022' then year end) '2023',
			count(case when year='2022' then year end) '2024',
			count(case when year='0' then year end) 'N/A'
			FROM vw_year_completion
			where  forum in ('DDWP','CDWP','ECNEC')
			and province="."'".$_POST['select_ministry']."'"."
			group by category";
	else
		$stmt_completion_year = "SELECT category,
				count(case when year='2005' then year end) '2005',
				count(case when year='2006' then year end) '2006',
				count(case when year='2007' then year end) '2007',
				count(case when year='2008' then year end) '2008',
				count(case when year='2009' then year end) '2009',
				count(case when year='2010' then year end) '2010',
				count(case when year='2011' then year end) '2011',
				count(case when year='2012' then year end) '2012',
				count(case when year='2013' then year end) '2013',
				count(case when year='2014' then year end) '2014',
				count(case when year='2015' then year end) '2015',
				count(case when year='2016' then year end) '2016',
				count(case when year='2017' then year end) '2017',
				count(case when year='2018' then year end) '2018',
				count(case when year='2019' then year end) '2019',
				count(case when year='2020' then year end) '2020',
				count(case when year='2021' then year end) '2021',
				count(case when year='2022' then year end) '2022',
				count(case when year='2022' then year end) '2023',
				count(case when year='2022' then year end) '2024',
				count(case when year='0' then year end) 'N/A'
				FROM vw_year_completion
				where  forum in ('DDWP','CDWP','ECNEC')
				group by category";
					
	$run_query_completion_year= $conn->query($stmt_completion_year);
	
	// loop over the rows, outputting them
	while ($row_completion_year=mysqli_fetch_assoc($run_query_completion_year)) 
		fputcsv($output4, $row_completion_year);
	
	fclose($output4);
	
	
	$output6 = fopen('json/physical_progress.csv', 'w');
	// output the column headings
	fputcsv($output6, array('Category','0-25','26-50','51-75','76-100+','N/A'));
	
	if ($_POST['select_ministry'] <> '0')
		$stmt_physical_progress = "select Category,
						count(case when physical_progress  between 0 and 25 then physical_progress end) '0-25',
						count(case when physical_progress  between 26 and 50 then physical_progress end) '26-50',
						count(case when physical_progress  between 51 and 75 then physical_progress end) '51-75',
						count(case when physical_progress  > 75 then physical_progress end) '76-100+',
						count(case when physical_progress = -1 then physical_progress end) 'N/A'
						from vw_physical_progress
						where  forum in ('DDWP','CDWP','ECNEC')
						and province="."'".$_POST['select_ministry']."'"."
						group by category";
	else
		$stmt_physical_progress = "select Category,
							count(case when physical_progress  between 0 and 25 then physical_progress end) '0-25',
							count(case when physical_progress  between 26 and 50 then physical_progress end) '26-50',
							count(case when physical_progress  between 51 and 75 then physical_progress end) '51-75',
							count(case when physical_progress  > 75 then physical_progress end) '76-100+',
							count(case when physical_progress = -1 then physical_progress end) 'N/A'
							from vw_physical_progress
							where  forum in ('DDWP','CDWP','ECNEC')
							group by category";
			
					
	$run_query_physical_progress= $conn->query($stmt_physical_progress);
	
	// loop over the rows, outputting them
	while ($row_physical_progress=mysqli_fetch_assoc($run_query_physical_progress)) 
		fputcsv($output6, $row_physical_progress);
	
	fclose($output6);
	
	
	if ($_POST['select_ministry'] <> '0')
	$stmt_spi="select ifnull(round(avg((round(ifnull(physical_progress,0)/
				TIMESTAMPDIFF(MONTH,DATE_FORMAT(commencement_date,'%Y-%m-%d'),DATE_FORMAT(now(),'%Y-%m-%d')),2)*100) / 
				(100 / TIMESTAMPDIFF(MONTH,DATE_FORMAT(commencement_date,'%Y-%m-%d'),DATE_FORMAT(completion_date,'%Y-%m-%d'))))),0) 
				speed from tbl_project_summary
				where physical_progress is not null and commencement_date <> '0000-00-00' and completion_date <> '0000-00-00'
				and  province="."'".$_POST['select_ministry']."'";
	else
	$stmt_spi="select round(avg((round(ifnull(physical_progress,0)/
				TIMESTAMPDIFF(MONTH,DATE_FORMAT(commencement_date,'%Y-%m-%d'),DATE_FORMAT(now(),'%Y-%m-%d')),2)*100) / 
				(100 / TIMESTAMPDIFF(MONTH,DATE_FORMAT(commencement_date,'%Y-%m-%d'),DATE_FORMAT(completion_date,'%Y-%m-%d'))))) 
				speed from tbl_project_summary
				where physical_progress is not null and commencement_date <> '0000-00-00' and completion_date <> '0000-00-00'"; 
		
		$run_query_spi= $conn->query($stmt_spi);
		if($run_query_spi == FALSE) 
			{ 
			  die(mysql_error()); // TODO: better error handling
			}
		$row_spi = mysqli_fetch_assoc($run_query_spi);
	
	
	$output8 = fopen('json/forum.csv', 'w');
	// output the column headings
	fputcsv($output8, array('Category','DDWP','CDWP','ECNEC'));
	
	if ($_POST['select_ministry'] <> '0')
		$stmt_forum = "SELECT category,
				count(case when forum='DDWP' then forum end) 'DDWP',
				count(case when forum='CDWP' then forum end) 'CDWP',
				count(case when forum='ECNEC' then forum end) 'ECNEC'
				FROM vw_forum
				where  forum_actual in ('DDWP','CDWP','ECNEC') 
				and province="."'".$_POST['select_ministry']."'"."
				group by category";
	else
		$stmt_forum = "SELECT category,
				count(case when forum='DDWP' then forum end) 'DDWP',
				count(case when forum='CDWP' then forum end) 'CDWP',
				count(case when forum='ECNEC' then forum end) 'ECNEC'
				FROM vw_forum
				where  forum_actual in ('DDWP','CDWP','ECNEC')
				group by category";
				
	$run_query_forum= $conn->query($stmt_forum);
	
	// loop over the rows, outputting them
	while ($row_forum=mysqli_fetch_assoc($run_query_forum)) 
		fputcsv($output8, $row_forum);
	
	fclose($output8);
	
	if ($_POST['select_ministry'] <> '0')
		$stmt_allocation_vs_release ="select round(ifnull((sum(releases_pip)*100)/(sum(local_pip)+sum(fec_pip)),0)) total
				  from tbl_project_summary
				  where psdp_status='A'
				  and province="."'".$_POST['select_ministry']."'";
	else
		$stmt_allocation_vs_release ="select round((sum(releases_pip)*100)/(sum(local_pip)+sum(fec_pip))) total
				  from tbl_project_summary
				  where psdp_status='A'";
				  
		$run_query_allocation_vs_release= $conn->query($stmt_allocation_vs_release);
		$row_allocation_vs_release=mysqli_fetch_assoc($run_query_allocation_vs_release); 
		
	
	if ($_POST['select_ministry'] <> '0')
		$stmt_release_vs_expenditure ="select round(ifnull((sum(expenditure)*100)/sum(releases_pip),0)) total
				  from tbl_project_summary
				  where psdp_status='A'
				  and province="."'".$_POST['select_ministry']."'";
	else
		$stmt_release_vs_expenditure ="select round((sum(expenditure)*100)/sum(releases_pip)) total
				  from tbl_project_summary
				  where psdp_status='A'";
				  
		$run_query_release_vs_expenditure= $conn->query($stmt_release_vs_expenditure);
		$row_release_vs_expenditure=mysqli_fetch_assoc($run_query_release_vs_expenditure); 
	
	
	if ($_POST['select_ministry'] <> '0')
		$stmt_total_projects ="select count(*) total
				  from tbl_project_summary
				  where province="."'".$_POST['select_ministry']."'";
	else
		$stmt_total_projects ="select count(*) total
				  from tbl_project_summary";
				  
		$run_query_total_projects= $conn->query($stmt_total_projects);
		$row_total_projects=mysqli_fetch_assoc($run_query_total_projects); 
	
	if ($_POST['select_ministry'] <> '0')
		$stmt_progress_updated ="select count(for_month) total
				  from tbl_project_summary
				  where forum in ('DDWP','CDWP','ECNEC') 
				  and province="."'".$_POST['select_ministry']."'";
	else
		$stmt_progress_updated ="select count(for_month) total
				  from tbl_project_summary
				  where forum in ('DDWP','CDWP','ECNEC')";
				  
		$run_query_progress_updated= $conn->query($stmt_progress_updated);
		$row_progress_updated=mysqli_fetch_assoc($run_query_progress_updated); 
		
	if ($_POST['select_ministry'] <> '0')
		$stmt_ongoing ="select count(*) total
				  from tbl_project_summary
				  where project_status='ON-GOING'
				  and province="."'".$_POST['select_ministry']."'";
	else
		$stmt_ongoing ="select count(*) total
				  from tbl_project_summary
				  where project_status='ON-GOING'";
				  
		$run_query_ongoing= $conn->query($stmt_ongoing);
		$row_ongoing=mysqli_fetch_assoc($run_query_ongoing); 
	
	if ($_POST['select_ministry'] <> '0')
		$stmt_new ="select count(*) total
				  from tbl_project_summary
				  where project_status='NEW'
				  and province="."'".$_POST['select_ministry']."'";
	else
		$stmt_new ="select count(*) total
				  from tbl_project_summary
				  where project_status='NEW'";
				  
		$run_query_new= $conn->query($stmt_new);
		$row_new=mysqli_fetch_assoc($run_query_new); 	
	
	if ($_POST['select_ministry'] <> '0')
		$stmt_approved ="select count(*) total
				  from tbl_project_summary
				  where forum not in ('N/A','UNAPPROVED')
				  and province="."'".$_POST['select_ministry']."'";
	else
		$stmt_approved ="select count(*) total
				  from tbl_project_summary
				  where forum not in ('N/A','UNAPPROVED')";
				  
		$run_query_approved= $conn->query($stmt_approved);
		$row_approved=mysqli_fetch_assoc($run_query_approved); 
	
	if ($_POST['select_ministry'] <> '0')
		$stmt_unapproved ="select count(*) total
				  from tbl_project_summary
				  where forum in ('N/A','UNAPPROVED')
				  and province="."'".$_POST['select_ministry']."'";
	else
		$stmt_unapproved ="select count(*) total
				  from tbl_project_summary
				  where forum in ('N/A','UNAPPROVED')";
				  
		$run_query_unapproved= $conn->query($stmt_unapproved);
		$row_unapproved=mysqli_fetch_assoc($run_query_unapproved);		

?>

<script>

$(document).ready(function () {
		setTimeout(function(){
							$('#select_ministry').removeClass('hidden').addClass('animated bounceInLeft');
							$('#load_dashboard').removeClass('hidden').addClass('animated bounceInRight');
						 },900); 
		$('#load_dashboard').click();
	});	
	
	
$(document).ready(function () 
{
var options = {
				colors: ['#4572A7','#AA4643','#89A54E','#80699B','#3D96AE','#DB843D','#92A8CD','#A47D7C','#B5CA92'],
				chart: {
					renderTo: 'outlay',
					type: 'column',
				},
				title: {
					text: 'Financial Outlay of PSDP 2016-17',
					style:{
                    color: '#34495E',
                    fontSize: '18px'
                	}  
				},
				xAxis: {
					categories: [],
					
					labels: {
							style: {
									fontSize:'14px'
									}
								}
					 
				},
				yAxis: {
					title: {
						text: 'in Billions',
						style:{
                    		color: '#34495E',
                    		fontSize: '14px',
							color:'#F00'
                				}
					}
				},
				 plotOptions: {
           			series: {
							colorByPoint: true,
              			  	dataLabels: {
                   			enabled: true,
							style: {
                        			fontWeight: 'bold',
									fontSize:'12px'
                   					 }
                			},
				
				credits: {
    						enabled: false
  				},
                enableMouseTracking: true
            }
        },
				series: []
			};
 
			$.get('json/outlay.csv', function(data) {
				// Split the lines
				var lines = data.split('\n');
				$.each(lines, function(lineNo, line) {
					var items = line.split(',');
					
					// header line containes categories
					if (lineNo == 0) {
						$.each(items, function(itemNo, item) {
							if (itemNo > 0) options.xAxis.categories.push(item);
						});
					}
					// the rest of the lines contain data with their name in the first position
					else {
						var series = { 
							data: []
						};
						$.each(items, function(itemNo, item) {
							if (itemNo == 0 ) {
								series.name = item;
							} else {
								series.data.push(parseFloat(item));
							}
						});
						options.series.push(series);
						options.credits=false;
					}
					
				});
				var chart = new Highcharts.Chart(options);
						var item = chart.series[chart.series.length-1];
						item.options.showInLegend = false;
						chart.series[1].hide();
						item.legendItem = null;
					    chart.legend.destroyItem(item);
						chart.legend.render();
			});
									
});

$(document).ready(function () 
{
//Highcharts
var options = {
				chart: {
					renderTo: 'time_over_run',
					type: 'column'
				},
				title: {
					text: 'Time Over Run of PSDP 2016-17',
					style:{
                    color: '#34495E',
                    fontSize: '18px'
                	}  
				},
				xAxis: {
					categories: [],
					labels: {
							style: {
									fontSize:'13px'
									}
								}
				},
				
				yAxis: {
					title: {
						text: 'No of Projects',
						style:{
                    		color: '#F00',
                    		fontSize: '14px'
                				}
					}
				},
				 plotOptions: {
           			column: {
						  	dataLabels: {
                   			enabled: true
							},
					
				credits: {
    						enabled: false
  						 },
                enableMouseTracking: true
            			},
				series: {
						cursor: 'pointer',
						point: {
								events: {
									click: function (events) {
										load_detail("Time Over Run Details",this.series.name,this.category,"<?php echo $_POST['select_ministry']; ?>");
															}
										 }
                				},
						}
        			},
					
				series: []
			};
 
			$.get('json/time_over_run.csv', function(data) {
				// Split the lines
				var lines = data.split('\n');
				$.each(lines, function(lineNo, line) {
					var items = line.split(',');
					
					// header line containes categories
					if (lineNo == 0) {
						$.each(items, function(itemNo, item) {
							if (itemNo > 0) options.xAxis.categories.push(item);
						});
					}
					// the rest of the lines contain data with their name in the first position
					else {
						var series = { 
							data: []
						};
						$.each(items, function(itemNo, item) {
							if (itemNo == 0 ) {
								series.name = item;
							} else {
								series.data.push(parseFloat(item));
							}
						});
						options.series.push(series);
						//options.dataLabels.enabled=true;
						options.credits=false;
						
						//options.dataLabels=true;

					}
					
				});
				var chart = new Highcharts.Chart(options);
						var item = chart.series[chart.series.length-1];
						item.options.showInLegend = false;
						item.legendItem = null;
					    chart.legend.destroyItem(item);
						chart.legend.render();
			});
	
	
	
		
});

$(document).ready(function () 
{
//Highcharts
var options = {
				chart: {
					renderTo: 'monthly_progress',
					type: 'line'
				},
				title: {
					text: 'Monthly Progress Status',
					style:{
                    color: '#34495E',
                    fontSize: '18px'
                	}  
				},
				xAxis: {
					categories: [],
					labels: {
							style: {
									fontSize:'13px'
									}
								}
				},
				
				yAxis: {
					title: {
						text: 'No of Projects',
						style:{
                    		color: '#F00',
                    		fontSize: '14px'
                				}
					}
				},
				 plotOptions: {
           			line: {
						  	dataLabels: {
                   			enabled: true
							},
					
				credits: {
    						enabled: false
  						 },
                enableMouseTracking: true
            			}
          		},
				series: []
			};
 
			$.get('json/monthly_progress.csv', function(data) {
				// Split the lines
				var lines = data.split('\n');
				$.each(lines, function(lineNo, line) {
					var items = line.split(',');
					
					// header line containes categories
					if (lineNo == 0) {
						$.each(items, function(itemNo, item) {
							if (itemNo > 0) options.xAxis.categories.push(item);
						});
					}
					// the rest of the lines contain data with their name in the first position
					else {
						var series = { 
							data: []
						};
						$.each(items, function(itemNo, item) {
							if (itemNo == 0 ) {
								series.name = item;
							} else {
								series.data.push(parseFloat(item));
							}
						});
						options.series.push(series);
						//options.dataLabels.enabled=true;
						options.credits=false;
						//options.dataLabels=true;

					}
					
				});
				var chart = new Highcharts.Chart(options);
						var item = chart.series[chart.series.length-1];
						item.options.showInLegend = false;
						item.legendItem = null;
					    chart.legend.destroyItem(item);
						chart.legend.render();
			});
			
});

$(document).ready(function () 
{
//Highcharts
var options = {
				chart: {
					renderTo: 'commencement_year',
					type: 'column'
				},
				title: {
					text: 'Commencement Year',
					style:{
                    color: '#34495E',
                    fontSize: '18px'
                	}  
				},
				xAxis: {
					categories: [],
					labels: {
							style: {
									fontSize:'13px'
									}
								}
				},
				
				yAxis: {
					title: {
						text: 'No of Projects',
						style:{
                    		color: '#F00',
                    		fontSize: '14px'
                				}
					}
				},
				 plotOptions: {
           			column: {
						  	dataLabels: {
                   			enabled: true
							},
					
				credits: {
    						enabled: false
  						 },
                enableMouseTracking: true
            			}
        		},
				series: []
			};
 
			$.get('json/commencement_year.csv', function(data) {
				// Split the lines
				var lines = data.split('\n');
				$.each(lines, function(lineNo, line) {
					var items = line.split(',');
					
					// header line containes categories
					if (lineNo == 0) {
						$.each(items, function(itemNo, item) {
							if (itemNo > 0) options.xAxis.categories.push(item);
						});
					}
					// the rest of the lines contain data with their name in the first position
					else {
						var series = { 
							data: []
						};
						$.each(items, function(itemNo, item) {
							if (itemNo == 0 ) {
								series.name = item;
							} else {
								series.data.push(parseFloat(item));
							}
						});
						options.series.push(series);
						//options.dataLabels.enabled=true;
						options.credits=false;
						//options.dataLabels=true;

					}
					
				});
				var chart = new Highcharts.Chart(options);
						var item = chart.series[chart.series.length-1];
						item.options.showInLegend = false;
						item.legendItem = null;
					    chart.legend.destroyItem(item);
						chart.legend.render();
			});
			
});

$(document).ready(function () 
{
//Highcharts
var options = {
				chart: {
					renderTo: 'completion_year',
					type: 'column'
				},
				title: {
					text: 'Completion Year',
					style:{
                    color: '#34495E',
                    fontSize: '18px'
                	}  
				},
				xAxis: {
					categories: [],
					labels: {
							style: {
									fontSize:'13px'
									}
								}
				},
				
				yAxis: {
					title: {
						text: 'No of Projects',
						style:{
                    		color: '#F00',
                    		fontSize: '14px'
                				}
					}
				},
				 plotOptions: {
           			column: {
						  	dataLabels: {
                   			enabled: true
							},
					
				credits: {
    						enabled: false
  						 },
                enableMouseTracking: true
            			}
        		},
				series: []
			};
 
			$.get('json/completion_year.csv', function(data) {
				// Split the lines
				var lines = data.split('\n');
				$.each(lines, function(lineNo, line) {
					var items = line.split(',');
					
					// header line containes categories
					if (lineNo == 0) {
						$.each(items, function(itemNo, item) {
							if (itemNo > 0) options.xAxis.categories.push(item);
						});
					}
					// the rest of the lines contain data with their name in the first position
					else {
						var series = { 
							data: []
						};
						$.each(items, function(itemNo, item) {
							if (itemNo == 0 ) {
								series.name = item;
							} else {
								series.data.push(parseFloat(item));
							}
						});
						options.series.push(series);
						//options.dataLabels.enabled=true;
						options.credits=false;
						//options.dataLabels=true;

					}
					
				});
				var chart = new Highcharts.Chart(options);
						var item = chart.series[chart.series.length-1];
						item.options.showInLegend = false;
						item.legendItem = null;
					    chart.legend.destroyItem(item);
						chart.legend.render();
			});
			
});



$(document).ready(function () 
{
//Highcharts
var options = {
				chart: {
					renderTo: 'physical_progress',
					type: 'column'
				},
				title: {
					text: 'Physical Progress Status',
					style:{
                    color: '#34495E',
                    fontSize: '18px'
                	}  
				},
				xAxis: {
					categories: [],
					labels: {
							style: {
									fontSize:'13px'
									}
								}
				},
				
				yAxis: {
					title: {
						text: 'No of Projects',
						style:{
                    		color: '#F00',
                    		fontSize: '14px'
                				}
					}
				},
				 plotOptions: {
           			column: {
						  	dataLabels: {
                   			enabled: true
							},
					
				credits: {
    						enabled: false
  						 },
                enableMouseTracking: true
            			}
        		},
				series: []
			};
 
			$.get('json/physical_progress.csv', function(data) {
				// Split the lines
				var lines = data.split('\n');
				$.each(lines, function(lineNo, line) {
					var items = line.split(',');
					
					// header line containes categories
					if (lineNo == 0) {
						$.each(items, function(itemNo, item) {
							if (itemNo > 0) options.xAxis.categories.push(item);
						});
					}
					// the rest of the lines contain data with their name in the first position
					else {
						var series = { 
							data: []
						};
						$.each(items, function(itemNo, item) {
							if (itemNo == 0 ) {
								series.name = item;
							} else {
								series.data.push(parseFloat(item));
							}
						});
						options.series.push(series);
						//options.dataLabels.enabled=true;
						options.credits=false;
						//options.dataLabels=true;

					}
					
				});
				var chart = new Highcharts.Chart(options);
						var item = chart.series[chart.series.length-1];
						item.options.showInLegend = false;
						item.legendItem = null;
					    chart.legend.destroyItem(item);
						chart.legend.render();
			});
			
});

function load_detail(input_graph,input_type,input_category,input_ministry) {
		var category='province';
		$.ajax({
		type: 'GET',
		contentType: 'application/json; charset=utf-8',
		success: function (response) {
			if (input_type=='All')
				window.open("search_project_4_graph.php?graph="+input_graph+"&graph_for="+input_type+"&graph_value="+input_category+"&ministry="+input_ministry+"&category="+category,'','menubar=no,toolbar=no');
			else
				window.open("search_project_4_graph.php?graph="+input_graph+"&graph_for="+input_type+"&graph_value="+input_category+"&ministry="+input_ministry+"&category="+category,'','menubar=no,toolbar=no');
		},
	}); 
}


$(document).ready(function () 
{
//Highcharts
var options = {
				chart: {
					renderTo: 'forum',
					type: 'bar'
				},
				title: {
					text: 'Approval Forums Summary',
					style:{
                    color: '#34495E',
                    fontSize: '18px'
                	}  
				},
				xAxis: {
					categories: [],
					labels: {
							style: {
									fontSize:'13px'
									}
								}
				},
				
				yAxis: {
					title: {
						text: 'No of Projects',
						style:{
                    		color: '#F00',
                    		fontSize: '14px'
                				}
					}
				},
				 plotOptions: {
           			bar: {
						  	dataLabels: {
                   			enabled: true
							},
					
				credits: {
    						enabled: false
  						 },
                enableMouseTracking: true
            			}
        		},
				series: []
			};
 
			$.get('json/forum.csv', function(data) {
				// Split the lines
				var lines = data.split('\n');
				$.each(lines, function(lineNo, line) {
					var items = line.split(',');
					
					// header line containes categories
					if (lineNo == 0) {
						$.each(items, function(itemNo, item) {
							if (itemNo > 0) options.xAxis.categories.push(item);
						});
					}
					// the rest of the lines contain data with their name in the first position
					else {
						var series = { 
							data: []
						};
						$.each(items, function(itemNo, item) {
							if (itemNo == 0 ) {
								series.name = item;
							} else {
								series.data.push(parseFloat(item));
							}
						});
						options.series.push(series);
						//options.dataLabels.enabled=true;
						options.credits=false;
						//options.dataLabels=true;

					}
					
				});
				var chart = new Highcharts.Chart(options);
						var item = chart.series[chart.series.length-1];
						item.options.showInLegend = false;
						item.legendItem = null;
					    chart.legend.destroyItem(item);
						chart.legend.render();
			});
			
});


$(document).ready(function() {
	var speedColor = '#474337';
    var rpmColor = '#BBB59C';
    var kmhArr = [ 0, 20, 40, 60, 90, 120, 150, 180, 210 ];
    var hiRef = '#A41E09';
    var dialColor = '#FA3421';
    var currentRpm = 0;
	var speedColor = '#474337';
    $('#spi').highcharts({

        chart: {
            type: 'gauge',
            plotBackgroundColor: null,
            plotBackgroundImage: null,
            plotBorderWidth: 0,
            plotShadow: false
        },

        title: {
            text: 'SP of PSDP 2016-17',
			style:{
                    color: '#34495E',
                    fontSize: '18px'
                	}  
        },

       pane: {
            startAngle: -150,
            endAngle: 90,
            background: [{
                backgroundColor: {
                    linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                    stops: [
                        [0, '#FFF'],
                        [1, '#333']
                    ]
                },
                borderWidth: 0,
                outerRadius: '115%'
            }, {
                backgroundColor: {
                    linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                    stops: [
                        [0, '#333'],
                        [1, '#FFF']
                    ]
                },
                borderWidth: 1,
                outerRadius: '107%'
            }, {
                // default background
            }, {
               // BG color for rpm
                    backgroundColor: '#999',
                    outerRadius: '6%',
                    innerRadius: '5%'
            }]
        },
		credits: {
    						enabled: false
  				},
        // the value axis
        yAxis: {
            min: 0,
            max: 120,
			
                tickInterval: 5,
                tickLength: 7,
				tickWidth: 1.5,
                lineWidth: 1,
                lineColor: speedColor,
                tickColor: speedColor,
				tickPosition: 'outside',
                minorTickInterval: 2,
                minorTickLength: 10,
                minorTickWidth: .5,
				minorTickPosition: 'inside',
                minorTickColor: speedColor,
                endOnTick: false,
				
            labels: {
                step: 2,
                rotation: 'auto',
				style: {
                       fontFamily: 'Verdana',
                       fontSize: '12px',
					   color:'#474337',
					   offset:10
                       
                   }
            },
            title: {
                text: '% SP',
                    y: 100,
                    x: 5,
				style:{
                    color: '#34495E',
                    fontSize: '18px'
					}
            },
            plotBands: [{
                from: 0,
                to: 60,
                color: '#DF5353' // red 
            }, {
                from: 60,
                to: 80,
                color: '#DDDF0D' // yellow
            }, {
                from: 80,
                to: 120,
                color: '#55BF3B' // green
            }]
        },

        series: [{
            name: 'SP',
            data: [0],
            tooltip: {
                valueSuffix: ' %'
            },
			dataLabels: 
				{
                    color:'#222',
                    borderWidth: 1,
                    y: -80,
                    x: 0,
                    style: {
                        fontSize: '14px'
                    		},
                    formatter: function() {
                        return this.y.toFixed(0);
                    					  }
                },
			dial: {
                    backgroundColor: dialColor,
                    baseLength: '70%',
                    baseWidth: 5,
                    radius: '80%',
                    topWidth: .2,
                    rearLength: '-7%',
                    borderColor: '#B17964',
                    borderWidth: 1
                }
				
        }]

    },
	
	
        // Add some life
        function (chart) {
			
            if (!chart.renderer.forExport) 	{
				var initial_value=0;
                var timer = setInterval(function () 		{
                    var point = chart.series[0].points[0],newVal,
                        inc = <?php echo $row_spi["speed"];?>
					
                    if (initial_value >= inc)
                        {
							clearInterval(timer);
							//initial_value=0;
						}
					else
						initial_value = initial_value +1;
						
                    point.update(initial_value);
					//
                								}, 100);
            								}
        				});
});


$(document).ready(function () {
		$('.allocation_vs_release').easyPieChart({
			//easing: 'easeOutBounce',
			 lineWidth:8,
			 animate: 4000,
			 scaleColor: true,
			// trailColor: '#eee',
			 lineCap: "round",
			 size: 180,
			 trackColor: '#e5e5e5',
			 barColor: '#3da0ea',
			 onStep: function(from, to, percent) {
					$(this.el).find('.percent').text(Math.round(percent));
			}
		});
	});

$(document).ready(function () {
		$('.release_vs_expenditure').easyPieChart({
			//easing: 'easeOutBounce',
			 lineWidth:8,
			 animate: 2000,
			 scaleColor: true,
			 lineCap: "round",
			 size: 180,
			 trackColor: '#e5e5e5',
			 barColor: '#CC870E',
			 onStep: function(from, to, percent1) {
					$(this.el).find('.percent1').text(Math.round(percent1));
			}
		});
	});

$(document).ready(function () {
		$('.total_projects').easyPieChart({
			 //easing: 'easeOutBounce',
			 lineWidth:false,
			 animate: 4000,
			 scaleColor: true,
			// trailColor: '#eee',
			 lineCap: false,
			 size: 180,
			 trackColor: '#e5e5e5',
			 barColor: false,
			 onStep: function(from, to, percent2) {
					$(this.el).find('.percent2').text(Math.round(percent2));
			}
		});
	});

$(document).ready(function () {
		$('.progress_updated').easyPieChart({
			 //easing: 'easeOutBounce',
			 lineWidth:false,
			 animate: 2000,
			 scaleColor: true,
			 lineCap:false,
			 size: 180,
			 trackColor: '#e5e5e5',
			 barColor:false,
			 onStep: function(from, to, percent3) {
					$(this.el).find('.percent3').text(Math.round(percent3));
			}
		});
	});

$(document).ready(function () {
		$('.ongoing').easyPieChart({
			 //easing: 'easeOutBounce',
			 lineWidth:false,
			 animate: 4000,
			 scaleColor: true,
			 lineCap:false,
			 size: 180,
			 trackColor: '#e5e5e5',
			 barColor:false,
			 onStep: function(from, to, percent4) {
					$(this.el).find('.percent4').text(Math.round(percent4));
			}
		});
	});

$(document).ready(function () {
		$('.new_project').easyPieChart({
			 //easing: 'easeOutBounce',
			 lineWidth:false,
			 animate: 4000,
			 scaleColor: true,
			 lineCap:false,
			 size: 180,
			 trackColor: '#e5e5e5',
			 barColor:false,
			 onStep: function(from, to, percent5) {
					$(this.el).find('.percent5').text(Math.round(percent5));
			}
		});
	});	

$(document).ready(function () {
		$('.approved').easyPieChart({
			 //easing: 'easeOutBounce',
			 lineWidth:false,
			 animate: 5000,
			 scaleColor: true,
			 lineCap:false,
			 size: 180,
			 trackColor: '#e5e5e5',
			 barColor:false,
			 onStep: function(from, to, percent6) {
					$(this.el).find('.percent6').text(Math.round(percent6));
			}
		});
	});	

$(document).ready(function () {
		$('.unapproved').easyPieChart({
			 //easing: 'easeOutBounce',
			 lineWidth:false,
			 animate: 5000,
			 scaleColor: true,
			 lineCap:false,
			 size: 180,
			 trackColor: '#e5e5e5',
			 barColor:false,
			 onStep: function(from, to, percent7) {
					$(this.el).find('.percent7').text(Math.round(percent7));
			}
		});
	});	

function load_dashboard_again(){
	document.getElementById("get_ministry").submit();
}
			
</script>
<title>Dashboard Province Wise</title>
<link rel="shortcut icon" href="images/FederalLogo.jpg">
<script src="js/jquery.easing.min.js"></script>
<script src="js/jquery.easypiechart.min.js"></script>
<script type="text/javascript" src="js/arrow78.js"></script>
<script src="js/pace.min.js"></script>
<style>
.col-md-12 {
	margin: 12px auto;
}
.col-md-6 {
	margin: 12px auto;
}
.col-md-3 {
	margin: 12px auto;
}
.center {
	margin: auto;
	width: 80%;
	padding: 2px;
}
</style>
<div class="container-fluid">
  <div class="row"> 
  <h4 class="text-center"> Province Wise Dashboard for Projects Assigned to <font style="color:#F00"><?php echo strtoupper($_SESSION['username']);?></font> User </h4>
  <h4 class="text-center">
    <form class="form-inline" id="get_ministry" name="get_ministry" role="form" method="post" onsubmit="set_ministry()" action="dashboard_for_minister_province.php?loaded=1" enctype="multipart/form-data">
      <?php
	 	$stmt_province="select distinct province from tbl_project_summary order by 1";
		$run_query_province= $conn->query($stmt_province);

     	echo "<div class='input-group input-group-md align-center-div'> ";?>
		
		<select name='select_ministry' id='select_ministry' class='form-control hidden' size='1' onchange='load_dashboard_again()'> 
        <?php echo "<option value='0'>All Provinces</option>";
		while ($row_province=mysqli_fetch_assoc($run_query_province))
				{
					echo "<option value="."'".$row_province['province']."'";
					if($_POST['select_ministry']==$row_province['province'])
					{
						echo "selected='selected'>".$row_province['province']."</option>";
					}
					else
						echo ">".$row_province['province']."</option>";
				}
		echo "</select> </div>";
		if ($_GET['loaded']==1)
			null;
		else
			echo "<button id='load_dashboard' type='submit' class='btn btn-success hidden'> Load Dashboard </button>";
	 ?>
    </form></h4>
  </div>
   <div class="row">
    <div class="col-md-6">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h4 class="panel-title">Financial Outlay of PSDP</h4>
        </div>
        <div class="panel-body">
          <div id="outlay"> </div>
        </div>
        <div class="panel-footer">
          <h6 class="text-danger"> <strong>Note:</strong> Comparison between Allocations, Releases and Expenditures for current PSDP. <br/>
            <strong>*</strong> CPEC represents projects included in current PSDP with a keyword "CPEC"</h6>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h4 class="panel-title">Scheduled Performance</h4>
        </div>
        <div class="panel-body">
          <div id="spi"> </div>
        </div>
        <div class="panel-footer">
          <h6 class="text-danger"> <strong>Note:</strong> SP <strong>100%</strong> means that project will be completed on time whereas SP <strong>50%</strong> means that the project will take double the time proposed in PC-I</h6>
        </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-3 col-sm-6">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h4 class="panel-title">% Releases Against Allocations</h4>
        </div>
        <div class="panel-body">
          <div class="align-center-div" id="release_vs_expenditure" style="width:250px; height:250px"> <br/>
            <div class="center"> <span class="allocation_vs_release text-center" data-percent=<?php echo $row_allocation_vs_release["total"];?>> <span class="percent"></span> </span> </div>
          </div>
          <div class="panel-footer">
            <h6 class="text-danger"> <strong>Note:</strong> Total Releases till date compared with total Allocations </h6>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-3 col-sm-6">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h4 class="panel-title">% Expenditures Against Releases</h4>
        </div>
        <div class="panel-body">
          <div class="align-center-div" id="release_vs_expenditure" style="width:250px; height:250px"> <br/>
            <div class="center"> <span class="release_vs_expenditure text-center" data-percent=<?php echo $row_release_vs_expenditure["total"];?>> <span class="percent1"></span> </span> </div>
          </div>
          <div class="panel-footer">
            <h6 class="text-danger"> <strong>Note:</strong> Total Expenditure till date compared with total Releases till date</h6>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-3 col-sm-6">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h4 class="panel-title">Total Projects</h4>
        </div>
        <div class="panel-body">
          <div class="align-center-div" id="total_projects" style="width:250px; height:250px"> <br/>
            <div class="center"> <span class="total_projects text-center" data-percent=<?php echo $row_total_projects["total"];?>> <span class="percent2"></span> </span> </div>
          </div>
          <div class="panel-footer">
            <h6 class="text-danger"> <strong>Note:</strong> Number of Projects in current PSDP 2016-17</h6>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-3 col-sm-6">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h4 class="panel-title">Progress Updated for Projects</h4>
        </div>
        <div class="panel-body">
          <div class="align-center-div" id="progress_updated" style="width:250px; height:250px"> <br/>
            <div class="center"> <span class="progress_updated text-center" data-percent=<?php echo $row_progress_updated["total"];?>> <span class="percent3"></span> </span> </div>
          </div>
          <div class="panel-footer">
            <h6 class="text-danger"> <strong>Note:</strong> One Pager updated for number of projects in current PSDP</h6>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-3 col-sm-6">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h4 class="panel-title">On-Going Projects</h4>
        </div>
        <div class="panel-body">
          <div class="align-center-div" id="ongoing" style="width:250px; height:250px"> <br/>
            <div class="center"> <span class="ongoing text-center" data-percent=<?php echo $row_ongoing["total"];?>> <span class="percent4"></span> </span> </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-3 col-sm-6">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h4 class="panel-title">New Projects</h4>
        </div>
        <div class="panel-body">
          <div class="align-center-div" id="new" style="width:250px; height:250px"> <br/>
            <div class="center"> <span class="new_project text-center" data-percent=<?php echo $row_new["total"];?>> <span class="percent5"></span> </span> </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-3 col-sm-6">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h4 class="panel-title">Approved Projects</h4>
        </div>
        <div class="panel-body">
          <div class="align-center-div" id="approved" style="width:250px; height:250px"> <br/>
            <div class="center"> <span class="approved text-center" data-percent=<?php echo $row_approved["total"];?>> <span class="percent6"></span> </span> </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-3 col-sm-6">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h4 class="panel-title">Un-Approved Projects</h4>
        </div>
        <div class="panel-body">
          <div class="align-center-div" id="unapproved" style="width:250px; height:250px"> <br/>
            <div class="center"> <span class="unapproved text-center" data-percent=<?php echo $row_unapproved["total"];?>> <span class="percent7"></span> </span> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-6">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h4 class="panel-title">Time Over Run</h4>
        </div>
        <div class="panel-body">
          <div id="time_over_run"> </div>
        </div>
        <div class="panel-footer">
          <h6 class="text-danger"> <strong>Note:</strong> Time Over Run is calculated using Commencement Date, Completion Date and Current Date</h6>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h4 class="panel-title">Approval Forums Summary</h4>
        </div>
        <div class="panel-body">
          <div id="forum"> </div>
        </div>
        <div class="panel-footer">
          <h6 class="text-danger"> <strong>Note:</strong> Projects approved by competent forums</h6>
        </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-6">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h4 class="panel-title">Monthly Progress Status</h4>
        </div>
        <div class="panel-body">
          <div id="monthly_progress"> </div>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h4 class="panel-title">Physical Progress Status</h4>
        </div>
        <div class="panel-body">
          <div id="physical_progress"> </div>
        </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h4 class="panel-title">Commencement Year Summary</h4>
        </div>
        <div class="panel-body">
          <div id="commencement_year"> </div>
        </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h4 class="panel-title">Completion Year Summary</h4>
        </div>
        <div class="panel-body">
          <div id="completion_year"> </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="voffset5"></div>
<?php include("footer.php")?>