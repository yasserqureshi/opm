<?php
	error_reporting(0); // Turn off all error reporting
	if(session_status()!=PHP_SESSION_ACTIVE) 
		session_start();
	include("header.php");
	if(!isset($_SESSION['username']))
		header('location: index.php');
	include('include/connection.php');
	

	if ($_POST['select_ministry'] <> '0')
			$stmt ="select 
				'All',
				ifnull(round(sum(allocation)/1000,2),0) 'Allocation',
				ifnull(round(sum(releases)/1000,2),0) 'Releases', 
				ifnull(round(sum(expenditure)/1000,2),0) 'Expenditure'
				from tbl_project_summary_pmes
				where psdp_status='A' 
				and ministry="."'".$_POST['select_ministry']."'"."
				union all
				select
				'CPEC',
				ifnull(round(sum(allocation)/1000,2),0) 'Allocation',
				ifnull(round(sum(releases)/1000,2),0) 'Releases', 
				ifnull(round(sum(expenditure)/1000,2),0) 'Expenditure'
				from tbl_project_summary_pmes
				where psdp_status='A'
				and upper(project_name) like ('%CPEC%')
				and ministry="."'".$_POST['select_ministry']."'";
	else
		$stmt ="select 
				'All',
				ifnull(round(sum(allocation)/1000,2),0) 'Allocation',
				ifnull(round(sum(releases)/1000,2),0) 'Releases', 
				ifnull(round(sum(expenditure)/1000,2),0) 'Expenditure'
				from tbl_project_summary_pmes
				where  psdp_status='A'
				union all
				select
				'CPEC',
				ifnull(round(sum(allocation)/1000,2),0) 'Allocation',
				ifnull(round(sum(releases)/1000,2),0) 'Releases', 
				ifnull(round(sum(expenditure)/1000,2),0) 'Expenditure'
				from tbl_project_summary_pmes
				where  psdp_status='A'
				and upper(project_name) like ('%CPEC%')";
	
		$output = fopen('json/outlay.csv', 'w');
		fputcsv($output, array('Category', 'Allocation','Releases','Expenditure'));
		$run_query_outlay= $conn->query($stmt);
	// loop over the rows, outputting them
	while ($row_outlay=mysqli_fetch_assoc($run_query_outlay)) 
		fputcsv($output, $row_outlay);
		fclose($output);
	
	
	
	
	$output2 = fopen('json/monthly_progress.csv', 'w');
	// output the column headings
	fputcsv($output2, array('Progress','Jul', 'Aug','Sept','Oct','Nov','Dec','Jan','Feb','Mar','Apr','May','Jun'));
	
	if ($_POST['select_ministry'] <> '0')
		$stmt_monthly_progress = "SELECT 'Progress',
			count(case when for_month='JULY' then for_month end) 'Jul 2016',
			count(case when for_month='AUGUST' then for_month end) 'Aug 2016',
			count(case when for_month='SEPTEMBER' then for_month end) 'Sept 2016',
			count(case when for_month='OCTOBER' then for_month end) 'Oct 2016',
			count(case when for_month='NOVEMBER' then for_month end) 'Nov 2016',
			count(case when for_month='DECEMBER' then for_month end) 'Dec 2016',
			count(case when for_month='JANUARY' then for_month end) 'Jan 2017',
			count(case when for_month='FEBRUARY' then for_month end) 'Feb 2017',
			count(case when for_month='MARCH' then for_month end) 'Mar 2017',
			count(case when for_month='APRIL' then for_month end) 'Apr 2017',
			count(case when for_month='MAY' then for_month end) 'May 2017',
			count(case when for_month='JUNE' then for_month end) 'Jun 2017'
			FROM tbl_project_summary_pmes 
			where ministry="."'".$_POST['select_ministry']."'";
	else
		$stmt_monthly_progress = "SELECT 'Progress',
				count(case when for_month='JULY' then for_month end) 'Jul 2016',
				count(case when for_month='AUGUST' then for_month end) 'Aug 2016',
				count(case when for_month='SEPTEMBER' then for_month end) 'Sept 2016',
				count(case when for_month='OCTOBER' then for_month end) 'Oct 2016',
				count(case when for_month='NOVEMBER' then for_month end) 'Nov 2016',
				count(case when for_month='DECEMBER' then for_month end) 'Dec 2016',
				count(case when for_month='JANUARY' then for_month end) 'Jan 2017',
				count(case when for_month='FEBRUARY' then for_month end) 'Feb 2017',
				count(case when for_month='MARCH' then for_month end) 'Mar 2017',
				count(case when for_month='APRIL' then for_month end) 'Apr 2017',
				count(case when for_month='MAY' then for_month end) 'May 2017',
				count(case when for_month='JUNE' then for_month end) 'Jun 2017'
				FROM tbl_project_summary_pmes"; 
			
	$run_query_monthly_progress= $conn->query($stmt_monthly_progress);
	
	// loop over the rows, outputting them
	while ($row_monthly_progress=mysqli_fetch_assoc($run_query_monthly_progress)) 
		fputcsv($output2, $row_monthly_progress);
	
	fclose($output2);
	
	
	
	
	$output8 = fopen('json/work_plan.csv', 'w');
	// output the column headings
	fputcsv($output8, array('Category','Not Initiated','With PD','With FPM','With PW','Approved'));
	
	if ($_POST['select_ministry'] <> '0')
		$stmt_work_plan = "SELECT 'Work Plan',
				count(case when work_plan='Not Initiated' then work_plan end) 'Not Initiated',
				count(case when work_plan='With PD' then work_plan end) 'With PD',
				count(case when work_plan='With FPM' then work_plan end) 'With FPM',
				count(case when work_plan='With PW' then work_plan end) 'With PW',
				count(case when work_plan='Approved' then work_plan end) 'Approved'
				FROM tbl_project_summary_pmes
				where pmes_profile='Yes' and ministry="."'".$_POST['select_ministry']."'
				union all
				SELECT 'Cash Plan',
				count(case when cash_plan='Not Initiated' then cash_plan end) 'Not Initiated',
				count(case when cash_plan='With PD' then cash_plan end) 'With PD',
				count(case when cash_plan='With FPM' then cash_plan end) 'With FPM',
				count(case when cash_plan='With PW' then cash_plan end) 'With PW',
				count(case when cash_plan='Approved' then cash_plan end) 'Approved'
				FROM tbl_project_summary_pmes
				where pmes_profile='Yes' and ministry="."'".$_POST['select_ministry']."'";
	else
		$stmt_work_plan = "SELECT 'Work Plan',
				count(case when work_plan='Not Initiated' then work_plan end) 'Not Initiated',
				count(case when work_plan='With PD' then work_plan end) 'With PD',
				count(case when work_plan='With FPM' then work_plan end) 'With FPM',
				count(case when work_plan='With PW' then work_plan end) 'With PW',
				count(case when work_plan='Approved' then work_plan end) 'Approved'
				FROM tbl_project_summary_pmes
				where pmes_profile='Yes'
				union all
				SELECT 'Cash Plan',
				count(case when cash_plan='Not Initiated' then cash_plan end) 'Not Initiated',
				count(case when cash_plan='With PD' then cash_plan end) 'With PD',
				count(case when cash_plan='With FPM' then cash_plan end) 'With FPM',
				count(case when cash_plan='With PW' then cash_plan end) 'With PW',
				count(case when cash_plan='Approved' then cash_plan end) 'Approved'
				FROM tbl_project_summary_pmes
				where pmes_profile='Yes'";
				
	$run_query_work_plan= $conn->query($stmt_work_plan);
	
	// loop over the rows, outputting them
	while ($row_work_plan=mysqli_fetch_assoc($run_query_work_plan)) 
		fputcsv($output8, $row_work_plan);
	
	fclose($output8);
	
	
	
	
	if ($_POST['select_ministry'] <> '0')
		$stmt_allocation_vs_release ="select round(ifnull((sum(releases)*100)/sum(allocation),0)) total
				  from tbl_project_summary_pmes
				  where psdp_status='A'
				  and ministry="."'".$_POST['select_ministry']."'";
	else
		$stmt_allocation_vs_release ="select round((sum(releases)*100)/sum(allocation)) total
				  from tbl_project_summary_pmes
				  where psdp_status='A'";
				  
		$run_query_allocation_vs_release= $conn->query($stmt_allocation_vs_release);
		$row_allocation_vs_release=mysqli_fetch_assoc($run_query_allocation_vs_release); 
		
	
	if ($_POST['select_ministry'] <> '0')
		$stmt_release_vs_expenditure ="select round(ifnull((sum(expenditure)*100)/sum(releases),0)) total
				  from tbl_project_summary_pmes
				  where psdp_status='A'
				  and ministry="."'".$_POST['select_ministry']."'";
	else
		$stmt_release_vs_expenditure ="select round((sum(expenditure)*100)/sum(releases)) total
				  from tbl_project_summary_pmes
				  where psdp_status='A'";
				  
		$run_query_release_vs_expenditure= $conn->query($stmt_release_vs_expenditure);
		$row_release_vs_expenditure=mysqli_fetch_assoc($run_query_release_vs_expenditure); 
	
	
	if ($_POST['select_ministry'] <> '0')
		$stmt_total_projects ="select count(*) total
				  from tbl_project_summary_pmes
				  where ministry="."'".$_POST['select_ministry']."'";
	else
		$stmt_total_projects ="select count(*) total
				  from tbl_project_summary_pmes";
				  
		$run_query_total_projects= $conn->query($stmt_total_projects);
		$row_total_projects=mysqli_fetch_assoc($run_query_total_projects); 
	
	if ($_POST['select_ministry'] <> '0')
		$stmt_progress_updated ="select count(for_month) total
				  from tbl_project_summary_pmes
				  where pmes_profile='Yes' 
				  and ministry="."'".$_POST['select_ministry']."'";
	else
		$stmt_progress_updated ="select count(for_month) total
				  from tbl_project_summary_pmes
				  where pmes_profile='Yes'";
				  
		$run_query_progress_updated= $conn->query($stmt_progress_updated);
		$row_progress_updated=mysqli_fetch_assoc($run_query_progress_updated); 
		
	if ($_POST['select_ministry'] <> '0')
		$stmt_ongoing ="select count(*) total
				  from tbl_project_summary_pmes
				  where project_status='ON GOING'
				  and ministry="."'".$_POST['select_ministry']."'";
	else
		$stmt_ongoing ="select count(*) total
				  from tbl_project_summary_pmes
				  where project_status='ON GOING'";
				  
		$run_query_ongoing= $conn->query($stmt_ongoing);
		$row_ongoing=mysqli_fetch_assoc($run_query_ongoing); 
	
	if ($_POST['select_ministry'] <> '0')
		$stmt_new ="select count(*) total
				  from tbl_project_summary_pmes
				  where project_status='NEW'
				  and ministry="."'".$_POST['select_ministry']."'";
	else
		$stmt_new ="select count(*) total
				  from tbl_project_summary_pmes
				  where project_status='NEW'";
				  
		$run_query_new= $conn->query($stmt_new);
		$row_new=mysqli_fetch_assoc($run_query_new); 	
	
	if ($_POST['select_ministry'] <> '0')
		$stmt_approved ="select count(*) total
				  from tbl_project_summary_pmes
				  where forum not in ('UNAPPROVED')
				  and ministry="."'".$_POST['select_ministry']."'";
	else
		$stmt_approved ="select count(*) total
				  from tbl_project_summary_pmes
				  where forum not in ('UNAPPROVED')";
				  
		$run_query_approved= $conn->query($stmt_approved);
		$row_approved=mysqli_fetch_assoc($run_query_approved); 
	
	if ($_POST['select_ministry'] <> '0')
		$stmt_unapproved ="select count(*) total
				  from tbl_project_summary_pmes
				  where forum in ('UNAPPROVED')
				  and ministry="."'".$_POST['select_ministry']."'";
	else
		$stmt_unapproved ="select count(*) total
				  from tbl_project_summary_pmes
				  where forum in ('UNAPPROVED')";
				  
		$run_query_unapproved= $conn->query($stmt_unapproved);
		$row_unapproved=mysqli_fetch_assoc($run_query_unapproved);	
		
		
	if ($_POST['select_ministry'] <> '0')
		$stmt_missing_profile ="select count(*) total
				  from tbl_project_summary_pmes
				  where pmes_profile = 'No'
				  and forum <> 'UNAPPROVED'
				  and ministry="."'".$_POST['select_ministry']."'";
	else
		$stmt_missing_profile ="select count(*) total
				  from tbl_project_summary_pmes
				  where pmes_profile = 'No'
				  and forum <> 'UNAPPROVED'";
				  
		$run_query_missing_profile= $conn->query($stmt_missing_profile);
		$row_missing_profile=mysqli_fetch_assoc($run_query_missing_profile);	
			

?>
<script>

$(document).ready(function () {
		setTimeout(function(){
							$('#select_ministry').removeClass('hidden').addClass('animated bounceInLeft');
							$('#load_dashboard').removeClass('hidden').addClass('animated bounceInRight');
						 },900); 
							$('#load_dashboard').click();
	});



$(document).ready(function () 
{
var options = {
				colors: ['#4572A7','#AA4643','#89A54E','#80699B','#3D96AE','#DB843D','#92A8CD','#A47D7C','#B5CA92'],
				chart: {
					renderTo: 'outlay',
					type: 'column',
				},
				title: {
					text: 'Financial Outlay of PSDP 2016-17',
					style:{
                    color: '#34495E',
                    fontSize: '18px'
                	}  
				},
				xAxis: {
					categories: [],
					
					labels: {
							style: {
									fontSize:'14px'
									}
								}
					 
				},
				yAxis: {
					title: {
						text: 'in Billions',
						style:{
                    		color: '#34495E',
                    		fontSize: '14px',
							color:'#F00'
                				}
					}
				},
				 plotOptions: {
           			series: {
							colorByPoint: true,
              			  	dataLabels: {
                   			enabled: true,
							style: {
                        			fontWeight: 'bold',
									fontSize:'12px'
                   					 }
                			},
				
				credits: {
    						enabled: false
  				},
                enableMouseTracking: true
            }
        },
				series: []
			};
 
			$.get('json/outlay.csv', function(data) {
				// Split the lines
				var lines = data.split('\n');
				$.each(lines, function(lineNo, line) {
					var items = line.split(',');
					
					// header line containes categories
					if (lineNo == 0) {
						$.each(items, function(itemNo, item) {
							if (itemNo > 0) options.xAxis.categories.push(item);
						});
					}
					// the rest of the lines contain data with their name in the first position
					else {
						var series = { 
							data: []
						};
						$.each(items, function(itemNo, item) {
							if (itemNo == 0 ) {
								series.name = item;
							} else {
								series.data.push(parseFloat(item));
							}
						});
						options.series.push(series);
						options.credits=false;
					}
				});
				var chart = new Highcharts.Chart(options);
						var item = chart.series[chart.series.length-1];
						item.options.showInLegend = false;
						chart.series[1].hide();
						item.legendItem = null;
						chart.legend.destroyItem(item);
						chart.legend.render();
			});
									
});


$(document).ready(function () 
{
//Highcharts
var options = {
				chart: {
					renderTo: 'monthly_progress',
					type: 'line'
				},
				title: {
					text: 'Monthly Progress Status',
					style:{
                    color: '#34495E',
                    fontSize: '18px'
                	}  
				},
				xAxis: {
					categories: [],
					labels: {
							style: {
									fontSize:'13px'
									}
								}
				},
				
				yAxis: {
					title: {
						text: 'No of Projects',
						style:{
                    		color: '#F00',
                    		fontSize: '14px'
                				}
					}
				},
				 plotOptions: {
           			line: {
						  	dataLabels: {
                   			enabled: true
							},
					
				credits: {
    						enabled: false
  						 },
                enableMouseTracking: true
            			}
          		},
				series: []
			};
 
			$.get('json/monthly_progress.csv', function(data) {
				// Split the lines
				var lines = data.split('\n');
				$.each(lines, function(lineNo, line) {
					var items = line.split(',');
					
					// header line containes categories
					if (lineNo == 0) {
						$.each(items, function(itemNo, item) {
							if (itemNo > 0) options.xAxis.categories.push(item);
						});
					}
					// the rest of the lines contain data with their name in the first position
					else {
						var series = { 
							data: []
						};
						$.each(items, function(itemNo, item) {
							if (itemNo == 0 ) {
								series.name = item;
							} else {
								series.data.push(parseFloat(item));
							}
						});
						options.series.push(series);
						//options.dataLabels.enabled=true;
						options.credits=false;
						//options.dataLabels=true;

					}
					
				});
				var chart = new Highcharts.Chart(options);
						var item = chart.series[chart.series.length-1];
						item.options.showInLegend = false;
						item.legendItem = null;
					    chart.legend.destroyItem(item);
						chart.legend.render();
			});
			
});



$(document).ready(function () 
{
//Highcharts
var options = {
				chart: {
					renderTo: 'work_plan',
					type: 'column'
				},
				title: {
					text: 'Work/Cash Plan 2016-17 Summary',
					style:{
                    color: '#34495E',
                    fontSize: '18px'
                	}  
				},
				xAxis: {
					categories: [],
					labels: {
							style: {
									fontSize:'13px'
									}
								}
				},
				
				yAxis: {
					title: {
						text: 'No of Projects',
						style:{
                    		color: '#F00',
                    		fontSize: '14px'
                				}
					}
				},
				 plotOptions: {
           			column: {
						  	dataLabels: {
                   			enabled: true
							},
							dataLabels: {
                   			enabled: true,
							align: 'left',
							rotation: 270,
							x: 0,
							y: -15,
							style: {
                        			fontSize:'12px'									
                   					}
                			},
					
				credits: {
    						enabled: false
  						 },
                enableMouseTracking: true
            			}
        		},
				series: []
			};
 
			$.get('json/work_plan.csv', function(data) {
				// Split the lines
				var lines = data.split('\n');
				$.each(lines, function(lineNo, line) {
					var items = line.split(',');
					
					// header line containes categories
					if (lineNo == 0) {
						$.each(items, function(itemNo, item) {
							if (itemNo > 0) options.xAxis.categories.push(item);
						});
					}
					// the rest of the lines contain data with their name in the first position
					else {
						var series = { 
							data: []
						};
						$.each(items, function(itemNo, item) {
							if (itemNo == 0 ) {
								series.name = item;
							} else {
								series.data.push(parseFloat(item));
							}
						});
						options.series.push(series);
						//options.dataLabels.enabled=true;
						options.credits=false;
						//options.dataLabels=true;

					}
					
				});
				var chart = new Highcharts.Chart(options);
						var item = chart.series[chart.series.length-1];
						item.options.showInLegend = false;
						item.legendItem = null;
					    chart.legend.destroyItem(item);
						chart.legend.render();
			});
			
});


$(document).ready(function () {
		$('.allocation_vs_release').easyPieChart({
			//easing: 'easeOutBounce',
			 lineWidth:8,
			 animate: 4000,
			 scaleColor: true,
			// trailColor: '#eee',
			 lineCap: "round",
			 size: 180,
			 trackColor: '#e5e5e5',
			 barColor: '#3da0ea',
			 onStep: function(from, to, percent) {
					$(this.el).find('.percent').text(Math.round(percent));
			}
		});
	});

$(document).ready(function () {
		$('.release_vs_expenditure').easyPieChart({
			//easing: 'easeOutBounce',
			 lineWidth:8,
			 animate: 2000,
			 scaleColor: true,
			 lineCap: "round",
			 size: 180,
			 trackColor: '#e5e5e5',
			 barColor: '#CC870E',
			 onStep: function(from, to, percent1) {
					$(this.el).find('.percent1').text(Math.round(percent1));
			}
		});
	});

$(document).ready(function () {
		$('.total_projects').easyPieChart({
			 //easing: 'easeOutBounce',
			 lineWidth:false,
			 animate: 4000,
			 scaleColor: true,
			// trailColor: '#eee',
			 lineCap: false,
			 size: 180,
			 trackColor: '#e5e5e5',
			 barColor: false,
			 onStep: function(from, to, percent2) {
					$(this.el).find('.percent2').text(Math.round(percent2));
			}
		});
	});

$(document).ready(function () {
		$('.progress_updated').easyPieChart({
			 //easing: 'easeOutBounce',
			 lineWidth:false,
			 animate: 2000,
			 scaleColor: true,
			 lineCap:false,
			 size: 180,
			 trackColor: '#e5e5e5',
			 barColor:false,
			 onStep: function(from, to, percent3) {
					$(this.el).find('.percent3').text(Math.round(percent3));
			}
		});
	});

$(document).ready(function () {
		$('.ongoing').easyPieChart({
			 //easing: 'easeOutBounce',
			 lineWidth:false,
			 animate: 4000,
			 scaleColor: true,
			 lineCap:false,
			 size: 180,
			 trackColor: '#e5e5e5',
			 barColor:false,
			 onStep: function(from, to, percent4) {
					$(this.el).find('.percent4').text(Math.round(percent4));
			}
		});
	});

$(document).ready(function () {
		$('.new_project').easyPieChart({
			 //easing: 'easeOutBounce',
			 lineWidth:false,
			 animate: 4000,
			 scaleColor: true,
			 lineCap:false,
			 size: 180,
			 trackColor: '#e5e5e5',
			 barColor:false,
			 onStep: function(from, to, percent5) {
					$(this.el).find('.percent5').text(Math.round(percent5));
			}
		});
	});	

$(document).ready(function () {
		$('.approved').easyPieChart({
			 //easing: 'easeOutBounce',
			 lineWidth:false,
			 animate: 5000,
			 scaleColor: true,
			 lineCap:false,
			 size: 180,
			 trackColor: '#e5e5e5',
			 barColor:false,
			 onStep: function(from, to, percent6) {
					$(this.el).find('.percent6').text(Math.round(percent6));
			}
		});
	});
	
	
$(document).ready(function () {
		$('.unapproved').easyPieChart({
			 //easing: 'easeOutBounce',
			 lineWidth:false,
			 animate: 5000,
			 scaleColor: true,
			 lineCap:false,
			 size: 180,
			 trackColor: '#e5e5e5',
			 barColor:false,
			 onStep: function(from, to, percent7) {
					$(this.el).find('.percent7').text(Math.round(percent7));
			}
		});
	});	

$(document).ready(function () {
		$('.missing_profile').easyPieChart({
			//easing: 'easeOutBounce',
			 lineWidth:8,
			 animate: 4000,
			 scaleColor: true,
			// trailColor: '#eee',
			 lineCap: "round",
			 size: 180,
			 trackColor: '#e5e5e5',
			 barColor: '#3da0ea',
			 onStep: function(from, to, percent9) {
					$(this.el).find('.percent9').text(Math.round(percent9));
			}
		});
	});
			
function load_dashboard_again(){
	document.getElementById("get_ministry").submit();
}
</script>
<title>Dashboard</title>
<link rel="shortcut icon" href="images/FederalLogo.jpg">
<script src="js/jquery.easing.min.js"></script>
<script src="js/jquery.easypiechart.min.js"></script>
<script type="text/javascript" src="js/arrow78.js"></script>
<script src="js/pace.min.js"></script>
<style>
.col-md-12 {
	margin: 6px auto;
}
.col-md-6 {
	margin: 3px auto;
}
.col-md-3 {
	margin: 6px auto;
}
.center {
	margin: auto;
	width: 80%;
	padding: 1px;
}
</style>
<div class="container-fluid">
  <div class="row">
    <h4 class="text-center"> Ministry Wise Dashboard for PMES Status</h4>
    <h4 class="text-center">
      <form class="form-inline" id="get_ministry" name="get_ministry" role="form" method="post" onsubmit="set_ministry()" action="dashboard_for_pmes.php?loaded=1" enctype="multipart/form-data">
        <?php
         $stmt_ministry="select distinct ministry from tbl_project_summary_pmes order by 1";
         $run_query_ministry= $conn->query($stmt_ministry);
   
         echo "<div class='input-group input-group-md align-center-div'> ";?>
        <select name='select_ministry' id='select_ministry' class='form-control hidden' size='1' onchange='load_dashboard_again()'>
        <?php echo" <option value='0'>All Ministries</option>";
         while ($row_ministry=mysqli_fetch_assoc($run_query_ministry))
               {
                  echo "<option value="."'".$row_ministry['ministry']."'";
                  if($_POST['select_ministry']==$row_ministry['ministry'])
                  {
                     echo "selected='selected'>".$row_ministry['ministry']."</option>";
                  }
                  else
                     echo ">".$row_ministry['ministry']."</option>";
               }
         echo "</select> </div>";
         if ($_GET['loaded']==1)
            null;
         else
            echo "<button id='load_dashboard' type='submit' class='btn btn-success hidden'> Load Dashboard </button>";
       ?>
      </form>
    </h4>
  </div>
  <div class="row">
    <div class="col-md-6">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h4 class="panel-title">Financial Outlay of PSDP</h4>
        </div>
        <div class="panel-body">
          <div id="outlay"> </div>
        </div>
        <div class="panel-footer">
          <h6 class="text-danger"> <strong>Note:</strong> Comparison between Allocations, Releases and Expenditures for current PSDP. <br/>
            <strong>*</strong> CPEC represents projects included in current PSDP with a keyword "CPEC"</h6>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="row">
        <div class="col-md-6 col-sm-6">
          <div class="panel panel-primary">
            <div class="panel-heading">
              <h4 class="panel-title">% Releases Against Allocations</h4>
            </div>
            <div class="panel-body">
              <div class="align-center-div" id="release_vs_expenditure" style="width:250px; height:200px">
                <div class="center"> <span class="allocation_vs_release text-center" data-percent=<?php echo $row_allocation_vs_release["total"];?>> <span class="percent"></span> </span> </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-sm-6">
          <div class="panel panel-primary">
            <div class="panel-heading">
              <h4 class="panel-title">% Expenditures Against Releases</h4>
            </div>
            <div class="panel-body">
              <div class="align-center-div" id="release_vs_expenditure" style="width:250px; height:200px">
                <div class="center"> <span class="release_vs_expenditure text-center" data-percent=<?php echo $row_release_vs_expenditure["total"];?>> <span class="percent1"></span> </span> </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6 col-sm-6">
          <div class="panel panel-primary">
            <div class="panel-heading">
              <h4 class="panel-title">Total Projects</h4>
            </div>
            <div class="panel-body">
              <div class="align-center-div" id="total_projects" style="width:250px; height:200px">
                <div class="center"> <span class="total_projects text-center"  data-percent=<?php echo $row_total_projects["total"];?>> <span class="percent2"></span> </span> </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-sm-6">
          <div class="panel panel-primary">
            <div class="panel-heading">
              <h4 class="panel-title">Progress Updated for Projects</h4>
            </div>
            <div class="panel-body">
              <div class="align-center-div" id="progress_updated" style="width:250px; height:200px">
                <div class="center"> <span class="progress_updated text-center" data-percent=<?php echo $row_progress_updated["total"];?>> <span class="percent3"></span> </span> </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-6 col-sm-6">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h4 class="panel-title">Missing Profiles for Approved Projects / On Going Projects</h4>
        </div>
        <div class="panel-body">
          <div class="align-center-div" id="ongoing" style="width:250px; height:200px">
            <div class="center"> <span class="ongoing text-center" data-percent=<?php echo $row_missing_profile["total"];?>> <span class="percent4"></span> </span> </div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="col-md-3 col-sm-6">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h4 class="panel-title">Approved Projects</h4>
        </div>
        <div class="panel-body">
          <div class="align-center-div" id="approved" style="width:250px; height:200px">
            <div class="center"> <span class="approved text-center" data-percent=<?php echo $row_approved["total"];?>> <span class="percent6"></span> </span> </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-3 col-sm-6">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h4 class="panel-title">Un-Approved Projects</h4>
        </div>
        <div class="panel-body">
          <div class="align-center-div" id="unapproved" style="width:250px; height:200px">
            <div class="center"> <span class="unapproved text-center" data-percent=<?php echo $row_unapproved["total"];?>> <span class="percent7"></span> </span> </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  
  <div class="row">
    <div class="col-md-6">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h4 class="panel-title">Monthly Progress Status</h4>
        </div>
        <div class="panel-body">
          <div id="monthly_progress"> </div>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="panel panel-primary">
        <div class="panel-heading">
          <h4 class="panel-title">Work / Cash Plan Status for 2016-17</h4>
        </div>
        <div class="panel-body">
          <div id="work_plan"> </div>
        </div>
      </div>
    </div>


    

  </div>
</div>
<div class="voffset5"></div>
<?php include("footer.php")?>
