<?php 
	error_reporting(0); // Turn off all error reporting
	if(session_status()!=PHP_SESSION_ACTIVE) 
		session_start();
	include('include/connection.php');
	date_default_timezone_set("Asia/Karachi");
	include("header.php");

if(isset($_POST['message']) && isset($_POST['visitor_name']))
{
		$remove[] = "'";
		$remove[] = '"';
		$remove[] = "-"; 
		$var_message=str_replace( $remove, "", (!empty($_POST['message'])? $_POST['message']: NULL));

$stmt_insert="insert into tbl_feedback (visitor_name,visitor_contact,visitor_email,feedback_type,feedback,dml_date,dml_time)
			  values "."('".(!empty($_POST['visitor_name']) ? $_POST['visitor_name']:NULL)."',".
			  "'".(!empty($_POST['visitor_mobile']) ? $_POST['visitor_mobile']:NULL)."',".
			  "'".(!empty($_POST['visitor_email']) ? $_POST['visitor_email']:NULL)."',".
			  "'".(!empty($_POST['feedback_type']) ? $_POST['feedback_type']:NULL)."',".
			  "'".$var_message."',".
			  "STR_TO_DATE("."'".date("d-m-Y")."'".",'%d-%m-%Y')".",".
			  "'".date("h:i")."'".")";
			  
	if ($conn->query($stmt_insert) == TRUE) 
		{?>

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog"> 
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Confirmation Message</h4>
      </div>
      <div class="modal-body">
        <h5>Your Complaint / Suggestion has been forwarded to the concerned person. Thank You! </h5>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<?php
			require("include/api_class.php");
			$obj = new SMILE_API();
			$mobile_number = preg_replace("/-/", '',$_POST['visitor_mobile']);
			$var_session=$obj->get_session();
			$var_result=$obj->send_sms($mobile_number,"8333","Thank You ".$_POST['visitor_name']." for your Complaint / Suggestion.");
			echo ("<script type='text/javascript'>
						 $('#myModal').modal('show');
					  </script>");
					  unset($_POST['visitor_name']);
					  unset($_POST['message']);
					  session_destroy();
    		header('location: contactus.php');
		} 
		else 
		{
   			echo "<font style='color:#F00; font-style:italic; font-size:20px'>";
			die("Fata Error-00214! Unable to save feedback. Please avoid single or double quotes in message.");
			echo "</font>";
		}
}
?>
<style>
.login-box-plain {
	background: none repeat scroll 0 0 #fff;
	border: 1px solid #d8d8d8;
	border-radius: 7px 7px 7px 7px;
	box-shadow: 0 4px 5px #d3d3d3;
	margin: 20px auto;
	padding: 10px 20px 20px;
	position: relative;
	min-height: 275px;
}
</style>
<title>Contact Us</title>
<link rel="shortcut icon" href="images/Federal Logo.jpg">
<link rel="stylesheet" href="css/animate.min.css" />
<div class="container">
  <div class="row">
    <div class="col-lg-8 align-center-div">
      <div class="row"> <span class="text-center">
        <div class="col-md-3 col-sm-6 col-xs-12 hidden" id="dg"> <img class="img-circle" src="images/team/shahid.jpg" alt="Shahid Mahmood">
          <h4 class="text-center">Shahid Mahmood</h4>
          <h6 class="text-center">Director General MIS</h6>
          <span class="glyphicon glyphicon-earphone" aria-hidden="true"> 051-9250762 </span> </div>
        </span> <span class="text-center">
        <div class="col-md-3 col-sm-6 col-xs-12 hidden" id="kp"> <img class="img-circle" src="images/team/yasser.jpg" alt="Yasser Qureshi">
          <h4 class="text-center">Yasser H. Qureshi</h4>
          <h6 class="text-center">Director MIS</h6>
          <span class="glyphicon glyphicon-phone" aria-hidden="true"> 0321-9131997 </span> </div>
        </span> <span class="text-center">
        <div class="col-md-3 col-sm-6 col-xs-12 hidden" id="b"> <img class="img-circle" src="images/team/aqeel.jpg" alt="Aqeel Akhtar">
          <h4 class="text-center">Aqeel Akhtar</h4>
          <h6 class="text-center">Director MIS</h6>
          <span class="glyphicon glyphicon-phone" aria-hidden="true"> 0322-5348981 </span> </div>
        </span> <span class="text-center">
        <div class="col-md-3 col-sm-6 col-xs-12 hidden" id="dd"> <img class="img-circle" src="images/team/faisal.jpg" alt="Faisal Saeed">
          <h4 class="text-center">Faisal Saeed</h4>
          <h6 class="text-center">Deputy Director MIS</h6>
          <span class="glyphicon glyphicon-phone" aria-hidden="true"> 0333-5197869 </span> </div>
        </span> </div>
      <div class="voffset7"></div>
      <div class="row"> <span class="text-center">
        <div class="col-md-3 col-sm-6 col-xs-12 hidden" id="he"> <img class="img-circle" src="images/team/irshad.jpg" alt="Irshad Khaliq">
          <h4 class="text-center">Irshad Khaliq</h4>
          <h6 class="text-center">Network Engineer</h6>
          <span class="glyphicon glyphicon-phone" aria-hidden="true"> 0333-9654336 </span> </div>
        </span> <span class="text-center">
        <div class="col-md-3 col-sm-6 col-xs-12 hidden" id="ne"> <img class="img-circle" src="images/team/shahzad.jpg" alt="Shahzad Iqbal">
          <h4 class="text-center">Shahzad Iqbal</h4>
          <h6 class="text-center">Hardware Engineer</h6>
          <span class="glyphicon glyphicon-phone" aria-hidden="true"> 0301-8151572 </span> </div>
        </span> <span class="text-center">
        <div class="col-md-3 col-sm-6 col-xs-12 hidden" id="dps1"> <img class="img-circle" src="images/team/qamar.jpg" alt="Qamar">
          <h4 class="text-center">Qamar Zaman</h4>
          <h6 class="text-center">Data Processing Supervisor</h6>
          <span class="glyphicon glyphicon-phone" aria-hidden="true"> 0333-5129271 </span> </div>
        </span> <span class="text-center">
        <div class="col-md-3 col-sm-6 col-xs-12 hidden" id="dps2"> <img class="img-circle" src="images/team/arshad.jpg" alt="Arshad Munir">
          <h4 class="text-center">Arshad Munir</h4>
          <h6 class="text-center">Data Processing Supervisor</h6>
          <span class="glyphicon glyphicon-phone" aria-hidden="true"> 0345-5933554 </span> </div>
        </span> </div>
    </div>
    <div class="col-lg-3 login-box-plain hidden algin-center" id="feedback" style="margin-left:20px">
    <h3 class="text-center"> Feedback </h3>
    <form id="feedback_form" method="POST" role="form" name="feedback_form"  enctype="multipart/form-data">
      <div class="input-group input-group-md"> <span class="input-group-addon" id="basic-addon2"> <span class="glyphicon glyphicon-user" aria-hidden="true"></span> </span>
        <input type="text" id="visitor_name" name="visitor_name" class="form-control" placeholder="Enter Your Name" aria-describedby="basic-addon2">
      </div>
      <div class="voffset3"></div>
      <div class="alert alert-danger hidden" id="visitor_name_empty" role="alert" aria-hidden="true"> Please Enter Your Name </div>
      <div class="voffset3"></div>
      <div class="input-group input-group-md"> <span class="input-group-addon" id="basic-addon3"> <span class="glyphicon glyphicon-phone" aria-hidden="true"></span> </span>
        <input type="text" id="visitor_mobile" name="visitor_mobile" class="form-control" placeholder="Enter Valid Mobile #" aria-describedby="basic-addon3">
      </div>
      <div class="voffset3"></div>
      <div class="alert alert-danger hidden" id="visitor_mobile_empty" role="alert" aria-hidden="true"> Please Enter Mobile Number </div>
      <div class="alert alert-danger hidden" id="valid_mobile_no" role="alert" aria-hidden="true"> Please Enter Valid Mobile Number </div>
      <div class="input-group input-group-md">
        <select name="feedback_type" class="form-control" size="1" >
          <option value=" Complaint ">Complaint </option>
          <div class="form-actions">
          <option value=" Suggestion ">Suggestion </option>
        </select>
      </div>
      <div class="voffset3"></div>
      <textarea id="message" name="message" class="form-control" rows="3" id="textArea" placeholder="Enter Your Message">
      </textarea>
      <div class="voffset3"></div>
      <div class="alert alert-danger hidden" id="message_empty" role="alert" aria-hidden="true">Please Enter Message </div>
      <div class="voffset3"></div>
      <button type="button" class="btn btn-success" onclick="return check_empty()">Send Feedback</button>
      </div>
    </form>
  </div>
</div>
<div class="voffset5"></div>
<?php include("footer.php")?>
<script>

$(document).ready(function () 
{
	$("#message").val('');
	setTimeout(function(){
							$('#dg').removeClass('hidden').addClass('animated bounceInLeft');
							$('#kp').removeClass('hidden').addClass('animated bounceInRight');
							$('#b').removeClass('hidden').addClass('animated bounceInLeft');
							$('#dd').removeClass('hidden').addClass('animated bounceInRight');
						 },900); 
	
	setTimeout(function(){
							$('#he').removeClass('hidden').addClass('animated bounceInLeft');
							$('#ne').removeClass('hidden').addClass('animated bounceInRight');
							$('#dps1').removeClass('hidden').addClass('animated bounceInLeft');
							$('#dps2').removeClass('hidden').addClass('animated bounceInRight');
						 },1800); 

	setTimeout(function(){
							$('#feedback').removeClass('hidden').addClass('animated bounceInRight');
						 },2800); 
	
	
});

function check_empty ()
	{
		var regex_mobile=/^03\d{2}\d{7}$|^03\d{2}-\d{7}$/;
		var regex_mobile_code=/^0300|0301|0302|0303|0304|0305|0306|0307|0308|0309|0310|0311|0312|0313|0314|0315|0316|0320|0321|0322|0323|0324|0325|0326|0330|0331|0332|0333|0334|0335|0336|0337|0340|0341|0342|0343|0344|0345|0345|0346|0347|0346|0399|0398$/;
		var regex_mobile_zero=/.*0{4,7}.*/;

	if ($('#visitor_name').val()=='')
	{

		$('#visitor_name_empty').removeClass('hidden').hide().fadeIn().fadeTo(1000, 100).fadeOut(900, function()
		{
			$("#visitor_name_empty").addClass('hidden');
		});
		
		$('#visitor_name').focus();
		return false;
	}
	
	else if ($('#visitor_mobile').val()=='')
	{
		$('#visitor_mobile_empty').removeClass('hidden').hide().fadeIn().fadeTo(1000, 100).fadeOut(900, function()
		{
			$("#visitor_mobile_empty").addClass('hidden');
		}); 
		$('#visitor_mobile').focus();
		return false;
	}
	else if (!$('#visitor_mobile').val().match(regex_mobile) || !$('#visitor_mobile').val().match(regex_mobile_code) || $('#visitor_mobile').val().match(regex_mobile_zero))
	{
		$('#valid_mobile_no').removeClass('hidden').hide().fadeIn().fadeTo(1000, 100).fadeOut(900, function()
		{
			$("#valid_mobile_no").addClass('hidden');
		}); 
		$('#visitor_mobile').focus();
		return false;
	}	
	else if ($('#message').val()=='')
	{

		$('#message_empty').removeClass('hidden').hide().fadeIn().fadeTo(1000, 100).fadeOut(900, function()
		{
			$("#message_empty").addClass('hidden');
		});
		
		$('#message').focus();
		return false;
	}
	else
	{
		$('#feedback_form').submit();
	}
	
}
</script>