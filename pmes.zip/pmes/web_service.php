<?php
$header = "Content-Type: application/json";
header($header);
$dbLink = mysqli_connect('localhost','root','','pmes');
if (!$dbLink) {
    $row = array("project_id" => "Database Error");
    print json_encode($row);
} else {
    $query = "select project_id,project_name,psdp_number,fiscal_year,physical_progress,concat(for_month,'-',for_year) month_year from tbl_project_summary where psdp_number order by psdp_number";
    $result = mysqli_query($dbLink,$query);
	 for ($i=0;$i<=1012;$i++)
		  {
			  $row = $result->fetch_array(MYSQLI_ASSOC);
			  print json_encode($row);
		  }

    
    mysqli_close($dbLink);
} // End else condition (for database connection)
?>