<?php 
//error_reporting(0); // Turn off all error reporting
if(session_status()!=PHP_SESSION_ACTIVE) 
	session_start();
if(!isset($_SESSION['username']))
header('location: index.php');

include("header.php");
?>
<title>Feedback</title>
<link rel="stylesheet" type="text/css" href="css/datatable.css"/>
<link rel="stylesheet" type="text/css" href="css/jquery.dataTables.css"/>
<link rel="stylesheet" type="text/css" href="css/responsive.dataTables.min.css"/>
<link rel="stylesheet" type="text/css" href="css/responsive.bootstrap.min.css"/>
<script src="js/pace.min.js"></script>

<script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
<script type="text/javascript" language="javascript" src="js/jquery.dataTables.min.js"></script>
<script type="text/javascript" language="javascript" src="js/dataTables.responsive.min.js"></script>
<script type="text/javascript" language="javascript" class="init">
		$(document).ready(function() {
			$('#t1').DataTable( {
					responsive: true
				} );
		} );
	</script>
<div class="container">
 
      <?php
include('include/connection.php');
$stmt = "select feedback_id,visitor_name,visitor_contact,visitor_email,feedback_type,feedback,dml_date,dml_time from tbl_feedback
		 order by feedback_id desc";
	
$run_query= $conn->query($stmt);
if($run_query == FALSE) 
				{ 
  				  die(mysql_error()); // TODO: better error handling
				}
echo "<table id='t1' class='display responsive' width='100%'>\n";
echo "<thead>\n";
echo "<tr>\n";
echo "<th>ID</th>\n";
echo "<th>Name</th>\n";
echo "<th>Contact</th>\n";
echo "<th>Email ID</th>\n";
echo "<th>Type</th>\n";
echo "<th>Message</th>\n";
echo "<th>Date</th>\n";
echo "<th>Time</th>\n";
echo "</tr>\n";
echo "</thead>\n";
echo "<tbody>\n";

while ($row = mysqli_fetch_assoc($run_query))
 {
	 
    echo "<tr>\n";
    //foreach ($row as $item) {
        echo "<td align='center'>" . $row["feedback_id"] . "</td>\n";
		echo "<td align='left'>" . $row["visitor_name"] . "</td>\n";
		echo "<td align='center'>" . $row["visitor_contact"] . "</td>\n";
		echo "<td align='center'>" . $row["visitor_email"]  . "</td>\n";
		echo "<td align='center'>" . $row["feedback_type"]  . "</td>\n";
		echo "<td align='center'> <textarea name rows='4' cols='50'>" . $row["feedback"]  . "</textarea></td>\n";
		echo "<td align='center'>" . $row["dml_date"] . "</td>\n";
		echo "<td align='center'>" .$row["dml_time"] . "</td>\n";
    //}
    echo "</tr>";
	
}
echo "</tbody>";
echo "</table>";

?>

</div>
<?php include("footer.php")?>
