<link rel="shortcut icon" href="images/FederalLogo.jpg">
<?php 
error_reporting(0); // Turn off all error reporting
if(session_status()!=PHP_SESSION_ACTIVE) 
	session_start();
date_default_timezone_set("Asia/Karachi");
if(!isset($_SESSION['username']))
	header('location: index.php');
include('include/connection.php');
echo "<input type='hidden' id='check_role' name='check_role' value=".$_SESSION['roleid'].">";
include("header.php");
$projectid=mysqli_real_escape_string($conn,$_GET['projectid'])+0;
$stmt = "select forum,date_format(approval_date,'%d-%m-%Y') approval_date,
		 project_status, project_id, project_name, ministry, objective, project_cost, 
		 expected_completion_cost, date_format(commencement_date,'%d-%m-%Y') commencement_date, 
		 date_format(completion_date,'%d-%m-%Y') completion_date, 
		 date_format(expected_completion_date,'%d-%m-%Y') expected_completion_date, for_month, for_year, 
		 psdp_number, allocation, release_upto, releases, release_remarks, expenditure_upto, expenditure, 
		 expenditure_remarks, physical_progress, progress_remarks, cost_over_run, reason_cost_over_run,
		 time_over_run,reason_time_over_run,issue, image_path_1, image_path_2, image_path_3, 
		 project_director, contact_1, contact_2, fiscal_year,date_format(entry_date,'%d-%m-%Y') entry_date, 
		 date_format(revised_approval_date,'%d-%m-%Y') revised_approval_date,
		 date_format(revised_completion_date,'%d-%m-%Y') revised_completion_date, 
		 dml_date,dml_time,user_name,scope,funding,email from tbl_project_summary where project_id=".$projectid;

$run_query= $conn->query($stmt);
if ($run_query->num_rows > 0)
		{
			$row = mysqli_fetch_assoc($run_query);
		}
		else
		{
			echo "<font style='color:#F00; font-style:italic; font-size:20px'>";
			die("Fata Error-00215! Unable to execute query. Please contact Director-MIS (0321-9131997).");
			echo "</font>";
		}
function isImage($img){
      return (bool)getimagesize($img);
  }
if($_GET['action']=="add")
{
$image1_success=1;
$image2_success=1;
$image3_success=1;
		if (($_FILES['image1']['name'])!='')
		{
			$targetPath = "uploaded/";
			$image1 = $_POST['image1_name'];
			$filename=$_FILES['image1']['name'];
			$file1 = $filename;
			$exploded1 = explode('.', $file1);
			$ext = end($exploded1);
			//$ext = end(explode('.', $filename));
			$target1 = $targetPath.$_POST['project_id'].'_1_'.date("d-m-Y").'.'.$ext;
			$image1_path=$_POST['project_id'].'_1_'.date("d-m-Y").'.'.$ext;
			if(isImage($_FILES['image1']['tmp_name']) && $_FILES['image1']['size'] <= 624288 )
			{
				if(move_uploaded_file($_FILES['image1']['tmp_name'],$target1))
				{
					unlink($image1_path);
				}
				else
				{
					$target1 = $image1;
				}
			}
			else
				{
					echo "<font style='color:#F00; font-style:italic; font-size:20px'>";
           		 		die($_FILES['image1']['name']." is not an image file or its size is more than maximum limit. Please upload again.");
           			echo "</font>";
				}
		}
		else
		{
			if (isset($_FILES['image1']['size']))
				$image1_success=1;
				else
				$image1_success=2;
				$image1_path=$_POST['image_path_1'];		
		}
		
		if (($_FILES['image2']['name'])!='')
		{
			$targetPath = "uploaded/";
			$image2 = $_POST['image2_name'];
			$filename2=$_FILES['image2']['name'];
			$file2 = $filename2;
			$exploded2 = explode('.', $file2);
			$ext2 = end($exploded2);
			//$ext2 = end(explode('.', $filename2));
			$target2 = $targetPath.$_POST['project_id'].'_2_'.date("d-m-Y").'.'.$ext2;
			$image2_path=$_POST['project_id'].'_2_'.date("d-m-Y").'.'.$ext2;
			
			if(isImage($_FILES['image2']['tmp_name']) && $_FILES['image2']['size'] <= 624288)
			{
				if(move_uploaded_file($_FILES['image2']['tmp_name'],$target2))
				{
					unlink($image2_path);
				}
				else
				{
					$target2 = $image2;
				}
			}
			else
				{
					echo "<font style='color:#F00; font-style:italic; font-size:20px'>";
           		 		die($_FILES['image2']['name']." is not an image file or its size is more than maximum limit. Please upload again.");
           			echo "</font>";
				}
		}
		else
		{
			if (isset($_FILES['image2']['size']))
				$image2_success=1;
				else
				$image2_success=2;
			$image2_path=$_POST['image_path_2'];		
		}
	if (($_FILES['image3']['name'])!='')
		{
			$targetPath = "uploaded/";
			$image3 = $_POST['image3_name'];
			$filename3=$_FILES['image3']['name'];
			$file3 = $filename3;
			$exploded3 = explode('.', $file3);
			$ext3 = end($exploded3);
			//$ext3 = end(explode('.', $filename3));
			$target3 = $targetPath.$_POST['project_id'].'_3_'.date("d-m-Y").'.'.$ext3;
			$image3_path=$_POST['project_id'].'_3_'.date("d-m-Y").'.'.$ext3;
			if(isImage($_FILES['image3']['tmp_name']) && $_FILES['image3']['size'] <= 624288)
			{
			
				if(move_uploaded_file($_FILES['image3']['tmp_name'],$target3))
				{
					unlink($image3_path);
					
				}
				else
				{
					$target3 = $image3;
				}
			}
			else
				{
					echo "<font style='color:#F00; font-style:italic; font-size:20px'>";
           		 		die($_FILES['image3']['name']." is not an image file or its size is more than maximum limit. Please upload again.");
           			echo "</font>";
				}
		}
		else
		{
			if (isset($_FILES['image3']['size']))
				$image3_success=1;
				else
				$image3_success=2;
				
			$image3_path=$_POST['image_path_3'];		
		}
	if ($image1_success==1 && $image2_success==1 && $image3_success==1)
	{
		$remove[] = "'";
		$remove[] = '"';
		$remove[] = "-"; 
		$var_objective=str_replace( $remove, "", (!empty($_POST['objective'])? $_POST['objective']: NULL));
		$var_scope=str_replace( $remove, "",(!empty($_POST['scope'])? $_POST['scope']: NULL));
		$var_issue=str_replace( $remove, "",(!empty($_POST['issue'])? $_POST['issue']: NULL));
		$var_release_remarks=str_replace( $remove, "",(!empty($_POST['release_remarks'])? $_POST['release_remarks']: NULL));
		$var_expenditure_remakrs=str_replace( $remove, "",(!empty($_POST['expenditure_remarks'])? $_POST['expenditure_remarks']: NULL));
		$var_reason_cost_over_run=str_replace( $remove, "",(!empty($_POST['reason_cost_over_run'])? $_POST['reason_cost_over_run']: NULL));
		$var_reason_time_over_run=str_replace( $remove, "",(!empty($_POST['reason_time_over_run'])? $_POST['reason_time_over_run']: NULL));
		$var_progress_remarks=str_replace( $remove, "",(!empty($_POST['progress_remarks'])? $_POST['progress_remarks']: NULL));
		
		
$stmt_update = "update  tbl_project_summary set 
				objective="."'".$var_objective."'".
				",project_cost=".(!empty($_POST['project_cost'])? $_POST['project_cost']:'NULL').
				",expected_completion_cost=".(!empty($_POST['expected_completion_cost']) ? $_POST['expected_completion_cost']:'NULL').
				",commencement_date=STR_TO_DATE("."'".(!empty($_POST['commencement_date']) ? $_POST['commencement_date']:NULL)."'".",'%d-%m-%Y')".
				",completion_date=STR_TO_DATE("."'".(!empty($_POST['completion_date']) ? $_POST['completion_date']:NULL)."'".",'%d-%m-%Y')".
				",revised_completion_date=STR_TO_DATE("."'".(!empty($_POST['revised_completion_date']) ? $_POST['revised_completion_date'] : NULL)."'".",'%d-%m-%Y')".
				",expected_completion_date=STR_TO_DATE("."'".(!empty($_POST['expected_completion_date']) ? $_POST['expected_completion_date'] : NULL)."'".",'%d-%m-%Y')".
				",approval_date=STR_TO_DATE("."'".(!empty($_POST['approval_date']) ? $_POST['approval_date'] : NULL)."'".",'%d-%m-%Y')".
				",revised_approval_date=STR_TO_DATE("."'".(!empty($_POST['revised_approval_date']) ? $_POST['revised_approval_date'] : NULL)."'".",'%d-%m-%Y')".
				",forum="."'".(!empty($_POST['forum']) ? $_POST['forum']:NULL)."'".
				",for_month="."'".(!empty($_POST['for_month']) ? $_POST['for_month']:NULL)."'".
				",for_year=".(!empty($_POST['for_year']) ? $_POST['for_year']:'NULL').
				",psdp_number=".(!empty($_POST['psdp_number']) ? $_POST['psdp_number']:'NULL').
				",allocation=".(!empty($_POST['allocation']) ? $_POST['allocation']:'NULL').
				",release_upto=".(!empty($_POST['release_upto']) ? $_POST['release_upto']:0).
				",releases=".(!empty($_POST['release'])?$_POST['release']:0).
				",release_remarks="."'".$var_release_remarks."'".
				",expenditure_upto=".(!empty($_POST['expenditure_upto'])?$_POST['expenditure_upto']:0).
				",expenditure=".(!empty($_POST['expenditure'])?$_POST['expenditure']:0).
				",expenditure_remarks="."'".$var_expenditure_remakrs."'".
				",physical_progress=".(!empty($_POST['physical_progress'])?$_POST['physical_progress']:0).
				",progress_remarks="."'".$var_progress_remarks."'".
				",cost_over_run=".(!empty($_POST['cost_over_run'])?$_POST['cost_over_run']:'NULL').
				",reason_cost_over_run="."'".$var_reason_cost_over_run."'".
				",time_over_run=".(!empty($_POST['time_over_run'])?$_POST['time_over_run']:'NULL').
				",reason_time_over_run="."'".$var_reason_time_over_run."'".
				",issue="."'".$var_issue."'".
				",image_path_1="."'".$image1_path."'".
				",image_path_2="."'".$image2_path."'".
				",image_path_3="."'".$image3_path."'".
				",project_director="."'".(!empty($_POST['project_director']) ? $_POST['project_director']:NULL)."'".
				",contact_1="."'".(!empty($_POST['contact_1']) ? $_POST['contact_1']:NULL)."'".
				",contact_2="."'".(!empty($_POST['contact_2']) ? $_POST['contact_2']:NULL)."'".
			//	",entry_date=STR_TO_DATE("."'".(!empty($_POST['entry_date']) ? $_POST['entry_date']:NULL)."'".",'%d-%m-%Y')".
				",dml_date=STR_TO_DATE("."'".date("d-m-Y")."'".",'%d-%m-%Y')".
				",dml_time="."'".date("h:i")."'".
				",user_name="."'".$_SESSION['username']."'".
				",scope="."'".$var_scope."'".
				",email="."'".(!empty($_POST['email']) ? $_POST['email']:NULL)."'".
				",funding="."'".(!empty($_POST['funding']) ? $_POST['funding']:NULL)."'".
				" where project_id=".$projectid;

		if ($conn->query($stmt_update) == TRUE) 
		{
			if ($_POST['contact_2']!='0399-9999999' && $_POST['contact_2']!='03999999999' && $_SESSION['username']<>'arshahzad' && $_SESSION['username']<>'tahir' && $_SESSION['username']<>'shahzina' && $_SESSION['username']<>'choudhry' && $_SESSION['username']<>'bilalkhan' && $_SESSION['username']<>'fozia' && $_SESSION['username']<>'hina' && $_SESSION['username']<>'arshad' && $_SESSION['username']<>'dps_qamar' )
			{
				require("include/api_class.php");
				$obj = new SMILE_API();
				$mobile_number = preg_replace("/-/", '', $_POST['contact_2']);
				$var_session=$obj->get_session();
				$var_result=$obj->send_sms($mobile_number,"8583","From One Pager Module: Progress of the Project (PSDP # ".$_POST['psdp_number'].") for the month of ".$_POST['for_month']." has been updated successfully. For information CALL 0321-9131997");
			$stmt_insert="insert into tbl_message (project_id,mobile,dml_date,dml_time,status) values (".$projectid.",'".$mobile_number."',"."STR_TO_DATE("."'".date("d-m-Y")."'".",'%d-%m-%Y')".","."'".date("h:i")."',"."'".$var_result."')";
			//echo $stmt_insert;
			$run_query_insert= $conn->query($stmt_insert);
			}
    		//header('location: search_project.php');
			//echo $stmt_update;
			echo '<script type="text/javascript">';
					echo 'window.location.href="'.'search_project.php'.'";';
					echo '</script>';

		} 
		else 
		{
   			echo "<font style='color:#F00; font-style:italic; font-size:20px'>";
			die("Fata Error-00214! Unable to execute query. Please avoid single or double quotes in fields.");
			echo "</font>";
		}
	}
	else
	{
		echo "<font style='color:#F00; font-style:italic; font-size:20px'>";
			die("Fata Error-00213! Please make sure you have uploaded image files having size less than 0.5 MB.");
		echo "</font>";
	}
}
?>
<title>One Pager Entry Form</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap-datepicker.css">
<script src="js/pace.min.js"></script>
<script type="text/javascript" src="js/arrow78.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<script language="javascript">


function MM_validateForm() { //v4.0
  if (document.getElementById){
    var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
    for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=document.getElementById(args[i]);
      if (val) { nm=val.name; if ((val=val.value)!="") {
        if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
          if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
        } else if (test!='R') { num = parseFloat(val);
          if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
          if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
            min=test.substring(8,p); max=test.substring(p+1);
            if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
      } } }
	  // else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n';
	  }
    } if (errors) { alert('The following error(s) occurred:\n'+errors);document.forms['update_form'][nm].focus(); }
    document.MM_returnValue = (errors == '');
	
} }

$(document).ready(function(){
	
	$('.input-group.date').datepicker({
    format: "dd-mm-yyyy",
    startView: 2,
    todayBtn: true,
    clearBtn: true,
    autoclose: true,
    todayHighlight: true,
    toggleActive: true
});
	
	var incoming=$("#check_role").val();

	if (incoming == 1 || incoming == 12 || incoming == 18 || incoming == 24 || incoming == 33 || incoming == 42 || incoming == 44)
		{
			document.getElementById("Update_Record").disabled = false;
		}
		else
		{
			document.getElementById("Update_Record").disabled = true;
		}

});

function check_month_year()
{
    var regex=/^[\d\.\-]+$/;
	//var regex_mobile=/^((\+92)|(0092))-{0,1}\d{3}-{0,1}\d{7}$|^\d{11}$|^\d{4}-\d{7}$/;
	var regex_mobile=/^03\d{2}\d{7}$|^03\d{2}-\d{7}$/;
	var regex_mobile_code=/^0300|0301|0302|0303|0304|0305|0306|0307|0308|0309|0310|0311|0312|0313|0314|0315|0316|0317|0320|0321|0322|0323|0324|0325|0326|0330|0331|0332|0333|0334|0335|0336|0337|0340|0341|0342|0343|0344|0345|0345|0346|0347|0355|0364|0399|0398$/;
	var regex_mobile_zero=/.*0{4,7}.*/;
	if ($('#for_month').val()==0)
	{
		$('#month_empty').removeClass('hidden').hide().fadeIn().fadeTo(1000, 100).fadeOut(1500, function()
		{
			$("#month_empty").addClass('hidden');
		});
		$('#for_month').focus();
		return false;
	}
	else if ($('#for_year').val()==0)
	{
		
		$('#year_empty').removeClass('hidden').hide().fadeIn().fadeTo(1000, 100).fadeOut(1500, function()
		{
			$("#year_empty").addClass('hidden');
		});
		$('#for_year').focus();
		return false;
	}
	else if ($('#physical_progress').val()=='')
	{
		$('#progress_empty').removeClass('hidden').hide().fadeIn().fadeTo(1000, 100).fadeOut(1500, function()
		{
			$("#progress_empty").addClass('hidden');
		});
		$('#physical_progress').focus();
		return false;
	}
	else if (document.getElementById('project_cost').value=='')
	{
		$('#cost_empty').removeClass('hidden').hide().fadeIn().fadeTo(1000, 100).fadeOut(1500, function()
		{
			$("#cost_empty").addClass('hidden');
		});
		$('#project_cost').focus();
		return false;
	}
	else if ($('#allocation').val()=='')
	{
		$('#allocation_empty').removeClass('hidden').hide().fadeIn().fadeTo(1000, 100).fadeOut(1500, function()
		{
			$("#allocation_empty").addClass('hidden');
		});
		$('#allocation').focus();
		return false;
	}
	else if ($('#release_upto').val()=='')
	{
		$('#release_empty').removeClass('hidden').hide().fadeIn().fadeTo(1000, 100).fadeOut(1500, function()
		{
			$("#release_empty").addClass('hidden');
		});
		$('#release_upto').focus();
		return false;
	}
	else if ($('#expenditure_upto').val()=='')
	{
		$('#expenditure_empty').removeClass('hidden').hide().fadeIn().fadeTo(1000, 100).fadeOut(1500, function()
		{
			$("#expenditure_empty").addClass('hidden');
		});
		$('#expenditure_upto').focus();
		return false;
	}
	else if ($('#project_director').val()=='')
	{
		$('#pd_empty').removeClass('hidden').hide().fadeIn().fadeTo(1000, 100).fadeOut(1500, function()
		{
			$("#pd_empty").addClass('hidden');
		});
		$('#project_director').focus();
		return false;
	}
	else if ($('#contact_1').val()=='' || !$('#contact_1').val().match(regex))
	{
		$('#contact_1_empty').removeClass('hidden').hide().fadeIn().fadeTo(1000, 100).fadeOut(1500, function()
		{
			$("#contact_1_empty").addClass('hidden');
		});
		$('#contact_1').focus();
		return false;
	}
	else if ($('#contact_2').val()=='' || !$('#contact_2').val().match(regex_mobile) || !$('#contact_2').val().match(regex_mobile_code) || $('#contact_2').val().match(regex_mobile_zero))
	{
		$('#contact_2_empty').removeClass('hidden').hide().fadeIn().fadeTo(1000, 100).fadeOut(1500, function()
		{
			$("#contact_2_empty").addClass('hidden');
		});
		$('#contact_2').focus();
		return false;
	}
	else if ($('#forum').val()==0)
	{
		$('#forum_empty').removeClass('hidden').hide().fadeIn().fadeTo(1000, 100).fadeOut(1500, function()
		{
			$("#forum_empty").addClass('hidden');
		});
		$('#forum').focus();
		return false;
	}
	else if ($('#for_year').val()==2017 )
	{
		if ($('#for_month').val()=='JULY' || $('#for_month').val()=='AUGUST' || $('#for_month').val()=='SEPTEMBER' || $('#for_month').val()=='OCTOBER' || $('#for_month').val()=='NOVEMBER' || $('#for_month').val()=='DECEMBER')
		{
			alert('You can only give progress for Fiscal Year 2016-2017. Please check your progress month and year');
			$('#for_year').focus();
			return false;
		}
	}
	else if ($('#for_year').val()==2016 )
	{
		if ($('#for_month').val()=='JANUARY' || $('#for_month').val()=='FEBRUARY' || $('#for_month').val()=='MARCH' || $('#for_month').val()=='APRIL' || $('#for_month').val()=='MAY' || $('#for_month').val()=='JUNE')
		{
			alert('You can only give progress for Fiscal Year 2016-2017. Please check your progress month and year');
			$('#for_year').focus();
			return false;
		}
	}
	else
	{
		document.forms["update_form"].submit();
	}
}

	function printreport(incomingcall)
	{
	window.location="one_pager.php?printprojectid="+incomingcall ;
	
	}	
	
	function timeline(incomingcall)
	{
	window.location="timeline.php?projectid="+incomingcall ;
	
	}

</script>

<div class="container">
  <div class="row">
    <div class="page-header">
      <h4 class="text-center text-danger"><?php echo  $row["project_name"];?></h4>
    </div>
  </div>
  <div class="row">
    <div class="col-sm-6">
      <h5 class="text-danger blink"> Fields in RED color are compulsory</h5>
    </div>
  </div>
  <div class="voffset3"></div>
  <form id="update_form" name="update_form" class="form-horizontal" method="post" role="form" onSubmit="return check_month_year()" action="project_summary.php?action=add&projectid=<?php echo $projectid;?>" enctype="multipart/form-data" >
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Project ID</label>
      <div class="col-sm-2">
        <input class="form-control" id="project_id" name="project_id" value="<?php echo $row["project_id"]; ?>" disabled />
        <input type="hidden" id="project_id" name="project_id" value="<?php echo $row["project_id"]; ?>" />
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">PSDP Number</label>
      <div class="col-sm-2">
        <input class="form-control" id="psdp_number" name="psdp_number" value="<?php echo $row["psdp_number"]; ?>" disabled />
        <input type="hidden" id="psdp_number" name="psdp_number" value="<?php echo $row["psdp_number"]; ?>" />
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Ministry</label>
      <div class="col-sm-9">
        <input class="form-control" id="ministry" name="ministry" value="<?php echo $row["ministry"];?>" disabled />
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Last Progress for Month- Year</label>
      <div class="col-sm-3">
        <input class="form-control" value="<?php echo $row["for_month"].' - '.$row["for_year"];?>" disabled />
      </div>
    </div>
    <div class="form-group has-error">
      <label class="col-sm-3 control-label">Progress for the Month </label>
      <div class="col-sm-3">
        <select name="for_month" id="for_month" class="form-control"  >
          <option value="0" >Select Month</option>
          <option value="JULY">July</option>
          <option value="AUGUST">August</option>
          <option value="SEPTEMBER">Septemeber</option>
          <option value="OCTOBER">October</option>
          <option value="NOVEMBER">November</option>
          <option value="DECEMBER">December</option>
          <option value="JANUARY">January</option>
          <option value="FEBRUARY">February</option>
          <option value="MARCH">March</option>
          <option value="APRIL">April</option>
          <option value="MAY">May</option>
          <option value="JUNE">June</option>
        </select>
      </div>
      <div class="col-sm-3">
        <div class="alert alert-danger hidden" id="month_empty" role="alert" aria-hidden="true"> Please Select Month </div>
      </div>
    </div>
    <div class="form-group has-error">
      <label class="col-sm-3 control-label">Progress for the Year </label>
      <div class="col-sm-3">
        <select name="for_year" id="for_year" class="form-control"  >
          <option value="0" >Select Year</option>
          <option value="2016">2016</option>
          <option value="2017">2017</option>
        </select>
      </div>
      <div class="col-sm-3">
        <div class="alert alert-danger hidden" id="year_empty" role="alert" aria-hidden="true"> Please Select Year </div>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Objectives</label>
      <div class="col-sm-9">
        <textarea class="form-control" rows="4" id="objective" name="objective"><?php echo $row["objective"];  ?></textarea>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Scope</label>
      <div class="col-sm-9">
        <textarea class="form-control" rows="2" id="scope" name="scope"><?php echo $row["scope"];  ?></textarea>
      </div>
    </div>
    <div class="form-group has-error">
      <label class="col-sm-3 control-label text-right">Project Cost</label>
      <div class="col-sm-3">
        <div class="input-group">
          <input class="form-control"    name="project_cost" id="project_cost" onBlur="MM_validateForm('project_cost','','RisNum');return document.MM_returnValue" value="<?php echo $row["project_cost"]; ?>" aria-describedby="project_cost" />
          <span class="input-group-addon">Rs. in Millions</span> </div>
      </div>
      <div class="col-sm-3">
        <div class="alert alert-danger hidden" id="cost_empty" role="alert" aria-hidden="true"> Please Enter Project Cost </div>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Project Revised Cost</label>
      <div class="col-sm-3">
        <div class="input-group">
          <input class="form-control"   name="expected_completion_cost" id="expected_cost" onBlur="MM_validateForm('expected_cost','','NisNum');return document.MM_returnValue" value="<?php echo $row["expected_completion_cost"]; ?>" aria-describedby="revised_cost" />
          <span class="input-group-addon">Rs. in Millions</span> </div>
      </div>
    </div>
    <div class="form-group has-error">
      <label class="col-sm-3 control-label">Forum </label>
      <div class="col-sm-2">
        <select name="forum" id="forum" class="form-control"  >
          <option value="0" >Select Forum</option>
          <option value="N/A" <?php if ($row["forum"] =='N/A') { echo "selected"; } ?> >N/A</option>
          <option value="UNAPPROVED" <?php if ($row["forum"] =='UNAPPROVED') { echo "selected"; } ?> >UNAPPROVED</option>
          <option value="DDWP" <?php if ($row["forum"] =='DDWP') { echo "selected"; } ?> >DDWP</option>
          <option value="CDWP"  <?php if ($row["forum"] =='CDWP') { echo "selected";  } ?>>CDWP</option>
          <option value="ECNEC"  <?php if ($row["forum"] =='ECNEC') { echo "selected";  } ?>>ECNEC</option>
        </select>
      </div>
      <div class="col-sm-3">
        <div class="alert alert-danger hidden" id="forum_empty" role="alert" aria-hidden="true"> Please Select Forum </div>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Approval Date</label>
      <div class="col-sm-3">
        <div class="input-group date">
          <input class="form-control" id="approval_date" name="approval_date" value="<?php if ($row["approval_date"]<>'00-00-0000') echo $row["approval_date"]; ?>" readonly aria-describedby="approval_date" />
          <span class="input-group-addon" title="Click to Open Calendar"><span class="glyphicon glyphicon-calendar text-danger"></span> </span> </div>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Revised Approval Date </label>
      <div class="col-sm-3">
        <div class="input-group date">
          <input class="form-control" id="revised_approval_date" name="revised_approval_date" value="<?php if ($row["revised_approval_date"]<>'00-00-0000') echo $row["revised_approval_date"]; ?>"  readonly aria-describedby="revised_approval_date" />
          <span class="input-group-addon" title="Click to Open Calendar"><span class="glyphicon glyphicon-calendar text-danger"></span> </span> </div>
        <h6 class="text-right text-danger">(in case of Revision)</h6>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Commencement Date</label>
      <div class="col-sm-3">
        <div class="input-group date">
          <input class="form-control" id="commencement_date" name="commencement_date" value="<?php if ($row["commencement_date"]<>'00-00-0000') echo $row["commencement_date"]; ?>" readonly aria-describedby="commencement_date" />
          <span class="input-group-addon" title="Click to Open Calendar"><span class="glyphicon glyphicon-calendar text-danger"></span> </span> </div>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Completion Date</label>
      <div class="col-sm-3">
        <div class="input-group date">
          <input class="form-control" id="completion_date" name="completion_date" value="<?php if ($row["completion_date" ]<>'00-00-0000') echo  $row["completion_date" ]; ?>" readonly aria-describedby="completion_date" />
          <span class="input-group-addon" title="Click to Open Calendar"><span class="glyphicon glyphicon-calendar text-danger"></span> </span> </div>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Revised Completion Date </label>
      <div class="col-sm-3">
        <div class="input-group date">
          <input class="form-control" id="revised_completion_date" name="revised_completion_date" value="<?php if ($row["revised_completion_date"]<>'00-00-0000') echo $row["revised_completion_date"]; ?>"  readonly aria-describedby="revised_completion_date" />
          <span class="input-group-addon" title="Click to Open Calendar"><span class="glyphicon glyphicon-calendar text-danger"></span> </span> </div>
        <h6 class="text-right text-danger">(in case of Revision)</h6>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Expected Completion Date</label>
      <div class="col-sm-3">
        <div class="input-group date">
          <input class="form-control" id="expected_completion_date" name="expected_completion_date" value="<?php if ($row["expected_completion_date"]<>'00-00-0000') echo  $row["expected_completion_date"]; ?>" readonly aria-describedby="expected_completion_date" />
          <span class="input-group-addon" title="Click to Open Calendar"><span class="glyphicon glyphicon-calendar text-danger"></span> </span> </div>
      </div>
    </div>
    <div class="form-group has-error">
      <label class="col-sm-3 control-label text-right">Allocation in FY 2016-17</label>
      <div class="col-sm-3">
        <div class="input-group">
          <input class="form-control"  name="allocation" id="allocation"   onBlur="MM_validateForm('allocation','','RisNum');return document.MM_returnValue" value="<?php echo  $row["allocation"];  ?>" aria-describedby="allocation" />
          <span class="input-group-addon">Rs. in Millions</span> </div>
      </div>
      <div class="col-sm-3">
        <div class="alert alert-danger hidden" id="allocation_empty" role="alert" aria-hidden="true"> Please Enter Allocation </div>
      </div>
    </div>
    <div class="form-group has-error">
      <label class="col-sm-3 control-label text-right">Releases upto June, 2016</label>
      <div class="col-sm-3">
        <div class="input-group">
          <input class="form-control" name="release_upto" id="release_upto"   onBlur="MM_validateForm('release_upto','','RisNum');return document.MM_returnValue" value="<?php echo  $row["release_upto"]; ?>" aria-describedby="release_upto" />
          <span class="input-group-addon">Rs. in Millions</span> </div>
      </div>
      <div class="col-sm-3">
        <div class="alert alert-danger hidden" id="release_empty" role="alert" aria-hidden="true"> Please Enter Releases </div>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Releases in FY 2016-17</label>
      <div class="col-sm-3">
        <div class="input-group">
          <input class="form-control" name="release" id="release" onBlur="MM_validateForm('release','','RisNum');return document.MM_returnValue" value="<?php echo  $row["releases"]; ?>" aria-describedby="release" />
          <span class="input-group-addon">Rs. in Millions</span> </div>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Any Remarks for Releases</label>
      <div class="col-sm-9">
        <textarea class="form-control" rows="2" id="release_remarks" name="release_remarks"><?php echo  $row["release_remarks"];?></textarea>
      </div>
    </div>
    <div class="form-group has-error">
      <label class="col-sm-3 control-label text-right">Expenditures upto June, 2016</label>
      <div class="col-sm-3">
        <div class="input-group">
          <input class="form-control" name="expenditure_upto" id="expenditure_upto"   onBlur="MM_validateForm('expenditure_upto','','RisNum');return document.MM_returnValue" value="<?php echo  $row["expenditure_upto"]; ?>" aria-describedby="expenditure_upto" />
          <span class="input-group-addon">Rs. in Millions</span> </div>
      </div>
      <div class="col-sm-3">
        <div class="alert alert-danger hidden" id="expenditure_empty" role="alert" aria-hidden="true"> Please Enter Expenditure </div>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Expenditures in FY 2016-17</label>
      <div class="col-sm-3">
        <div class="input-group">
          <input class="form-control" name="expenditure" id="expenditure" onBlur="MM_validateForm('expenditure','','RisNum');return document.MM_returnValue" value="<?php echo  $row["expenditure"]; ?>" aria-describedby="expenditure" />
          <span class="input-group-addon">Rs. in Millions</span> </div>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Any Remarks for Expenditures</label>
      <div class="col-sm-9">
        <textarea class="form-control" rows="2" id="expenditure_remarks" name="expenditure_remarks"><?php echo  $row["expenditure_remarks"]; ?></textarea>
      </div>
    </div>
    <div class="form-group has-error">
      <label class="col-sm-3 control-label text-right">Overall Physical Progress</label>
      <div class="col-sm-2">
        <div class="input-group">
          <input class="form-control" name="physical_progress"  id="physical_progress"   onBlur="MM_validateForm('physical_progress','','RinRange0:110');return document.MM_returnValue" value="<?php echo  $row["physical_progress"]; ?>" aria-describedby="physical_progress" />
          <span class="input-group-addon">%</span> </div>
      </div>
      <div class="col-sm-3">
        <div class="alert alert-danger hidden" id="progress_empty" role="alert" aria-hidden="true"> Please Enter Physical Progress </div>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Major Work Done</label>
      <div class="col-sm-9">
        <textarea class="form-control" rows="2" id="progress_remarks" name="progress_remarks"><?php echo  $row["progress_remarks"];  ?></textarea>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Benefits</label>
      <div class="col-sm-9">
        <textarea class="form-control" rows="2" id="reason_cost_over_run" name="reason_cost_over_run"><?php echo  $row["reason_cost_over_run"];  ?></textarea>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Reason for Delay / Cost Over Run</label>
      <div class="col-sm-9">
        <textarea class="form-control" rows="2" id="reason_time_over_run" name="reason_time_over_run"><?php echo  $row["reason_time_over_run"]; ?></textarea>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">Bottlenecks / Any Other Issue</label>
      <div class="col-sm-9">
        <textarea class="form-control" rows="2" id="issue" name="issue"><?php echo  $row["issue"]; ?></textarea>
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">
      Image 1 <br/>
      <h5 class="text-primary text-right"> (Image with JPEG or GIF extensions having size not more than 0.5 MB) </h5>
      </label>
      <div class="col-sm-6">
        <input class="form-control" type="hidden" readonly   id="image_path_1" name="image_path_1" value=<?php echo  $row["image_path_1"]  ?>   />
        <img src="uploaded/<?php echo  $row["image_path_1"]  ?>" width="100" height="100"/>
        <input name="image1" type="file"  id="image1" />
        <a href="<?php echo $resExtra['image1']; ?>" target="_blank"><?php echo $resExtra['image1']; ?></a>
        <input type="hidden" name="image1_name" value="<?php echo $resExtra['image1']; ?>" />
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">
      Image 2 <br/>
      <h5 class="text-primary text-right"> (Image with JPEG or GIF extensions having size not more than 0.5 MB) </h5>
      </label>
      <div class="col-sm-6">
        <input class="form-control" type="hidden" readonly   id="image_path_2" name="image_path_2" value=<?php echo  $row["image_path_2"]  ?>  />
        <img src="uploaded/<?php echo  $row["image_path_2"]  ?>" width="100" height="100"/>
        <input name="image2" type="file"  id="image2" />
        <a href="<?php echo $resExtra['image2']; ?>" target="_blank"><?php echo $resExtra['image2']; ?></a>
        <input type="hidden" name="image2_name" value="<?php echo $resExtra['image2']; ?>" />
      </div>
    </div>
    <div class="form-group">
      <label class="col-sm-3 control-label text-right">
      Image 3 <br/>
      <h5 class="text-primary text-right"> (Image with JPEG or GIF extensions having size not more than 0.5 MB) </h5>
      </label>
      <div class="col-sm-6">
        <input class="form-control" type="hidden" readonly   id="image_path_3" name="image_path_3" value=<?php echo  $row["image_path_3"]  ?>  />
        <img src="uploaded/<?php echo  $row["image_path_3"]  ?>" width="100" height="100"/>
        <input name="image3" type="file"  id="image3" />
        <a href="<?php echo $resExtra['image3']; ?>" target="_blank"><?php echo $resExtra['image3']; ?></a>
        <input type="hidden" name="image3_name" value="<?php echo $resExtra['image3']; ?>" />
      </div>
    </div>
    <div class="form-group has-error">
      <label class="col-sm-3 control-label text-right">Project Director</label>
      <div class="col-sm-4">
        <input class="form-control" name="project_director"  id="project_director"   onBlur="MM_validateForm('project_director','','R');return document.MM_returnValue" value="<?php echo  $row["project_director"]; ?>"/>
      </div>
      <div class="col-sm-3">
        <div class="alert alert-danger hidden" id="pd_empty" role="alert" aria-hidden="true"> Please Enter PD's Name </div>
      </div>
    </div>
    <div class="form-group has-error">
      <label class="col-sm-3 control-label text-right">Office Telephone</label>
      <div class="col-sm-4">
        <div class="input-group">
          <input class="form-control" name="contact_1"  id="contact_1"   onBlur="MM_validateForm('contact_1','','R');return document.MM_returnValue" value="<?php echo  $row["contact_1"]; ?>" aria-describedby="contact_1" />
          <span class="input-group-addon">CODE-NUMBER</span> </div>
      </div>
      <div class="col-sm-3">
        <div class="alert alert-danger hidden" id="contact_1_empty" role="alert" aria-hidden="true"> Please Enter Valid Office # </div>
      </div>
    </div>
    <div class="form-group has-error">
      <label class="col-sm-3 control-label text-right">Mobile</label>
      <div class="col-sm-4">
        <div class="input-group">
          <input class="form-control" name="contact_2"  id="contact_2"   onBlur="MM_validateForm('contact_2','','R');return document.MM_returnValue" value="<?php echo  $row["contact_2"]; ?>" aria-describedby="contact_2" />
          <span class="input-group-addon">CODE-NUMBER</span> </div>
      </div>
      <div class="col-sm-3">
        <div class="alert alert-danger hidden" id="contact_2_empty" role="alert" aria-hidden="true"> Please Enter Valid Mobile # </div>
      </div>
    </div>
    <div class="form-group has-error">
      <label class="col-sm-3 control-label text-right">Email</label>
      <div class="col-sm-4">
        <input class="form-control" name="email"  id="email" onBlur="MM_validateForm('email','','NisEmail');return document.MM_returnValue" value="<?php echo  $row["email"];  ?>" />
      </div>
    </div>
    <div class="form-group">
      <div class="col-sm-3"> </div>
      <div class="col-sm-2">
        <input type="submit" class="btn btn-success" name="Update_Record" id="Update_Record" value="Update Project Data" onclick="check_month_year();"/>
      </div>
      <div class="col-sm-2"> <?php echo "<input class='btn btn-warning btn-md' type='button' id='value". $row["project_id"]."' value='Print One Pager' onclick= 'printreport(".$row["project_id"].")' />"?> </div>
      <div class="col-sm-2"> <?php echo "<input class='btn btn-warning btn-md'  type='button' id='timeline". $row["project_id"]."' value='Show Timeline' onclick= 'timeline(".$row["project_id"].")' />"; ?> </div>
    </div>
  </form>
</div>
<div class="voffset5"></div>
<?php include("footer.php");?>
