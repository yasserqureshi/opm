<!-- Footer Start Here -->
<footer class="footer">
 	<div class="container">
    	<p class="text-muted">Developed by Director-MIS &copy; Copyrights 2008-2017, MIS Section, Projects Wing, Islamabad </p>
  </div>
</footer>

</body>
</head>
<!-- Footers Ends Here-->