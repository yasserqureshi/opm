<!-- Header Starts Here -->
<!DOCTYPE html>
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" href="images/FederalLogo.jpg">
    <!-- CSS Starts here -->
    <link rel="stylesheet"  href="css/bootstrap.css" id="bootstrap_css" media="screen">
    <link rel="stylesheet"  href="css/sticky-footer.css">
    <link rel="stylesheet" href="css/pmes.css" media="screen">
    <link rel="stylesheet" href="css/animate.min.css" />
    <link rel="stylesheet" href="css/font-awesome.min.css" />
    <!-- CSS Ends here -->
    
    
    <!-- JS Starts here -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/bootstrap-dropdown.js"></script>
	 <script type="text/javascript" src="js/highcharts.js"></script>
	 <script src="js/exporting.js"></script>
	 <script src="js/highcharts-more.js"></script>
    <script src="js/waypoints.min.js"></script> 
    <script src="js/jquery.counterup.js"></script>
    <script src="js/jquery.shuffleLetters.js"></script>


    <!-- JS Ends here -->
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src=".js/respond.min.js"></script>
    <![endif]-->

<script>
$(document).ready(function () 
{
		var username = $("#username_value").val();
		var role_id = $("#role_id").val();
		if (username=='master' || username=='one_pager' || username=='dc' || username=='secretarypnd' || role_id==42 )
			{
				null;
			}
		else
			{
				$('#dashboard').addClass('disabled');
				$('#ministry_wise').addClass('disabled');
				$('[data-toggle="tooltip"]').prop('title','You are not privileged to use Dashboard');
				$('[data-toggle="tooltip"]').tooltip();  
			}
	});
	
$(document).ready(function () 
{
	var container = $("#shuffle-text");
	container.shuffleLetters();
});
</script>

<body>
	<nav class="navbar navbar-default .navbar.navbar-default.navbar-static-top" role="navigation">
      <div class="container-fluid">
        <div class="navbar-header">
        <div class="logo"></div>
        <a <?php 
				if(!isset($_SESSION['username']))        
        		echo 'id="shuffle-text"';
		  		?> href="search_project.php" class="navbar-brand">One Pager Module (OPM)</a>
						  <button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbar-main">
							<span class="glyphicon glyphicon-list" aria-hidden="true"></span>
						 </button>
        </div>
        <div class="navbar-collapse collapse" id="navbar-main">
          <ul class="nav navbar-nav navbar-right">
          <?php 
				if(isset($_SESSION['username']))
         			{
						echo '<li><a href="search_project.php">Home</a></li>
							<li class="dropdown">
							  <a class="dropdown-toggle"  data-toggle="dropdown" id="reports" role="button" aria-haspopup="true" aria-expanded="false">Reports<span class="caret"></span></a>
							  <ul class="dropdown-menu" aria-labelledby="reports">
								<li><a href="single_liner.php">Single Liner</a></li>
							  </ul>
							</li>
							<li id="ministry_wise" class="dropdown" data-toggle="tooltip" data-placement="auto">
							  <a class="dropdown-toggle" role="button" aria-haspopup="true" aria-expanded="false" data-toggle="dropdown" id="dashboard">Dashboard<span class="caret"></span></a>
							  <ul class="dropdown-menu" aria-labelledby="dashboard">
								<li><a href="dashboard_for_minister.php">Ministry Wise</a></li>
								<li><a href="dashboard_for_minister_province.php">Province Wise</a></li>
								<li><a href="dashboard_for_minister_sector.php">Sector Wise</a></li>
								<li role="separator" class="divider"></li>
								<li><a href="dashboard_for_pmes.php">PMES Status</a></li>
							  </ul>
							</li>';
					}
            ?>
            <li><a href="contactus.php">Contact Us</a></li>
            <li><a href="faq.php">FAQs</a></li>
            <?php 
						if(!isset($_SESSION['username']))
							echo "<li><a href='logout.php'>".'Login'."</a></li>";
						else 
						{	
							echo "<li><a href='logout.php'>Logout - <span class='text-danger blink'>".strtoupper($_SESSION['username'])."</span></a></li>";
							echo '<input id="username_value" type="hidden" value='."'".$_SESSION['username']."'".'>';
							echo '<input id="role_id" type="hidden" value='.$_SESSION['roleid'].'>';
							
						}
					?>
          </ul>
        </div>
      </div>
    </nav>

<!-- Header Ends Here -->   