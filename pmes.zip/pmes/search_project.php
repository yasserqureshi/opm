<?php 
	error_reporting(0); // Turn off all error reporting
	if(session_status()!=PHP_SESSION_ACTIVE) 
		session_start();

if(!isset($_SESSION['username']) && !isset($_SESSION['email']))
	{
		header('location: index.php');
	}

include("header.php");
?>

<title>Select Project</title>
<link rel="shortcut icon" href="images/Federal Logo.jpg">
<link rel="stylesheet" type="text/css" href="css/datatable.css"/>
<link rel="stylesheet" type="text/css" href="css/jquery.dataTables.css"/>
<link rel="stylesheet" type="text/css" href="css/responsive.dataTables.min.css"/>
<!--<link rel="stylesheet" type="text/css" href="css/responsive.bootstrap.min.css"/>-->
<!--<link rel="stylesheet" type="text/css" href="css/buttons.dataTables.min.css"/>-->

<script src="js/pace.min.js"></script>


<script type="text/javascript" language="javascript" src="js/jquery.dataTables.min.js"></script>
<script type="text/javascript" language="javascript" src="js/dataTables.responsive.min.js"></script>
<!--<script type="text/javascript" language="javascript" src="js/dataTables.buttons.min.js"></script>
<script type="text/javascript" language="javascript" src="js/buttons.colVis.min.js"></script>-->

<script type="text/javascript" language="javascript" class="init">
		$(document).ready(function() 
		{
			 var table = $('#projects').DataTable({
				  
				  "aLengthMenu": [[10, 25, 50, 100, 500, -1], [10, 25, 50, 100, 500, "All"]],
				   responsive: true,
				  //"scrollX": true,
				  "oLanguage": {
						 		"sSearch": "Search on any field:",
								sLengthMenu: "Show _MENU_ Projects"
								}
				/* dom: 'Bfrtip', // To show columns manually
						buttons: [
							'colvis'
						],*/
			});
				
			 function format(value,value1) {
			 
			 return '<div class="slider"> <table cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;">'+
						'<tr>'+
							'<td>Updated By :</td>'+
							'<td>'+ value +'</td>'+
						'</tr>'+
						'<tr>'+
							'<td>Project Director Mobile:</td>'+
							'<td>'+ value1 +'</td>'+
						'</tr>'+
					'</table> </div>';
  			}
		 
			 
		
			  // Add event listener for opening and closing details
			  $('#projects').on('click', 'td.details-control', function () {
				  var tr = $(this).closest('tr');
				  var row = table.row(tr);
		
				  if (row.child.isShown()) {
					  // This row is already open - close it
					  $('div.slider', row.child()).slideUp( function () {
						row.child.hide();
						tr.removeClass('shown');
					} );
				  } else {
					  // Open this row
					  row.child(format(tr.data('child-value'),tr.data('child-value1'))).show();
					  tr.addClass('shown');
					  $('div.slider', row.child()).slideDown();
				  }
			  });
		  });
	 
	</script>


<div class="container" style="font-size:15px; color:#000;">
  <div class="row">
    <div class="col-lg-12">
      <?php

include('include/connection.php');
$stmt_search = "select project_id,project_name,
		ifnull(expected_completion_cost,project_cost) project_cost,
		psdp_number,dml_date,dml_time,projectid, ministry,
		for_month,user_name,contact_2,pmes_profile
		from tbl_project_summary a,userprojects b
		where a.project_id = b.projectid
 		and username='".$_SESSION['username']."' and emailaddress='".$_SESSION['email']."'"." order by dml_date desc,psdp_number ";

$run_query_search= $conn->query($stmt_search);
if($run_query_search == FALSE) 
	{ 
	  die(mysql_error()); // TODO: better error handling
	}

echo "<table id='projects' class='display responsive' width='100%'>\n";
echo "<thead>\n";
echo "<tr>\n";
echo "<th class='dt-center all'>Options</th>\n";
echo "<th class='dt-center all'>PSDP# (2016-2017)</th>\n";
echo "<th class='dt-center min-tablet-l'>Ministry</th>\n";
echo "<th class='dt-center desktop'>Project Title</th>\n";
echo "<th class='dt-center desktop'>PMES Profile</th>\n";
echo "<th class='dt-center min-mobile-l'>Project Cost</th>\n";
echo "<th class='dt-center min-tablet-l'>Last Updated</th>\n";
echo "<th class='dt-center desktop'>Progress Month</th>\n";
echo "<th class='desktop'></th>\n";
echo "</tr>\n";
echo "</thead>\n";
echo "<tbody>\n";

while ($row_search = mysqli_fetch_assoc($run_query_search))
 {
    	echo "<tr data-child-value=".$row_search["user_name"]." data-child-value1= ".$row_search["contact_2"]."> \n";

		echo " <td align='center'><div class='input-group input-group-md'> 
		<select name='actions' id='actions' style='width:100px' class='form-control btn btn-success' onchange='setValue(".$row_search["project_id"].",value)'>
			<option value='0' >Select</option>
			<option value='UPDATE'>Update / View</option>
			<option value='HISTORY'>History</option>
			<option value='TIMELINE'>Timeline</option>
			<option value='PRINT'>Print</option>
		</select></div></td>\n";
        echo "<td align='center'>" . $row_search["psdp_number"] . "</td>\n";
		echo "<td>" . $row_search["ministry"] . "</td>\n";
		echo "<td>" . $row_search["project_name"] . "</td>\n";
		echo "<td align='center'> <h4><span class='label label-";
		if ($row_search["pmes_profile"]=="Yes")
				echo "success";
		else
				echo "danger";
		echo " '>" . $row_search["pmes_profile"] . "</span></h3></td>\n";
		echo "<td align='center'>" . $row_search["project_cost"]  . "</td>\n";
		echo "<td align='center' title=".'"'.$row_search["dml_time"].'"'.">". $row_search["dml_date"] . "</td>\n";
		echo "<td align='center'>" .$row_search["for_month"] . "</td>\n";
		echo "<td align='center' class='details-control'></td>\n";
    echo "</tr>";
}
echo "</tbody>";
echo "</table>";
?>
    </div>
  </div>
</div>
<div class="voffset6"></div>
<?php include("footer.php")?>
<script language="javascript" >
	function setValue(incomingcall,incomingoption)
	{
		if (incomingoption=='UPDATE')
			window.location="project_summary.php?projectid="+incomingcall ;
		else if (incomingoption=='HISTORY')
			window.location="project_history.php?projectid="+incomingcall ;
		else if (incomingoption=='TIMELINE')
			window.location="timeline.php?projectid="+incomingcall ;
		else if (incomingoption=='PRINT')
			window.location="one_pager.php?printprojectid="+incomingcall ;
	}	
</script>
