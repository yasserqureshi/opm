<?php
error_reporting(0); // Turn off all error reporting
date_default_timezone_set("Asia/Karachi");
require("../include/api_class.php");
$obj = new SMILE_API();

$mobile_numbers = array('0321-9110447');

for ($counter=0;$counter<count($mobile_numbers);$counter++)
{
	$mobile_numbers[$counter] = preg_replace("/-/", '',$mobile_numbers[$counter]);
	$var_session=$obj->get_session();
	$var_result=$obj->send_sms($mobile_numbers[$counter],"8583","From: Planning Commission. Projects Wing wishes you a very Happy Birthday and many many happy returns of the day.");
	echo $counter."    ".$mobile_numbers[$counter]."    ".$var_result."<br/>";
}
?>
<title> Birthdat Wishes </title>