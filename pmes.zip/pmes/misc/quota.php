<?php
	require("../include/api_class.php");
	$obj = new SMILE_API();
	$var_session=$obj->get_session();
	$var_result=$obj->getQuota();
	echo ($var_result);
?>
