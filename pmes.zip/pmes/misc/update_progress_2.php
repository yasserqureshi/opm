<?php
error_reporting(0); // Turn off all error reporting
date_default_timezone_set("Asia/Karachi");
require("../include/api_class.php");
$obj = new SMILE_API();

$mobile_numbers = array('');

//$message="REMINDER! Please update One Pager progress for June, 2016 of project having PSDP # 1111. For more information call 0321-9131997 or login www.psdp.net/pmes";

$message="One Pager Module for PSDP 2016-17 is Online NOW. Please update JULY-2016 Progress of your Project(s). For more information call 0321-9131997 or login www.psdp.net/pmes";


for ($counter=0;$counter<count($mobile_numbers);$counter++)
{
	$mobile_numbers[$counter] = preg_replace("/-/", '',$mobile_numbers[$counter]);
	$var_session=$obj->get_session();
	$var_result=$obj->send_sms($mobile_numbers[$counter],"8583",$message);
	echo $counter."    ".$mobile_numbers[$counter]."    ".$var_result."<br/>";
}
?>
<title> Update One Pager Progress </title>