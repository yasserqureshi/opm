<?php
error_reporting(0); // Turn off all error reporting
date_default_timezone_set("Asia/Karachi");
require("../include/api_class.php");
$obj = new SMILE_API();

$message1 = "PSDP Facts: Did you know that more than 69% of PSDP projects are time over run. For more facts login www.psdp.net/pmes";

$message2 = "PSDP Facts: Did you know that SPI of PSDP 2015-16 is 36%. This means that a project with 2 years duration will be completed in 5 years approx.";

$message3 = "PSDP Facts: Did you know that more than 35% of PSDP projects have 0% to 25% of Physical Progress. For more facts login www.psdp.net/pmes";

$message4 = "PSDP Facts: Did you know that more than 27% of PSDP projects have 76% to 100% of Physical Progress. For more facts login www.psdp.net/pmes";

$message5 = "PSDP Facts: Total releases till date are Rs. 329.42 (B) as per Planning Commission's website.  For more information login www.psdp.net/pmes";

$mobile_numbers = array('0333-5140776','0333-5197869','0345-5933554','0333-5129271','0333-9654336','0322-5348981','0300-5922688','0321-5653133','0333-5542256','0334-5308895','0333-9409866','0321-4887833','0321-9131997');


for ($counter=0;$counter<count($mobile_numbers);$counter++)
{
	$mobile_numbers[$counter] = preg_replace("/-/", '',$mobile_numbers[$counter]);
	$var_session=$obj->get_session();
	$var_result=$obj->send_sms($mobile_numbers[$counter],"8583",$message5);
	echo $counter."    ".$mobile_numbers[$counter]."    ".$var_result."<br/>";
}
?>
<title> Update One Pager Progress </title>