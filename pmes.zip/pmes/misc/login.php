<?php
if(session_status()!=PHP_SESSION_ACTIVE) 
	session_start();
	
error_reporting(0); // Turn off all error reporting
	
if(isset($_POST['username']) && isset($_POST['email']))
{	
	
	include('include/connection.php');
	$username=mysqli_real_escape_string($conn,$_POST['username']);
	$email=mysqli_real_escape_string($conn,$_POST['email']);
	
	$stmt = "select roleid from tbl_project_summary a,userprojects b
			where a.project_id =b.projectid
			and username='$username' and emailaddress='$email'";
			
	$run_query= $conn->query($stmt);
				if($run_query == FALSE) 
				{ 
  				  die(mysql_error()); // TODO: better error handling
				}
		if($row=mysqli_fetch_assoc($run_query))
		{
			$check_password=0;
			$_SESSION['roleid']=$row["roleid"];
			$_SESSION['username']=  $_POST['username'];
			$_SESSION['email']=  $_POST['email'];
					echo '<script type="text/javascript">';
					echo 'window.location.href="'.'search_project.php'.'";';
					echo '</script>';
		}
		else
		{
			$check_password=1;
		}
}

?>
<title>One Pager Module (OPM)</title>
<style>
.login-box-plain {
	background: none repeat scroll 0 0 #fff;
	border: 1px solid #d8d8d8;
	border-radius: 7px 7px 7px 7px;
	box-shadow: 0 4px 5px #d3d3d3;
	margin: 20px auto;
	padding: 0px 20px 20px;
	position: relative;
	min-height: 275px;
}
</style>

<section id="login" class="visible">
  <div class="container">
    <div class="row">
      <div class="voffset3"></div>
      <div class="login-box-plain">
        <div class="voffset3"></div>
        <h5 class="text-right"> Visitor No:
          <?php include("count_visitor.php") ?>
        </h5>
        <div class="voffset4"></div>
        <h3 class="text-center">
        MIS Section, Projects Wing
        </h4>
        <h5 class="text-center">Planning Commission, Islamabad </h5>
        <div class="voffset4"></div>
        <form id="login_form" role="form" method="POST" enctype="multipart/form-data" >
          <div class="input-group input-group-md"> <span class="input-group-addon" id="basic-addon"> <span class="glyphicon glyphicon-user" aria-hidden="true"></span> </span>
            <input type="text" id="username" name="username" class="form-control" placeholder="PMES Username" required aria-describedby="basic-addon">
          </div>
          <div class="voffset3"></div>
          <div class="alert alert-danger hidden" id="username_empty" role="alert" aria-hidden="true">
          	Please Enter PMES Username
          </div>
          <div class="voffset3"></div>
          <div class="input-group input-group-md"> <span class="input-group-addon" id="basic-addon1">@</span>
            <input type="password" id="email" name="email" class="form-control" required placeholder="PMES Email Address" aria-describedby="basic-addon1">
          </div>
          <div class="voffset3"></div>
          <div class="alert alert-danger hidden" id="email_empty" role="alert" aria-hidden="true">
          	Please Enter PMES Email Address
          </div>
          <div class="alert alert-danger hidden" id="email_invalid" role="alert" aria-hidden="true">
          	Please Enter Valid Email Address
          </div>
          <div class="voffset3"></div>
          <div class="form-actions">
            <button type="submit" class="btn btn-success" onclick="return check_empty()">Login</button>
          </div>
          <div class="voffset3"></div>
          <?php 
				if ($check_password == 1)
				{
			?>
          <!-- Trigger the modal with a button -->
        
          <!-- Modal -->
          <div id="myModal" class="modal fade" role="dialog">
            <div class="modal-dialog"> 
              
              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Warning!</h4>
                </div>
                <div class="modal-body">
                  <h5>You have entered invalid <strong>username</strong> or <strong>email address</strong>. <br/><br/>
                  Please contact <strong>Director-MIS</strong> on 0321-9131997 for information.
                  </h5>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
              </div>
            </div>
          </div>
          
          <?php
				echo ("<script type='text/javascript'>
						 $('#myModal').modal('show');
					  </script>");
				$check_password = 0;
				unset($_SESSION['username']);
				unset($_SESSION['roleid']);
				unset($_SESSION['email']);
				$username='';
				$email='';
				session_destroy();
				} 
			?>
        </form>
        <div class="voffset3"></div>
        <span class="glyphicon glyphicon-question-sign" aria-hidden="true"></span> <a href="#" onclick="swapScreen('forgot');return false;">Forgot Email Address</a> <br>
        <div class="voffset3"></div>
        <span class="glyphicon glyphicon-save" aria-hidden="true"></span> <a href="downloads/User Manual for One Pager Application.pdf">Download User Manual</a> <br>
      </div>
    </div>
  </div>
</section>
<!-- FORGOT PASSWORD -->
<section id="forgot" class="invisible">
  <div class="container">
    <div class="row">
      <div class="voffset3"></div>
      <div class="login-box-plain">
        <h3 class="text-center">
        Request for Password
        </h3>
        <div class="voffset5"></div>
        <form id="send_sms_form" role="form" method="POST" enctype="multipart/form-data">
          <div class="input-group input-group-md"> <span class="input-group-addon" id="basic-addon2"> <span class="glyphicon glyphicon-user" aria-hidden="true"></span> </span>
            <input type="text" id="username_forget" class="form-control" placeholder="PMES Username" aria-describedby="basic-addon2">
          </div>
          <div class="voffset3"></div>
          <div class="alert alert-danger hidden" id="username_empty1" role="alert" aria-hidden="true">
          	Please Enter PMES Username
          </div>
          <div class="voffset3"></div>
          <div class="input-group input-group-md"> <span class="input-group-addon" id="basic-addon3"> <span class="glyphicon glyphicon-phone" aria-hidden="true"></span> </span>
            <input type="text" id="mobile" class="form-control" placeholder="Enter Valid Mobile No." aria-describedby="basic-addon3">
          </div>
          <div class="voffset3"></div>
          <div class="alert alert-danger hidden" id="mobile_empty" role="alert" aria-hidden="true">
          	Please Enter Mobile Number
          </div>
          <div class="alert alert-danger hidden" id="valid_mobile_no" role="alert" aria-hidden="true">
          	Please Enter Valid Mobile Number
          </div>
          <div class="voffset3"></div>
          <div class="form-actions">
            <button type="button" class="btn btn-success" onclick="return send_sms()">Send Request</button>
          </div>
        </form>
        <div class="voffset3"></div>
        <div class="login-helpers"> <a href="#" onclick="swapScreen('login');return false;">Back to Login</a> <br>
        </div>
      </div>
    </div>
  </div>
</section>

<script type="text/javascript">

function isValidEmailAddress(emailAddress) {
    var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
    return pattern.test(emailAddress);
};

function send_sms ()
	{
		var regex_mobile=/^03\d{2}\d{7}$|^03\d{2}-\d{7}$/;
		var regex_mobile_code=/^0300|0301|0302|0303|0304|0305|0306|0307|0308|0309|0310|0311|0312|0313|0314|0315|0316|0320|0321|0322|0323|0324|0325|0326|0330|0331|0332|0333|0334|0335|0336|0337|0340|0341|0342|0343|0344|0345|0345|0346|0347|0346|0399|0398$/;
		var regex_mobile_zero=/.*0{4,7}.*/;
	
	if ($('#username_forget').val()=='')
	{
		$('#username_empty1').removeClass('hidden').hide().fadeIn().fadeTo(1000, 100).fadeOut(900, function()
		{
			$("#username_empty1").addClass('hidden');
		});
		
		$('#username_forget').focus();
		return false;
	}
	else if ($('#mobile').val()=='')
	{
		$('#mobile_empty').removeClass('hidden').hide().fadeIn().fadeTo(1000, 100).fadeOut(900, function()
		{
			$("#mobile_empty").addClass('hidden');
		}); 
		$('#mobile').focus();
		return false;
	}
	else if (!$('#mobile').val().match(regex_mobile) || !$('#mobile').val().match(regex_mobile_code) || $('#mobile').val().match(regex_mobile_zero))
	{
		$('#valid_mobile_no').removeClass('hidden').hide().fadeIn().fadeTo(1000, 100).fadeOut(900, function()
		{
			$("#valid_mobile_no").addClass('hidden');
		}); 
		$('#mobile').focus();
		return false;
	}		
	else
	{
		window.location="send_sms.php?mobile_for_sms="+$('#mobile').val()+"&username_for_sms="+$('#username_forget').val() ;
		
	}
	
}

function check_empty ()
	{
	if ($('#username').val()=='')
	{

		$('#username_empty').removeClass('hidden').hide().fadeIn().fadeTo(1000, 100).fadeOut(900, function()
		{
			$("#username_empty").addClass('hidden');
		});
		
		$('#username').focus();
		return false;
	}
	else if ($('#email').val()=='')
	{
		$('#email_empty').removeClass('hidden').hide().fadeIn().fadeTo(1000, 100).fadeOut(900, function()
		{
			$("#email_empty").addClass('hidden');
		}); 
		$('#email').focus();
		return false;
	}
	else if(!isValidEmailAddress($('#email').val()))
	{
		$('#email_invalid').removeClass('hidden').hide().fadeIn().fadeTo(1000, 100).fadeOut(900, function()
		{
			$("#email_invalid").addClass('hidden');
		}); 
		$('#email').focus();
		return false;
	}		
	else
	{
		
		$('#login_form').submit();
	}
	
}

function swapScreen(id) {
	$('.visible').removeClass('visible animated fadeInUp');
	$('#'+id).addClass('visible animated fadeInUp');
}
</script>