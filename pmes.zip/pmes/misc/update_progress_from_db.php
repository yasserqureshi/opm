<?php
error_reporting(0); // Turn off all error reporting
date_default_timezone_set("Asia/Karachi");

include('../include/connection.php');
$stmt_sms = "select psdp_number,contact_2 from tbl_project_summary
where contact_2 is not null and  contact_2 <> '' and contact_2 not like ('%9999%') and for_month <> 'JUNE'
and psdp_number not in (653)
and psdp_number > 695
and project_id in (select project_id from tbl_project_summary 
			group by contact_2
			having count(*)=1)
order by ministry,psdp_number,contact_2";
$run_query_sms= $conn->query($stmt_sms);

require("../include/api_class.php");
$obj = new SMILE_API();

while ($row_sms = mysqli_fetch_assoc($run_query_sms))
 {

	$mobile = preg_replace("/-/", '',$row_sms["contact_2"]);
	$var_session=$obj->get_session();
	$var_result=$obj->send_sms($mobile,"8583","REMINDER! Please update One Pager progress for June, 2016 of project having PSDP # ".$row_sms["psdp_number"].". For more information call 0321-9131997 or login www.psdp.net/pmes");
	echo $row_sms["psdp_number"]."    ".$mobile."    ".$var_result."<br/>";
 }
?>
<title> Update One Pager Progress </title>