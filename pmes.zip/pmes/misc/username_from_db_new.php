<?php
error_reporting(0); // Turn off all error reporting
date_default_timezone_set("Asia/Karachi");

include('../include/connection.php');
$stmt_sms = "select psdp_number,username,emailaddress,contact_2 from send_login_credential
where status is null";
$run_query_sms= $conn->query($stmt_sms);

require("../include/api_class.php");
$obj = new SMILE_API();

while ($row_sms = mysqli_fetch_assoc($run_query_sms))
 {

	$mobile = preg_replace("/-/", '',$row_sms["contact_2"]);
	$var_session=$obj->get_session();
	$var_result=$obj->send_sms($mobile,"8583","To update progress of PSDP# ".$row_sms["psdp_number"]." Login One Pager Module using Username: ".$row_sms["username"]." and Email ID: ".$row_sms["emailaddress"].". Visit www.psdp.net/pmes");

	//$var_result=$obj->send_sms($mobile,"8583","Dear Sir/Madam, If PSDP # ".$row_sms["psdp_number"]." is not your project then please call 0321-9131997 to resolve the issue. Regards,");
	
	echo $row_sms["psdp_number"]."    ".$mobile."    ".$var_result."<br/>";
	
	$stmt_update="update send_login_credential set status='SENT' where psdp_number="."'".$row_sms["psdp_number"]."'";
	$run_query_update= $conn->query($stmt_update);
	
 }
?>
<title> Login Credentials from DB </title>