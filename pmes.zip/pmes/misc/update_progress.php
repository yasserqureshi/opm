<?php
error_reporting(0); // Turn off all error reporting
date_default_timezone_set("Asia/Karachi");
require("../include/api_class.php");
$obj = new SMILE_API();

$mobile_numbers = array('0333-7981683','0301-6464960','0321-9131997');
$psdp_numbers = array(349,349,9999);
for ($counter=0;$counter<count($mobile_numbers);$counter++)
{
	$mobile_numbers[$counter] = preg_replace("/-/", '',$mobile_numbers[$counter]);
	$var_session=$obj->get_session();
	$var_result=$obj->send_sms($mobile_numbers[$counter],"8583","Please update One Pager progress of project having PSDP # ".$psdp_numbers[$counter]." for July, 2016. For more information call 0321-9131997 or login www.psdp.net/pmes");
	echo $counter."    ".$mobile_numbers[$counter]."    ".$var_result."<br/>";
}
?>
<title> Update One Pager Progress </title>