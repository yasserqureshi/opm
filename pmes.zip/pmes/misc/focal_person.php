<?php
error_reporting(0); // Turn off all error reporting
date_default_timezone_set("Asia/Karachi");

include('../include/connection.php');
$stmt_sms = "select mobile,ministry,total_projects,updated_pmes,updated_opm,work_plan,cash_plan,missing_profile,last_month_progress 
from focal_person
where mobile='03219131997'
order by ministry";
$run_query_sms= $conn->query($stmt_sms);

require("../include/api_class.php");
$obj = new SMILE_API();

while ($row_sms = mysqli_fetch_assoc($run_query_sms))
 {

	$mobile = preg_replace("/-/", '',$row_sms["mobile"]);
	$var_session=$obj->get_session();
	$var_result=$obj->send_sms($mobile,"8583","Planning Commission: Statistics of Your Ministry.\rTotal Project(s)=".$row_sms["total_projects"]."\rUpdated in PMES=".$row_sms["updated_pmes"]."\rUpdated in One Pager=".$row_sms["updated_opm"]."\rMissing Profile(s)=".$row_sms["missing_profile"]."\rWork Plan(s)=".$row_sms["work_plan"]."\rCash Plan(s)=".$row_sms["cash_plan"]."\rProgress for January=".$row_sms["last_month_progress"]."\rFor details call 0321-9131997");

	//$var_result=$obj->send_sms($mobile,"8583","Dear Sir/Madam, If PSDP # ".$row_sms["psdp_number"]." is not your project then please call 0321-9131997 to resolve the issue. Regards,");
	
	echo $row_sms["ministry"]."    ".$mobile."    ".$var_result."<br/>";
	
//	$stmt_update="update send_sms set status='SENT' where contact_2="."'".$row_sms["contact_2"]."'";
//	$run_query_update= $conn->query($stmt_update);
	
 }
?>
<title> Focal Persons </title>