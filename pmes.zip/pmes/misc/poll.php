<?php
error_reporting(0);
$vote = $_REQUEST['vote'];

//get content of textfile
$filename = "poll_result.txt";
$content = file($filename);

//put content in array
$array = explode("||", $content[0]);
$yes = $array[0];
$no = $array[1];

if ($vote == 0) {
  $yes = $yes + 1;
}
if ($vote == 1) {
  $no = $no + 1;
}

//insert votes to txt file
$insertvote = $yes."||".$no;
$fp = fopen($filename,"w");
fputs($fp,$insertvote);
fclose($fp);
?>
<h5 class="text-danger">Result:</h5>
<table>
<tr>
<td>Yes:</td>
<td>
<img src="images/poll.gif"
width='<?php echo(100*round($yes/($no+$yes),2)); ?>'
height='10'>
<?php echo(100*round($yes/($no+$yes),2)).' '; ?>%
</td>
</tr>
<tr>
<td>No:</td>
<td>
<img src="images/poll.gif"
width='<?php echo(100*round($no/($no+$yes),2)); ?>'
height='10'>
<?php echo(100*round($no/($no+$yes),2)).' '; ?>%
</td>
</tr>
</table>
